package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // Users
    @Query("SELECT * FROM users LIMIT 1")
    fun getCurrentUserFlow(): Flow<UserEntity?>

    @Query("SELECT * FROM users LIMIT 1")
    suspend fun getCurrentUser(): UserEntity?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Query("DELETE FROM users")
    suspend fun clearUsers()

    // Foremen
    @Query("SELECT * FROM foreman_profiles")
    fun getAllForemenFlow(): Flow<List<ForemanProfileEntity>>

    @Query("SELECT * FROM foreman_profiles WHERE id = :id LIMIT 1")
    suspend fun getForemanById(id: String): ForemanProfileEntity?

    @Query("SELECT * FROM foreman_profiles WHERE id = :id LIMIT 1")
    fun getForemanByIdFlow(id: String): Flow<ForemanProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertForeman(foreman: ForemanProfileEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertForemen(foremen: List<ForemanProfileEntity>)

    // Projects
    @Query("SELECT * FROM projects ORDER BY startDate DESC")
    fun getAllProjectsFlow(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE customerId = :customerId ORDER BY startDate DESC")
    fun getProjectsForCustomerFlow(customerId: String): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE foremanId = :foremanId ORDER BY startDate DESC")
    fun getProjectsForForemanFlow(foremanId: String): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    suspend fun getProjectById(id: String): ProjectEntity?

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    fun getProjectByIdFlow(id: String): Flow<ProjectEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProjects(projects: List<ProjectEntity>)

    @Update
    suspend fun updateProject(project: ProjectEntity)

    // Finance
    @Query("SELECT * FROM finance_items WHERE projectId = :projectId ORDER BY date DESC")
    fun getFinancesForProjectFlow(projectId: String): Flow<List<FinanceItemEntity>>

    @Query("SELECT * FROM finance_items WHERE projectId = :projectId ORDER BY date DESC")
    suspend fun getFinancesForProject(projectId: String): List<FinanceItemEntity>

    @Query("SELECT * FROM finance_items ORDER BY date DESC")
    fun getAllFinancesFlow(): Flow<List<FinanceItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFinance(finance: FinanceItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFinances(finances: List<FinanceItemEntity>)

    @Query("DELETE FROM finance_items WHERE id = :id")
    suspend fun deleteFinance(id: String)

    // Team
    @Query("SELECT * FROM team_members WHERE foremanId = :foremanId")
    fun getTeamForForemanFlow(foremanId: String): Flow<List<TeamMemberEntity>>

    @Query("SELECT * FROM team_members")
    fun getAllTeamMembersFlow(): Flow<List<TeamMemberEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeamMember(teamMember: TeamMemberEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeamMembers(members: List<TeamMemberEntity>)

    @Query("DELETE FROM team_members WHERE id = :id")
    suspend fun deleteTeamMember(id: String)

    // Reviews
    @Query("SELECT * FROM reviews WHERE foremanId = :foremanId ORDER BY date DESC")
    fun getReviewsForForemanFlow(foremanId: String): Flow<List<ReviewEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReview(review: ReviewEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReviews(reviews: List<ReviewEntity>)

    // Messages
    @Query("SELECT * FROM messages WHERE projectId = :projectId ORDER BY timestamp ASC")
    fun getMessagesForProjectFlow(projectId: String): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    // Photo Reports
    @Query("SELECT * FROM photo_reports WHERE projectId = :projectId")
    fun getPhotoReportsForProjectFlow(projectId: String): Flow<List<PhotoReportEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhotoReport(report: PhotoReportEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhotoReports(reports: List<PhotoReportEntity>)

    @Query("DELETE FROM photo_reports WHERE id = :id")
    suspend fun deletePhotoReport(id: String)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProject(id: String)

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun deleteMessage(id: String)

    // Milestones & Tasks
    @Query("SELECT * FROM milestones WHERE projectId = :projectId")
    fun getMilestonesForProjectFlow(projectId: String): Flow<List<MilestoneEntity>>

    @Query("SELECT * FROM milestones WHERE projectId = :projectId")
    suspend fun getMilestonesForProject(projectId: String): List<MilestoneEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMilestone(milestone: MilestoneEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMilestones(milestones: List<MilestoneEntity>)

    @Update
    suspend fun updateMilestone(milestone: MilestoneEntity)

    @Query("DELETE FROM milestones WHERE id = :id")
    suspend fun deleteMilestone(id: String)
}
