package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.local.ProjectEntity
import com.example.data.local.MilestoneEntity
import kotlinx.coroutines.flow.Flow

class ProjectRepository(private val dao: AppDao) {
    val allProjectsFlow: Flow<List<ProjectEntity>> = dao.getAllProjectsFlow()

    fun getProjectMilestonesFlow(projectId: String): Flow<List<MilestoneEntity>> {
        return dao.getMilestonesForProjectFlow(projectId)
    }

    suspend fun addProject(project: ProjectEntity) {
        dao.insertProject(project)
    }

    suspend fun updateProjectStatus(projectId: String, status: String) {
        val current = dao.getProjectById(projectId)
        if (current != null) {
            dao.insertProject(current.copy(status = status))
        }
    }

    suspend fun addMilestone(milestone: MilestoneEntity) {
        dao.insertMilestone(milestone)
    }
}
