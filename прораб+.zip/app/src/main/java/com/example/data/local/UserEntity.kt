package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val email: String,
    val name: String,
    val role: String, // FOREMAN or CUSTOMER
    val token: String,
    val city: String = "Москва",
    val phone: String = "+7 (999) 000-00-00",
    val avatarUrl: String = ""
)
