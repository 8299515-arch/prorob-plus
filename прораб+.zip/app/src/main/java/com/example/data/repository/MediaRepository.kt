package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.local.PhotoReportEntity
import kotlinx.coroutines.flow.Flow

class MediaRepository(private val dao: AppDao) {
    fun getProjectPhotoReportsFlow(projectId: String): Flow<List<PhotoReportEntity>> {
        return dao.getPhotoReportsForProjectFlow(projectId)
    }

    suspend fun addPhotoReport(report: PhotoReportEntity) {
        dao.insertPhotoReport(report)
    }
}
