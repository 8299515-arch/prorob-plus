package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.local.UserEntity
import com.example.util.EncryptedTokenManager
import kotlinx.coroutines.flow.Flow

class AuthRepository(
    private val dao: AppDao,
    private val tokenManager: EncryptedTokenManager
) {
    val currentUserFlow: Flow<UserEntity?> = dao.getCurrentUserFlow()

    suspend fun login(email: String, passwordHash: String): Result<UserEntity> {
        val user = dao.getCurrentUser() ?: UserEntity(
            id = "user_auth_${System.currentTimeMillis()}",
            email = email,
            name = email.substringBefore("@").replaceFirstChar { it.uppercase() },
            role = "FOREMAN",
            token = "jwt_access_token_${System.currentTimeMillis()}",
            city = "Киев",
            phone = "+380 (44) 100-20-30"
        )
        val accessToken = "access_jwt_${System.currentTimeMillis()}"
        val refreshToken = "refresh_jwt_${System.currentTimeMillis()}"
        tokenManager.saveTokens(accessToken, refreshToken, user.id)
        dao.insertUser(user)
        return Result.success(user)
    }

    suspend fun register(name: String, email: String, role: String, phone: String, city: String): Result<UserEntity> {
        val newUser = UserEntity(
            id = "user_reg_${System.currentTimeMillis()}",
            email = email,
            name = name,
            role = role,
            token = "jwt_access_${System.currentTimeMillis()}",
            city = city,
            phone = phone
        )
        tokenManager.saveTokens("access_${System.currentTimeMillis()}", "refresh_${System.currentTimeMillis()}", newUser.id)
        dao.insertUser(newUser)
        return Result.success(newUser)
    }

    suspend fun logout() {
        tokenManager.clear()
    }

    fun isLoggedIn(): Boolean = tokenManager.isLoggedIn()
}
