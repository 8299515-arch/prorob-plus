package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "finance_items")
data class FinanceItemEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val title: String,
    val amountRub: Long,
    val type: String, // INCOME, EXPENSE
    val category: String, // Черновые материалы, Чистовые материалы, Зарплата рабочим, Оплата заказчика
    val date: String,
    val note: String = "",
    val receiptUrl: String = ""
)
