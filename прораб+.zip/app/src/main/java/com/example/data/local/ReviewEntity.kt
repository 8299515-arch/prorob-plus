package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reviews")
data class ReviewEntity(
    @PrimaryKey val id: String,
    val foremanId: String,
    val customerName: String,
    val rating: Int,
    val text: String,
    val date: String,
    val projectTitle: String
)
