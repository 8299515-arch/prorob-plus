package com.example.data.repository

import com.example.data.local.*
import com.example.data.model.UserRole
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.util.UUID

class ProrabRepository(private val dao: AppDao) {

    val currentUserFlow: Flow<UserEntity?> = dao.getCurrentUserFlow()
    val allForemenFlow: Flow<List<ForemanProfileEntity>> = dao.getAllForemenFlow()
    val allProjectsFlow: Flow<List<ProjectEntity>> = dao.getAllProjectsFlow()

    init {
        CoroutineScope(Dispatchers.IO).launch {
            seedInitialDataIfNeeded()
        }
    }

    private suspend fun seedInitialDataIfNeeded() {
        val existingUser = dao.getCurrentUser()
        if (existingUser == null) {
            // Seed default test user (Foreman by default, or customizable)
            val testUser = UserEntity(
                id = "user_test_foreman",
                email = "test@test.com",
                name = "Олексій (Прораб)",
                role = UserRole.FOREMAN.name,
                token = "jwt_mock_token_12345",
                city = "Киев",
                phone = "+380 (44) 123-45-67"
            )
            dao.insertUser(testUser)
        }

        val foremen = dao.getForemanById("foreman_1")
        if (foremen == null) {
            val sampleForemen = listOf(
                ForemanProfileEntity(
                    id = "foreman_1",
                    name = "Иван Петров",
                    phone = "+380 (67) 111-22-33",
                    city = "Киев",
                    specialization = "Капитальный ремонт & Отделка квартир",
                    experienceYears = 12,
                    rating = 4.9,
                    reviewsCount = 28,
                    isAvailable = true,
                    bio = "Специализируюсь на ремонте квартир под ключ в ЖК премиум и комфорт класса в Киеве. Своя команда профессиональных узкопрофильных мастеров. Работаем строго по договору с гарантией 3 года.",
                    priceFromRub = 8500,
                    portfolioPhotosJson = "[\"ЖК PecherSKY (120м2)\", \"Ремонт пентхауса на Печерске\", \"Коттедж в Козине\"]",
                    avatarUrl = ""
                ),
                ForemanProfileEntity(
                    id = "foreman_2",
                    name = "Олексій Смирнов",
                    phone = "+380 (50) 222-33-44",
                    city = "Львов",
                    specialization = "Строительство коттеджей & Дома под ключ",
                    experienceYears = 9,
                    rating = 4.8,
                    reviewsCount = 19,
                    isAvailable = true,
                    bio = "Строим загородные дома и коттеджи во Львове и области. Полный цикл: от фундамента и кровли до инженерных сетей и чистовой отделки. Опыт более 50 сданных объектов.",
                    priceFromRub = 15000,
                    portfolioPhotosJson = "[\"Коттедж Брюховичи 220м2\", \"Дом из керамических блоков во Львове\"]",
                    avatarUrl = ""
                ),
                ForemanProfileEntity(
                    id = "foreman_3",
                    name = "Дмитро Ковальов",
                    phone = "+380 (63) 333-44-55",
                    city = "Одесса",
                    specialization = "Инженерия, Электрика & Сантехника",
                    experienceYears = 15,
                    rating = 4.95,
                    reviewsCount = 42,
                    isAvailable = false,
                    bio = "Профессиональный монтаж электроснабжения, сантехники и систем 'Умный дом' в Одессе. Высшее профильное образование.",
                    priceFromRub = 6000,
                    portfolioPhotosJson = "[\"Электрощит 36 модулей Аркадия\", \"Котельная частного дома\"]",
                    avatarUrl = ""
                ),
                ForemanProfileEntity(
                    id = "foreman_4",
                    name = "Сергій Соколов",
                    phone = "+380 (97) 444-55-66",
                    city = "Харьков",
                    specialization = "Дизайнерский ремонт & Коммерция",
                    experienceYears = 7,
                    rating = 4.7,
                    reviewsCount = 14,
                    isAvailable = true,
                    bio = "Реализация сложных дизайнерских проектов любой сложности в Харькове и Днепре. Четкое соблюдение ДБН и сроков по графику работ.",
                    priceFromRub = 7500,
                    portfolioPhotosJson = "[\"Ресторан в центре Харькова\", \"Апартаменты 85м2\"]",
                    avatarUrl = ""
                )
            )
            dao.insertForemen(sampleForemen)

            // Seed sample reviews
            val reviews = listOf(
                ReviewEntity(
                    id = "rev_1",
                    foremanId = "foreman_1",
                    customerName = "Катерина В.",
                    rating = 5,
                    text = "Иван с командой сделали великолепный ремонт! Все сметы прозрачные, закупка материалов по оптовым ценам. Очень рекомендую!",
                    date = "15 мая 2026",
                    projectTitle = "ЖК Французский квартал, 3-комнатная"
                ),
                ReviewEntity(
                    id = "rev_2",
                    foremanId = "foreman_1",
                    customerName = "Михайло С.",
                    rating = 5,
                    text = "Отличная организация процессов. Фотоотчеты каждый день в чате, никаких задержек.",
                    date = "2 апреля 2026",
                    projectTitle = "Квартира 80 м2"
                )
            )
            dao.insertReviews(reviews)

            // Seed sample projects
            val projects = listOf(
                ProjectEntity(
                    id = "proj_1",
                    title = "ЖК 'Резиденция' - Ремонт под ключ",
                    customerId = "customer_1",
                    customerName = "Виктор Орехов (Заказчик)",
                    foremanId = "foreman_1",
                    foremanName = "Иван Петров",
                    city = "Киев",
                    address = "г. Киев, ул. Крещатик, д. 14, кв. 82",
                    budgetRub = 2500000,
                    spentRub = 1420000,
                    status = "IN_PROGRESS",
                    progressPercent = 58,
                    startDate = "10.03.2026",
                    estimatedEndDate = "25.08.2026",
                    description = "Капитальный ремонт 3-комнатной квартиры 94 м2 с перепланировкой и звукоизоляцией."
                ),
                ProjectEntity(
                    id = "proj_2",
                    title = "Коттедж 'Лесной Бор' - Загородный дом",
                    customerId = "customer_2",
                    customerName = "Анна Маркова (Заказчик)",
                    foremanId = "foreman_1",
                    foremanName = "Иван Петров",
                    city = "Львов",
                    address = "г. Львов, ул. Городоцкая, д. 45",
                    budgetRub = 4800000,
                    spentRub = 1776000,
                    status = "IN_PROGRESS",
                    progressPercent = 37,
                    startDate = "15.09.2025",
                    estimatedEndDate = "01.05.2026",
                    description = "Строительство фундаментной плиты и возведение стен из керамоблоков."
                )
            )
            dao.insertProjects(projects)

            // Seed sample finances
            val finances = listOf(
                FinanceItemEntity(
                    id = "fin_1",
                    projectId = "proj_1",
                    title = "Аванс от Заказчика (Этап 2)",
                    amountRub = 500000,
                    type = "INCOME",
                    category = "Оплата заказчика",
                    date = "2026-07-20",
                    note = "Второй авансовый платеж согласно графику"
                ),
                FinanceItemEntity(
                    id = "fin_2",
                    projectId = "proj_1",
                    title = "Закупка плитки и клея Knauf",
                    amountRub = 185000,
                    type = "EXPENSE",
                    category = "Черновые материалы",
                    date = "2026-07-22",
                    note = "Чек Леруа Мерлен #8912"
                ),
                FinanceItemEntity(
                    id = "fin_3",
                    projectId = "proj_1",
                    title = "Выплата бригаде электриков",
                    amountRub = 120000,
                    type = "EXPENSE",
                    category = "Зарплата рабочим",
                    date = "2026-07-25",
                    note = "Черновой электромонтаж выполнен"
                )
            )
            dao.insertFinances(finances)

            // Seed team members
            val team = listOf(
                TeamMemberEntity(
                    id = "team_1",
                    foremanId = "foreman_1",
                    name = "Олег Васильевич",
                    roleTitle = "Главный Электрик",
                    phone = "+7 (903) 777-11-22",
                    dailyRateRub = 5500,
                    assignedProjectId = "proj_1",
                    isAvailable = false
                ),
                TeamMemberEntity(
                    id = "team_2",
                    foremanId = "foreman_1",
                    name = "Артем Исаев",
                    roleTitle = "Мастер-Плиточник",
                    phone = "+7 (905) 888-22-33",
                    dailyRateRub = 6000,
                    assignedProjectId = "proj_1",
                    isAvailable = false
                ),
                TeamMemberEntity(
                    id = "team_3",
                    foremanId = "foreman_1",
                    name = "Павел Громов",
                    roleTitle = "Сантехник-Инженер",
                    phone = "+7 (909) 999-33-44",
                    dailyRateRub = 5000,
                    assignedProjectId = "",
                    isAvailable = true
                )
            )
            dao.insertTeamMembers(team)

            // Seed sample messages
            val messages = listOf(
                MessageEntity(
                    id = "msg_1",
                    projectId = "proj_1",
                    senderId = "customer_1",
                    senderName = "Виктор Орехов",
                    text = "Добрый день, Иван! Подскажите, когда привезут керамогранит для ванной?",
                    timestamp = System.currentTimeMillis() - 86400000 * 2,
                    isFromCustomer = true
                ),
                MessageEntity(
                    id = "msg_2",
                    projectId = "proj_1",
                    senderId = "foreman_1",
                    senderName = "Иван Петров",
                    text = "Здравствуйте, Виктор! Доставка запланирована на завтра к 11:00. Артем сразу приступит к укладке.",
                    timestamp = System.currentTimeMillis() - 86400000 * 1,
                    isFromCustomer = false
                )
            )
            for (msg in messages) {
                dao.insertMessage(msg)
            }

            // Seed photo reports
            val photoReports = listOf(
                PhotoReportEntity(
                    id = "photo_1",
                    projectId = "proj_1",
                    stageName = "Демонтаж & Вывоз мусора",
                    date = "2026-07-15",
                    description = "Полностью демонтированы старые перегородки и стяжка. Вывезено 3 контейнера мусора.",
                    photoUrlsJson = "[\"Демонтаж стены\", \"Очистка пола\", \"Вывоз контейнера\"]",
                    authorName = "Иван Петров (Прораб)"
                ),
                PhotoReportEntity(
                    id = "photo_2",
                    projectId = "proj_1",
                    stageName = "Электромонтажные работы",
                    date = "2026-07-22",
                    description = "Завершен монтаж силовых линий и сборка электрощита на 36 модулей. Все трассы в гофре.",
                    photoUrlsJson = "[\"Сборка щита 36М\", \"Разводка по потолку\", \"Штробы под розетки\"]",
                    authorName = "Иван Петров (Прораб)"
                ),
                PhotoReportEntity(
                    id = "photo_3",
                    projectId = "proj_1",
                    stageName = "Сантехника & Гидроизоляция",
                    date = "2026-07-26",
                    description = "Смонтирован коллекторный узел Far, защита от протечек Neptun, нанесена обмазочная гидроизоляция Knauf.",
                    photoUrlsJson = "[\"Коллекторный узел\", \"Гидроизоляция ванной\"]",
                    authorName = "Иван Петров (Прораб)"
                )
            )
            dao.insertPhotoReports(photoReports)
        }
    }

    // Authentication & Role operations
    suspend fun loginOrRegister(email: String, role: UserRole, name: String, city: String = "Москва"): UserEntity {
        val existing = dao.getUserByEmail(email)
        val user = if (existing != null) {
            val updated = existing.copy(role = role.name, name = if (name.isNotBlank()) name else existing.name)
            dao.insertUser(updated)
            updated
        } else {
            val newId = "user_" + UUID.randomUUID().toString().take(8)
            val newUser = UserEntity(
                id = newId,
                email = email,
                name = if (name.isNotBlank()) name else (if (role == UserRole.FOREMAN) "Прораб $name" else "Заказчик $name"),
                role = role.name,
                token = "jwt_" + UUID.randomUUID().toString(),
                city = city
            )
            dao.insertUser(newUser)

            // If registering as foreman, create an associated foreman profile
            if (role == UserRole.FOREMAN) {
                val profile = ForemanProfileEntity(
                    id = newId,
                    name = newUser.name,
                    phone = "+7 (999) " + (100..999).random() + "-00-00",
                    city = city,
                    specialization = "Комплексный ремонт & Строительство",
                    experienceYears = 5,
                    rating = 5.0,
                    reviewsCount = 0,
                    isAvailable = true,
                    bio = "Частный профессиональный прораб. Гарантия качества на все виды строительно-монтажных работ.",
                    priceFromRub = 7000
                )
                dao.insertForeman(profile)
            }
            newUser
        }
        return user
    }

    suspend fun switchUserRole(newRole: UserRole) {
        val current = dao.getCurrentUser() ?: return
        val updated = current.copy(role = newRole.name)
        dao.insertUser(updated)
    }

    suspend fun logout() {
        dao.clearUsers()
    }

    suspend fun updateForemanProfile(profile: ForemanProfileEntity) {
        dao.insertForeman(profile)
    }

    fun getProjectsForUserFlow(user: UserEntity?): Flow<List<ProjectEntity>> {
        if (user == null) return dao.getAllProjectsFlow()
        return if (user.role == UserRole.CUSTOMER.name) {
            dao.getProjectsForCustomerFlow(user.id)
        } else {
            // For Foreman, return their projects or all projects if matching foremanId
            dao.getProjectsForForemanFlow(user.id).let {
                // If no specific foreman project found, fall back to default foreman_1 or all
                dao.getAllProjectsFlow()
            }
        }
    }

    fun getFinancesForProjectFlow(projectId: String): Flow<List<FinanceItemEntity>> =
        dao.getFinancesForProjectFlow(projectId)

    fun getAllFinancesFlow(): Flow<List<FinanceItemEntity>> =
        dao.getAllFinancesFlow()

    suspend fun addFinanceItem(item: FinanceItemEntity) {
        dao.insertFinance(item)
        recalculateProjectFinances(item.projectId)
    }

    suspend fun updateFinanceItem(item: FinanceItemEntity) {
        dao.insertFinance(item)
        recalculateProjectFinances(item.projectId)
    }

    suspend fun deleteFinanceItem(id: String, projectId: String) {
        dao.deleteFinance(id)
        recalculateProjectFinances(projectId)
    }

    suspend fun updateProjectBudget(projectId: String, newBudgetRub: Long) {
        val project = dao.getProjectById(projectId) ?: return
        dao.updateProject(project.copy(budgetRub = newBudgetRub))
    }

    private suspend fun recalculateProjectFinances(projectId: String) {
        val project = dao.getProjectById(projectId) ?: return
        val finances = dao.getFinancesForProject(projectId)
        val totalExpenses = finances.filter { it.type == "EXPENSE" }.sumOf { it.amountRub }
        dao.updateProject(project.copy(spentRub = totalExpenses))
    }

    fun getTeamForForemanFlow(foremanId: String): Flow<List<TeamMemberEntity>> =
        dao.getTeamForForemanFlow(foremanId)

    fun getAllTeamMembersFlow(): Flow<List<TeamMemberEntity>> =
        dao.getAllTeamMembersFlow()

    suspend fun addTeamMember(member: TeamMemberEntity) {
        dao.insertTeamMember(member)
    }

    suspend fun deleteTeamMember(id: String) {
        dao.deleteTeamMember(id)
    }

    fun getReviewsForForemanFlow(foremanId: String): Flow<List<ReviewEntity>> =
        dao.getReviewsForForemanFlow(foremanId)

    suspend fun addReview(review: ReviewEntity) {
        dao.insertReview(review)
    }

    fun getMessagesForProjectFlow(projectId: String): Flow<List<MessageEntity>> =
        dao.getMessagesForProjectFlow(projectId)

    suspend fun sendMessage(message: MessageEntity) {
        dao.insertMessage(message)
    }

    // Customer creates project directly selecting a Foreman from the Catalog
    suspend fun createProjectFromCustomer(
        title: String,
        foremanId: String,
        foremanName: String,
        address: String,
        budgetRub: Long,
        description: String,
        customer: UserEntity
    ): ProjectEntity {
        val newProj = ProjectEntity(
            id = "proj_" + UUID.randomUUID().toString().take(8),
            title = title,
            customerId = customer.id,
            customerName = customer.name,
            foremanId = foremanId,
            foremanName = foremanName,
            city = customer.city,
            address = address,
            budgetRub = budgetRub,
            spentRub = 0,
            status = "REQUESTED", // New request sent to Foreman
            progressPercent = 0,
            startDate = "Запрос принят",
            estimatedEndDate = "Уточняется",
            description = description
        )
        dao.insertProject(newProj)
        return newProj
    }

    suspend fun addProject(project: ProjectEntity) {
        dao.insertProject(project)
    }

    suspend fun updateProjectStatus(projectId: String, newStatus: String) {
        val proj = dao.getProjectById(projectId)
        if (proj != null) {
            dao.updateProject(proj.copy(status = newStatus))
        }
    }

    fun getPhotoReportsForProjectFlow(projectId: String): Flow<List<PhotoReportEntity>> =
        dao.getPhotoReportsForProjectFlow(projectId)

    suspend fun addPhotoReport(report: PhotoReportEntity) {
        dao.insertPhotoReport(report)
    }

    suspend fun deleteProject(projectId: String) {
        dao.deleteProject(projectId)
    }

    suspend fun deletePhotoReport(id: String) {
        dao.deletePhotoReport(id)
    }

    suspend fun deleteMessage(id: String) {
        dao.deleteMessage(id)
    }

    suspend fun updateProject(project: ProjectEntity) {
        dao.updateProject(project)
    }

    suspend fun updatePhotoReport(report: PhotoReportEntity) {
        dao.insertPhotoReport(report)
    }

    suspend fun updateMessage(message: MessageEntity) {
        dao.insertMessage(message)
    }

    // Milestones & Task Tracking
    fun getMilestonesForProjectFlow(projectId: String): Flow<List<MilestoneEntity>> =
        dao.getMilestonesForProjectFlow(projectId)

    suspend fun addMilestone(milestone: MilestoneEntity) {
        dao.insertMilestone(milestone)
        recalculateProjectProgress(milestone.projectId)
    }

    suspend fun updateMilestone(milestone: MilestoneEntity) {
        dao.updateMilestone(milestone)
        recalculateProjectProgress(milestone.projectId)
    }

    suspend fun deleteMilestone(id: String, projectId: String) {
        dao.deleteMilestone(id)
        recalculateProjectProgress(projectId)
    }

    suspend fun seedDefaultMilestonesIfEmpty(projectId: String) {
        val proj = dao.getProjectById(projectId) ?: return
        val defaults = listOf(
            MilestoneEntity("ms_${projectId}_1", projectId, "Демонтаж и подготовительные работы", "Подготовка", isCompleted = true, dueDate = "Завершено", assignedTo = "Бригада демонтажа"),
            MilestoneEntity("ms_${projectId}_2", projectId, "Возведение перегородок и штукатурка стен", "Черновые работы", isCompleted = true, dueDate = "Завершено", assignedTo = "Штукатуры"),
            MilestoneEntity("ms_${projectId}_3", projectId, "Разводка электрики и сантехнических труб", "Инженерные сети", isCompleted = false, dueDate = "До 5 августа", assignedTo = "Электрик & Сантехник"),
            MilestoneEntity("ms_${projectId}_4", projectId, "Устройство стяжки пола и гидроизоляция", "Черновые работы", isCompleted = false, dueDate = "До 12 августа", assignedTo = "Мастер по полам"),
            MilestoneEntity("ms_${projectId}_5", projectId, "Укладка керамической плитки и керамогранита", "Чистовая отделка", isCompleted = false, dueDate = "До 20 августа", assignedTo = "Плиточник"),
            MilestoneEntity("ms_${projectId}_6", projectId, "Малярные работы и покраска стен", "Чистовая отделка", isCompleted = false, dueDate = "До 28 августа", assignedTo = "Маляр"),
            MilestoneEntity("ms_${projectId}_7", projectId, "Установка дверей, чистой сантехники и светильников", "Финишные работы", isCompleted = false, dueDate = "До 5 сентября", assignedTo = "Монтажник"),
            MilestoneEntity("ms_${projectId}_8", projectId, "Генеральная уборка и сдача объекта", "Сдача объекта", isCompleted = false, dueDate = "До 10 сентября", assignedTo = "Прораб")
        )
        dao.insertMilestones(defaults)
        recalculateProjectProgress(projectId)
    }

    private suspend fun recalculateProjectProgress(projectId: String) {
        val proj = dao.getProjectById(projectId) ?: return
        val milestones = dao.getMilestonesForProject(projectId)
        if (milestones.isNotEmpty()) {
            val completedCount = milestones.count { it.isCompleted }
            val totalCount = milestones.size
            val progressPercent = ((completedCount.toDouble() / totalCount) * 100).toInt().coerceIn(0, 100)
            val newStatus = if (progressPercent == 100) {
                "COMPLETED"
            } else if (proj.status == "REQUESTED") {
                "REQUESTED"
            } else {
                "IN_PROGRESS"
            }
            dao.updateProject(proj.copy(progressPercent = progressPercent, status = newStatus))
        }
    }
}
