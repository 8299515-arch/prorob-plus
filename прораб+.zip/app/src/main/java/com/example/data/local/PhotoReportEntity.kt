package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "photo_reports")
data class PhotoReportEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val stageName: String,     // e.g. "Черновой этап & Демонтаж", "Электрика", "Сантехника", "Чистовая отделка"
    val date: String,          // e.g. "28 июля 2026"
    val description: String,   // E.g. "Завершен монтаж электрощита и разводка кабелей"
    val photoUrlsJson: String, // JSON array or comma separated list of photos
    val authorName: String     // e.g. "Прораб Иван Петров"
)
