package com.example.data.ai

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiClient(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()
) {
    companion object {
        private const val TAG = "GeminiClient"
    }

    suspend fun processVoiceTask(request: VoiceTaskRequest): VoiceTaskResponse = withContext(Dispatchers.IO) {
        val spokenText = request.spokenText.trim()
        if (spokenText.isBlank()) {
            return@withContext VoiceTaskResponse(
                success = false,
                result = null,
                errorMessage = "Текст задачи пуст."
            )
        }

        try {
            // Direct call or Backend API Proxy route
            val taskResult = GeminiAiService.parseVoiceToTask(spokenText)
            Log.d(TAG, "Successfully parsed voice task with Gemini API: ${taskResult.taskTitle}")
            VoiceTaskResponse(
                success = true,
                result = taskResult
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error executing Gemini API request", e)
            VoiceTaskResponse(
                success = false,
                result = null,
                errorMessage = e.localizedMessage ?: "Ошибка взаимодействия с AI сервисом."
            )
        }
    }
}
