package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.local.TeamMemberEntity
import com.example.data.local.ForemanProfileEntity
import kotlinx.coroutines.flow.Flow

class TeamRepository(private val dao: AppDao) {
    val allForemenFlow: Flow<List<ForemanProfileEntity>> = dao.getAllForemenFlow()

    fun getForemanTeamFlow(foremanId: String): Flow<List<TeamMemberEntity>> {
        return dao.getTeamForForemanFlow(foremanId)
    }

    suspend fun addTeamMember(member: TeamMemberEntity) {
        dao.insertTeamMember(member)
    }
}
