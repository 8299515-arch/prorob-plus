package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.local.MessageEntity
import kotlinx.coroutines.flow.Flow

class ChatRepository(private val dao: AppDao) {
    fun getProjectMessagesFlow(projectId: String): Flow<List<MessageEntity>> {
        return dao.getMessagesForProjectFlow(projectId)
    }

    suspend fun sendMessage(message: MessageEntity) {
        dao.insertMessage(message)
    }
}
