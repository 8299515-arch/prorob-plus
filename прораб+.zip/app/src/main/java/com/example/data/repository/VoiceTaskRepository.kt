package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.ai.AnalyticsLogger
import com.example.data.ai.GeminiClient
import com.example.data.ai.NetworkUtils
import com.example.data.ai.VoiceTaskRequest
import com.example.data.ai.VoiceTaskResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class VoiceTaskRepository(
    private val geminiClient: GeminiClient = GeminiClient()
) {
    companion object {
        private const val TAG = "VoiceTaskRepository"
    }

    suspend fun parseVoiceText(
        context: Context,
        spokenText: String,
        isRetry: Boolean = false
    ): Result<VoiceTaskResult> = withContext(Dispatchers.IO) {
        AnalyticsLogger.logEvent("parse_voice_task_start", mapOf("textLength" to spokenText.length.toString(), "isRetry" to isRetry.toString()))

        if (spokenText.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Речь не распознана. Продиктуйте задачу еще раз."))
        }

        // Check network connection
        if (!NetworkUtils.isNetworkAvailable(context)) {
            Log.w(TAG, "Network unavailable, using local offline fallback parser")
            AnalyticsLogger.logEvent("voice_task_offline_fallback")
            val offlineTask = buildOfflineFallbackTask(spokenText)
            return@withContext Result.success(offlineTask)
        }

        val request = VoiceTaskRequest(spokenText = spokenText)
        val response = geminiClient.processVoiceTask(request)

        if (response.success && response.result != null) {
            AnalyticsLogger.logEvent("parse_voice_task_success", mapOf("taskTitle" to response.result.taskTitle))
            Result.success(response.result)
        } else {
            Log.w(TAG, "API failed: ${response.errorMessage}, falling back to local heuristic parsing")
            AnalyticsLogger.logEvent("parse_voice_task_fallback", mapOf("error" to (response.errorMessage ?: "Unknown")))
            val offlineTask = buildOfflineFallbackTask(spokenText)
            Result.success(offlineTask)
        }
    }

    private fun buildOfflineFallbackTask(spokenText: String): VoiceTaskResult {
        val lower = spokenText.lowercase()
        val category = when {
            lower.contains("купить") || lower.contains("заказать") || lower.contains("цемент") -> "Закупки"
            lower.contains("электрик") || lower.contains("сантехник") || lower.contains("штукатур") -> "Работы"
            lower.contains("проверить") || lower.contains("осмотр") || lower.contains("фундамент") -> "Осмотр"
            else -> "Работы"
        }

        val priority = if (lower.contains("срочно") || lower.contains("сегодня") || lower.contains("завтра")) "Высокий" else "Средний"

        return VoiceTaskResult(
            taskTitle = spokenText.take(50).replaceFirstChar { it.uppercase() }.ifBlank { "Строительная задача" },
            description = spokenText,
            materials = if (category == "Закупки") spokenText else "Строительные материалы",
            quantity = "1 компл",
            deadline = if (lower.contains("завтра")) "Завтра" else "В течение недели",
            priority = priority,
            assignee = if (category == "Закупки") "Отдел снабжения" else "Мастер участка",
            category = category
        )
    }
}
