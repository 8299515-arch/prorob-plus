package com.example.data.ai

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log

data class VoiceTaskRequest(
    val spokenText: String,
    val contextInfo: String = "Строительный объект Прораб+",
    val userRole: String = "FOREMAN"
)

data class VoiceTaskResponse(
    val success: Boolean,
    val result: VoiceTaskResult?,
    val errorMessage: String? = null
)

object NetworkUtils {
    fun isNetworkAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}

object AnalyticsLogger {
    private const val TAG = "ProrabAnalytics"

    fun logEvent(eventName: String, params: Map<String, String> = emptyMap()) {
        Log.i(TAG, "Event: $eventName | Params: $params")
    }

    fun logError(eventName: String, throwable: Throwable) {
        Log.e(TAG, "Error in event $eventName: ${throwable.localizedMessage}", throwable)
    }
}
