package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "milestones")
data class MilestoneEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val title: String,
    val category: String,
    val isCompleted: Boolean = false,
    val dueDate: String = "",
    val assignedTo: String = "",
    val notes: String = ""
)
