package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "foreman_profiles")
data class ForemanProfileEntity(
    @PrimaryKey val id: String, // userId
    val name: String,
    val phone: String,
    val city: String,
    val specialization: String,
    val experienceYears: Int,
    val rating: Double,
    val reviewsCount: Int,
    val isAvailable: Boolean,
    val bio: String,
    val priceFromRub: Long,
    val portfolioPhotosJson: String = "[]", // serialized JSON or comma-separated list
    val avatarUrl: String = ""
)
