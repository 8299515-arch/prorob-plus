package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "team_members")
data class TeamMemberEntity(
    @PrimaryKey val id: String,
    val foremanId: String,
    val name: String,
    val roleTitle: String, // Электрик, Сантехник, Плиточник, Штукатур
    val phone: String,
    val dailyRateRub: Long,
    val assignedProjectId: String = "",
    val isAvailable: Boolean = true
)
