package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val title: String,
    val customerId: String,
    val customerName: String,
    val foremanId: String,
    val foremanName: String,
    val city: String,
    val address: String,
    val budgetRub: Long,
    val spentRub: Long,
    val status: String, // REQUESTED, ACTIVE, IN_PROGRESS, COMPLETED, PAUSED
    val progressPercent: Int,
    val startDate: String,
    val estimatedEndDate: String,
    val description: String
)
