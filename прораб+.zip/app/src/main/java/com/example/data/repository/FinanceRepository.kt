package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.local.FinanceItemEntity
import kotlinx.coroutines.flow.Flow

class FinanceRepository(private val dao: AppDao) {
    val allFinancesFlow: Flow<List<FinanceItemEntity>> = dao.getAllFinancesFlow()

    fun getProjectFinancesFlow(projectId: String): Flow<List<FinanceItemEntity>> {
        return dao.getFinancesForProjectFlow(projectId)
    }

    suspend fun addFinanceItem(item: FinanceItemEntity) {
        dao.insertFinance(item)
    }
}
