package com.example.data.model

enum class UserRole {
    FOREMAN,
    CUSTOMER
}

enum class ProjectStatus {
    REQUESTED,
    ACTIVE,
    IN_PROGRESS,
    COMPLETED,
    PAUSED
}

enum class FinanceType {
    INCOME,
    EXPENSE
}
