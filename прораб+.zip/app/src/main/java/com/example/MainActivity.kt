package com.example

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import com.example.data.local.AppDatabase
import com.example.data.repository.ProrabRepository
import com.example.ui.navigation.AppNavigation
import com.example.ui.theme.ProrabPlusTheme
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.CatalogViewModel
import com.example.ui.viewmodel.FinanceViewModel
import com.example.ui.viewmodel.ProjectViewModel
import com.example.ui.viewmodel.TeamViewModel
import com.example.util.AppLanguageProvider
import com.example.util.NotificationHelper

class MainActivity : ComponentActivity() {

  private val requestPermissionLauncher = registerForActivityResult(
    ActivityResultContracts.RequestPermission()
  ) { _ -> }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Initialize Push Notification channels
    NotificationHelper.createNotificationChannels(this)

    // Request Notification permission on Android 13+
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      requestPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
    }

    val db = AppDatabase.getDatabase(this)
    val dao = db.appDao()
    val repository = ProrabRepository(dao)

    val authViewModel = AuthViewModel(repository)
    val catalogViewModel = CatalogViewModel(repository)
    val projectViewModel = ProjectViewModel(repository)
    val financeViewModel = FinanceViewModel(repository)
    val teamViewModel = TeamViewModel(repository)

    setContent {
      ProrabPlusTheme {
        AppLanguageProvider {
          Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
            AppNavigation(
              authViewModel = authViewModel,
              catalogViewModel = catalogViewModel,
              projectViewModel = projectViewModel,
              financeViewModel = financeViewModel,
              teamViewModel = teamViewModel
            )
          }
        }
      }
    }
  }
}
