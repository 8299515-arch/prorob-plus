package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

enum class NotificationType {
    ESTIMATE_STATUS,
    NEW_CHAT_MESSAGE,
    MILESTONE_UPDATE,
    GENERAL
}

data class AppNotification(
    val id: String = UUID.randomUUID().toString(),
    val type: NotificationType,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val projectId: String? = null,
    val projectName: String? = null,
    var isRead: Boolean = false
)

object NotificationHelper {

    const val CHANNEL_ID_ESTIMATES = "channel_estimates_status"
    const val CHANNEL_ID_CHAT = "channel_chat_messages"

    private val _notifications = MutableStateFlow<List<AppNotification>>(
        listOf(
            AppNotification(
                type = NotificationType.ESTIMATE_STATUS,
                title = "Статус сметы обновлен",
                message = "Смета по объекту 'ЖК Новопечерские Липки' утверждена заказчиком.",
                timestamp = System.currentTimeMillis() - 3600000,
                projectName = "ЖК Новопечерские Липки"
            ),
            AppNotification(
                type = NotificationType.NEW_CHAT_MESSAGE,
                title = "Новое сообщение в чате",
                message = "Виктор (Заказчик): 'Подскажите, когда привезут штукатурные смеси?'",
                timestamp = System.currentTimeMillis() - 1800000,
                projectName = "ЖК Новопечерские Липки"
            )
        )
    )
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Channel 1: Estimate & Budget updates
            val estimatesChannel = NotificationChannel(
                CHANNEL_ID_ESTIMATES,
                "Сметы и статус оплаты",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Уведомления об изменении статуса смет, согласовании и финансовом балансе"
                enableVibration(true)
            }

            // Channel 2: Chat messages
            val chatChannel = NotificationChannel(
                CHANNEL_ID_CHAT,
                "Чат и сообщения по объектам",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Push-уведомления о новых сообщениях от прораба или заказчика"
                enableVibration(true)
            }

            notificationManager.createNotificationChannel(estimatesChannel)
            notificationManager.createNotificationChannel(chatChannel)
        }
    }

    fun sendEstimateStatusNotification(
        context: Context,
        projectId: String?,
        projectName: String,
        statusTitle: String,
        details: String
    ) {
        val title = "📋 Смета ($projectName): $statusTitle"
        val message = details
        postNotification(
            context = context,
            channelId = CHANNEL_ID_ESTIMATES,
            notificationId = (System.currentTimeMillis() % 10000).toInt(),
            type = NotificationType.ESTIMATE_STATUS,
            title = title,
            message = message,
            projectId = projectId,
            projectName = projectName
        )
    }

    fun sendChatNotification(
        context: Context,
        projectId: String?,
        projectName: String,
        senderName: String,
        text: String
    ) {
        val title = "💬 $senderName ($projectName)"
        val message = text
        postNotification(
            context = context,
            channelId = CHANNEL_ID_CHAT,
            notificationId = (System.currentTimeMillis() % 10000).toInt(),
            type = NotificationType.NEW_CHAT_MESSAGE,
            title = title,
            message = message,
            projectId = projectId,
            projectName = projectName
        )
    }

    fun sendMilestoneNotification(
        context: Context,
        projectId: String?,
        projectName: String,
        milestoneTitle: String,
        statusText: String
    ) {
        val title = "🏗️ Этап работ ($projectName): $statusText"
        val message = milestoneTitle
        postNotification(
            context = context,
            channelId = CHANNEL_ID_ESTIMATES,
            notificationId = (System.currentTimeMillis() % 10000).toInt(),
            type = NotificationType.MILESTONE_UPDATE,
            title = title,
            message = message,
            projectId = projectId,
            projectName = projectName
        )
    }

    private fun postNotification(
        context: Context,
        channelId: String,
        notificationId: Int,
        type: NotificationType,
        title: String,
        message: String,
        projectId: String?,
        projectName: String?
    ) {
        // Add to internal list first
        val newNotification = AppNotification(
            type = type,
            title = title,
            message = message,
            projectId = projectId,
            projectName = projectName,
            isRead = false
        )
        _notifications.value = listOf(newNotification) + _notifications.value

        // Check permission for system push on Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ActivityCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            // Permission not granted for system status bar, but in-app notification center is updated
            return
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.prorab_plus_logo_1785590039568)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        try {
            NotificationManagerCompat.from(context).notify(notificationId, builder.build())
        } catch (e: SecurityException) {
            // Handled if permission missing
        }
    }

    fun markAsRead(id: String) {
        _notifications.value = _notifications.value.map {
            if (it.id == id) it.copy(isRead = true) else it
        }
    }

    fun markAllAsRead() {
        _notifications.value = _notifications.value.map { it.copy(isRead = true) }
    }

    fun clearAll() {
        _notifications.value = emptyList()
    }
}
