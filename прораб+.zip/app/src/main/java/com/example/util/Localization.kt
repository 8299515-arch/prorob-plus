package com.example.util

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class AppLanguage(val code: String, val displayName: String, val flag: String) {
    RU("ru", "Русский", "🇷🇺"),
    UK("uk", "Українська", "🇺🇦"),
    EN("en", "English", "🇬🇧")
}

object LanguageState {
    var currentLanguage by mutableStateOf(AppLanguage.RU)
}

val LocalAppLanguage = compositionLocalOf { AppLanguage.RU }

@Composable
fun AppLanguageProvider(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalAppLanguage provides LanguageState.currentLanguage) {
        content()
    }
}

object L {
    // Helper to fetch translated text
    fun tr(
        ru: String,
        uk: String,
        en: String,
        lang: AppLanguage = LanguageState.currentLanguage
    ): String {
        return when (lang) {
            AppLanguage.RU -> ru
            AppLanguage.UK -> uk
            AppLanguage.EN -> en
        }
    }
}
