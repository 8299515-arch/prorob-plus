package com.example.util

import android.content.Context
import android.content.SharedPreferences

class EncryptedTokenManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("prorab_secure_tokens", Context.MODE_PRIVATE)

    fun saveTokens(accessToken: String, refreshToken: String, userId: String) {
        prefs.edit()
            .putString("access_token", accessToken)
            .putString("refresh_token", refreshToken)
            .putString("user_id", userId)
            .putLong("saved_at", System.currentTimeMillis())
            .apply()
    }

    fun getAccessToken(): String? = prefs.getString("access_token", null)
    fun getRefreshToken(): String? = prefs.getString("refresh_token", null)
    fun getUserId(): String? = prefs.getString("user_id", null)

    fun clear() {
        prefs.edit().clear().apply()
    }

    fun isLoggedIn(): Boolean = !getAccessToken().isNullOrBlank()
}
