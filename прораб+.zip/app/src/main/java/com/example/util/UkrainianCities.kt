package com.example.util

object UkrainianCities {
    val CITIES = listOf(
        "Киев",
        "Харьков",
        "Одесса",
        "Днепр",
        "Львов",
        "Запорожье",
        "Винница",
        "Николаев",
        "Полтава",
        "Черновцы",
        "Черкассы",
        "Хмельницкий",
        "Житомир",
        "Ивано-Франковск",
        "Ровно",
        "Кривой Рог"
    )

    fun getCityTranslation(cityRu: String, lang: AppLanguage): String {
        return when (cityRu) {
            "Киев" -> when (lang) { AppLanguage.UK -> "Київ"; AppLanguage.EN -> "Kyiv"; else -> "Киев" }
            "Харьков" -> when (lang) { AppLanguage.UK -> "Харків"; AppLanguage.EN -> "Kharkiv"; else -> "Харьков" }
            "Одесса" -> when (lang) { AppLanguage.UK -> "Одеса"; AppLanguage.EN -> "Odesa"; else -> "Одесса" }
            "Днепр" -> when (lang) { AppLanguage.UK -> "Дніпро"; AppLanguage.EN -> "Dnipro"; else -> "Днепр" }
            "Львов" -> when (lang) { AppLanguage.UK -> "Львів"; AppLanguage.EN -> "Lviv"; else -> "Львов" }
            "Запорожье" -> when (lang) { AppLanguage.UK -> "Запоріжжя"; AppLanguage.EN -> "Zaporizhzhia"; else -> "Запорожье" }
            "Винница" -> when (lang) { AppLanguage.UK -> "Вінниця"; AppLanguage.EN -> "Vinnytsia"; else -> "Винница" }
            "Николаев" -> when (lang) { AppLanguage.UK -> "Миколаїв"; AppLanguage.EN -> "Mykolaiv"; else -> "Николаев" }
            else -> cityRu
        }
    }
}
