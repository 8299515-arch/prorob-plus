package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.model.UserRole
import com.example.ui.auth.AuthScreen
import com.example.ui.catalog.CatalogScreen
import com.example.ui.catalog.ForemanDetailScreen
import com.example.ui.dashboard.CustomerDashboardScreen
import com.example.ui.dashboard.ForemanDashboardScreen
import com.example.ui.estimates.EstimatesScreen
import com.example.ui.finance.FinanceScreen
import com.example.ui.profile.ForemanProfileEditScreen
import com.example.ui.profile.PrivacyPolicyScreen
import com.example.ui.projects.ProjectDetailScreen
import com.example.ui.projects.ProjectsListScreen
import com.example.ui.team.TeamScreen
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.CatalogViewModel
import com.example.ui.viewmodel.FinanceViewModel
import com.example.ui.viewmodel.ProjectViewModel
import com.example.ui.viewmodel.TeamViewModel

@Composable
fun AppNavigation(
    authViewModel: AuthViewModel,
    catalogViewModel: CatalogViewModel,
    projectViewModel: ProjectViewModel,
    financeViewModel: FinanceViewModel,
    teamViewModel: TeamViewModel,
    navController: NavHostController = rememberNavController()
) {
    val currentUser by authViewModel.currentUser.collectAsState()

    val startDestination = when (currentUser?.role) {
        UserRole.CUSTOMER.name -> Screen.CustomerDashboard.route
        UserRole.FOREMAN.name -> Screen.ForemanDashboard.route
        else -> Screen.Auth.route
    }

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(Screen.Auth.route) {
            AuthScreen(
                authViewModel = authViewModel,
                onLoginSuccess = { role ->
                    if (role == UserRole.CUSTOMER) {
                        navController.navigate(Screen.CustomerDashboard.route) {
                            popUpTo(Screen.Auth.route) { inclusive = true }
                        }
                    } else {
                        navController.navigate(Screen.ForemanDashboard.route) {
                            popUpTo(Screen.Auth.route) { inclusive = true }
                        }
                    }
                }
            )
        }

        composable(Screen.CustomerDashboard.route) {
            CustomerDashboardScreen(
                currentUser = currentUser,
                projectViewModel = projectViewModel,
                onOpenCatalog = { navController.navigate(Screen.Catalog.route) },
                onOpenProject = { projectId -> navController.navigate(Screen.ProjectDetail.createRoute(projectId)) },
                onOpenEstimates = { navController.navigate(Screen.Estimates.route) },
                onSwitchRole = { newRole ->
                    authViewModel.switchRole(newRole)
                    navController.navigate(Screen.ForemanDashboard.route) {
                        popUpTo(Screen.CustomerDashboard.route) { inclusive = true }
                    }
                },
                onOpenPrivacyPolicy = { navController.navigate(Screen.PrivacyPolicy.route) },
                onLogout = {
                    authViewModel.logout {
                        navController.navigate(Screen.Auth.route) {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                }
            )
        }

        composable(Screen.ForemanDashboard.route) {
            ForemanDashboardScreen(
                currentUser = currentUser,
                projectViewModel = projectViewModel,
                financeViewModel = financeViewModel,
                teamViewModel = teamViewModel,
                onOpenProjects = { navController.navigate(Screen.ProjectsList.route) },
                onOpenFinance = { navController.navigate(Screen.Finance.route) },
                onOpenEstimates = { navController.navigate(Screen.Estimates.route) },
                onOpenTeam = { navController.navigate(Screen.Team.route) },
                onOpenCatalog = { navController.navigate(Screen.Catalog.route) },
                onOpenEditProfile = { navController.navigate(Screen.ForemanProfileEdit.route) },
                onOpenProjectDetail = { projectId -> navController.navigate(Screen.ProjectDetail.createRoute(projectId)) },
                onSwitchRole = { newRole ->
                    authViewModel.switchRole(newRole)
                    navController.navigate(Screen.CustomerDashboard.route) {
                        popUpTo(Screen.ForemanDashboard.route) { inclusive = true }
                    }
                },
                onLogout = {
                    authViewModel.logout {
                        navController.navigate(Screen.Auth.route) {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                }
            )
        }

        composable(Screen.ProjectsList.route) {
            ProjectsListScreen(
                currentUser = currentUser,
                projectViewModel = projectViewModel,
                onProjectClick = { projectId -> navController.navigate(Screen.ProjectDetail.createRoute(projectId)) },
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(Screen.Catalog.route) {
            CatalogScreen(
                viewModel = catalogViewModel,
                onForemanClick = { foremanId ->
                    navController.navigate(Screen.ForemanDetail.createRoute(foremanId))
                },
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.ForemanDetail.route,
            arguments = listOf(navArgument("foremanId") { type = NavType.StringType })
        ) { backStackEntry ->
            val foremanId = backStackEntry.arguments?.getString("foremanId") ?: ""
            ForemanDetailScreen(
                foremanId = foremanId,
                catalogViewModel = catalogViewModel,
                projectViewModel = projectViewModel,
                currentUser = currentUser,
                onBackClick = { navController.popBackStack() },
                onProjectCreated = { newProjId ->
                    navController.navigate(Screen.CustomerDashboard.route) {
                        popUpTo(Screen.Catalog.route) { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = Screen.ProjectDetail.route,
            arguments = listOf(navArgument("projectId") { type = NavType.StringType })
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getString("projectId") ?: ""
            ProjectDetailScreen(
                projectId = projectId,
                projectViewModel = projectViewModel,
                financeViewModel = financeViewModel,
                currentUser = currentUser,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(Screen.Finance.route) {
            FinanceScreen(
                viewModel = financeViewModel,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(Screen.Estimates.route) {
            EstimatesScreen(
                projectViewModel = projectViewModel,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(Screen.Team.route) {
            TeamScreen(
                viewModel = teamViewModel,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(Screen.ForemanProfileEdit.route) {
            ForemanProfileEditScreen(
                catalogViewModel = catalogViewModel,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(Screen.PrivacyPolicy.route) {
            PrivacyPolicyScreen(
                onBackClick = { navController.popBackStack() }
            )
        }
    }
}
