package com.example.ui.finance

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import com.example.ui.components.ScrollToTopBottomButtons
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.FinanceItemEntity
import com.example.ui.projects.SmartCalculatorDialog
import com.example.ui.viewmodel.FinanceViewModel
import com.example.util.L

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinanceScreen(
    viewModel: FinanceViewModel,
    onBackClick: () -> Unit
) {
    val finances by viewModel.allFinances.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var showSmartCalculatorDialog by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()

    if (showSmartCalculatorDialog) {
        SmartCalculatorDialog(
            onDismiss = { showSmartCalculatorDialog = false },
            onAddToFinance = { title, amount, category, type ->
                viewModel.addFinanceItem(
                    projectId = "p1",
                    title = title,
                    amountRub = amount,
                    type = type,
                    category = category,
                    date = "Сегодня",
                    note = "Добавлено из Умного калькулятора"
                )
                showSmartCalculatorDialog = false
            }
        )
    }

    val totalIncomes = finances.filter { it.type == "INCOME" }.sumOf { it.amountRub }
    val totalExpenses = finances.filter { it.type == "EXPENSE" }.sumOf { it.amountRub }
    val netProfit = totalIncomes - totalExpenses

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(L.tr("Финансы & Сметы", "Фінанси & Кошториси", "Finances & Estimates"), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showSmartCalculatorDialog = true },
                        modifier = Modifier.testTag("btn_finance_smart_calculator")
                    ) {
                        Icon(
                            Icons.Default.Calculate,
                            contentDescription = L.tr("Умный калькулятор", "Розумний калькулятор", "Smart Calculator"),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.testTag("fab_add_finance")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add transaction")
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
            // Summary Banner Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(L.tr("Баланс и прибыльность", "Баланс та прибутковість", "Balance & Profitability"), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(L.tr("Доходы (Авансы)", "Доходи (Аванси)", "Income"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                Text("$totalIncomes ₴", fontWeight = FontWeight.Bold, color = Color(0xFF16A34A), fontSize = 14.sp, maxLines = 1)
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(L.tr("Расходы (Матер.)", "Витрати (Матер.)", "Expenses"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                Text("$totalExpenses ₴", fontWeight = FontWeight.Bold, color = Color(0xFFDC2626), fontSize = 14.sp, maxLines = 1)
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(L.tr("Чистая прибыль", "Чистий прибуток", "Net Profit"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                Text("$netProfit ₴", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }

            // Financial Entries List Header
            item {
                Text(L.tr("Журнал финансовых транзакций", "Журнал фінансових транзакцій", "Financial Transaction Journal"), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }

            if (finances.isEmpty()) {
                item {
                    Text(L.tr("Нет финансовых записей", "Немає фінансових записів", "No transaction records"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                items(finances, key = { it.id }) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (item.type == "INCOME") Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
                                ) {
                                    Icon(
                                        imageVector = if (item.type == "INCOME") Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                        contentDescription = null,
                                        tint = if (item.type == "INCOME") Color(0xFF166534) else Color(0xFF991B1B),
                                        modifier = Modifier.padding(8.dp).size(20.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 2)
                                    Text("${item.category} • ${item.date}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${if (item.type == "INCOME") "+" else "-"}${item.amountRub} ₴",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (item.type == "INCOME") Color(0xFF16A34A) else Color(0xFFDC2626),
                                    maxLines = 1
                                )

                                IconButton(
                                    onClick = { viewModel.deleteFinanceItem(item.id, item.projectId) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        ScrollToTopBottomButtons(
            listState = listState,
            totalItemsCount = finances.size + 3,
            modifier = Modifier.align(Alignment.BottomEnd)
        )
    }
}

    if (showAddDialog) {
        AddFinanceDialog(
            onDismiss = { showAddDialog = false },
            onSubmit = { title, amount, type, category, note ->
                viewModel.addFinanceItem(
                    projectId = "proj_1",
                    title = title,
                    amountRub = amount,
                    type = type,
                    category = category,
                    date = "2026-07-28",
                    note = note
                )
                showAddDialog = false
            }
        )
    }
}

@Composable
fun AddFinanceDialog(
    onDismiss: () -> Unit,
    onSubmit: (title: String, amount: Long, type: String, category: String, note: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("EXPENSE") } // INCOME or EXPENSE
    var category by remember { mutableStateOf(L.tr("Черновые материалы", "Чорнові матеріали", "Rough Materials")) }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L.tr("Новая финансовая запись", "Новий фінансовий запис", "New Financial Entry")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = type == "EXPENSE",
                        onClick = { type = "EXPENSE" },
                        label = { Text(L.tr("Расход", "Витрата", "Expense")) }
                    )
                    FilterChip(
                        selected = type == "INCOME",
                        onClick = { type = "INCOME" },
                        label = { Text(L.tr("Доход (Аванс)", "Дохід (Аванс)", "Income / Advance")) }
                    )
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(L.tr("Наименование операции", "Найменування операції", "Operation Title")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_finance_title")
                )

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text(L.tr("Сумма (₴)", "Сума (₴)", "Amount (₴)")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_finance_amount")
                )

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text(L.tr("Категория (Материалы, Рабочие, Оплата)", "Категорія (Матеріали, Робітники, Оплата)", "Category (Materials, Crew, Payment)")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text(L.tr("Примечание / № чека", "Примітка / № чека", "Note / Receipt #")) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountStr.toLongOrNull() ?: 0L
                    if (title.isNotBlank() && amt > 0) {
                        onSubmit(title, amt, type, category, note)
                    }
                },
                modifier = Modifier.testTag("submit_add_finance")
            ) {
                Text(L.tr("Сохранить", "Зберегти", "Save"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(L.tr("Отмена", "Скасувати", "Cancel")) }
        }
    )
}
