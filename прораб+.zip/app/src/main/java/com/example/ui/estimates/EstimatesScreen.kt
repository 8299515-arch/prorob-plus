package com.example.ui.estimates

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import com.example.ui.components.ScrollToTopBottomButtons
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.ProjectEntity
import com.example.ui.components.AiEstimateAuditDialog
import com.example.ui.notification.NotificationCenterDialog
import com.example.ui.projects.SmartCalculatorDialog
import com.example.ui.viewmodel.ProjectViewModel
import com.example.util.LanguageState
import com.example.util.L
import com.example.util.NotificationHelper

data class EstimateItem(
    val id: String,
    val category: String,
    val title: String,
    val unit: String,
    val quantity: Double,
    val pricePerUnit: Long
) {
    val totalPrice: Long get() = (quantity * pricePerUnit).toLong()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EstimatesScreen(
    projectViewModel: ProjectViewModel,
    initialProjectId: String? = null,
    onBackClick: () -> Unit
) {
    val lang = LanguageState.currentLanguage
    val allProjects by projectViewModel.allProjects.collectAsState()
    
    val context = LocalContext.current
    val notifications by NotificationHelper.notifications.collectAsState()
    val unreadNotifications = remember(notifications) { notifications.count { !it.isRead } }

    var selectedProject by remember(allProjects, initialProjectId) {
        mutableStateOf(
            allProjects.find { it.id == initialProjectId } ?: allProjects.firstOrNull()
        )
    }

    var showProjectDropdown by remember { mutableStateOf(false) }
    var showAddItemDialog by remember { mutableStateOf(false) }
    var showSmartCalculatorDialog by remember { mutableStateOf(false) }
    var showAiAuditDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var showNotificationCenter by remember { mutableStateOf(false) }
    var itemToDelete by remember { mutableStateOf<EstimateItem?>(null) }
    var itemToEdit by remember { mutableStateOf<EstimateItem?>(null) }

    if (showNotificationCenter) {
        NotificationCenterDialog(onDismissRequest = { showNotificationCenter = false })
    }

    // Seed interactive estimate items
    val estimateItems = remember {
        mutableStateListOf(
            // Category: Демонтаж
            EstimateItem("e1", "Демонтажные работы", "Демонтаж межкомнатных перегородок (кирпич/гипс)", "м²", 45.0, 250),
            EstimateItem("e2", "Демонтажные работы", "Демонтаж старой стяжки пола до 50мм", "м²", 94.0, 180),
            EstimateItem("e3", "Демонтажные работы", "Вывоз строительного мусора (контейнер 8м³)", "шт", 3.0, 4500),

            // Category: Электрика
            EstimateItem("e4", "Электромонтаж", "Штробление стен под кабель (бетон/кирпич)", "м.п.", 120.0, 150),
            EstimateItem("e5", "Электромонтаж", "Прокладка силового кабеля ВВГнг-LS", "м.п.", 280.0, 80),
            EstimateItem("e6", "Электромонтаж", "Монтаж и сборка электрощита на 36 модулей", "компл", 1.0, 12000),

            // Category: Сантехника
            EstimateItem("e7", "Сантехника & Водоснабжение", "Разводка труб водоснабжения Rehau (точки)", "шт", 12.0, 1800),
            EstimateItem("e8", "Сантехника & Водоснабжение", "Монтаж коллекторного узла с фильтрами Far", "компл", 1.0, 14500),
            EstimateItem("e9", "Сантехника & Водоснабжение", "Установка инсталляции Geberit", "шт", 2.0, 2800),

            // Category: Отделка
            EstimateItem("e10", "Чистовая отделка", "Штукатурка стен по маякам Knauf MP75", "м²", 210.0, 320),
            EstimateItem("e11", "Чистовая отделка", "Укладка керамогранита (60x60)", "м²", 38.0, 650),
            EstimateItem("e12", "Чистовая отделка", "Покраска стен в 2 слоя премиум краской", "м²", 180.0, 280)
        )
    }

    if (showSmartCalculatorDialog) {
        SmartCalculatorDialog(
            onDismiss = { showSmartCalculatorDialog = false },
            onAddToFinance = { title, amount, category, _ ->
                estimateItems.add(
                    EstimateItem(
                        id = "calc_${System.currentTimeMillis()}",
                        category = category,
                        title = title,
                        unit = "компл",
                        quantity = 1.0,
                        pricePerUnit = amount
                    )
                )
                showSmartCalculatorDialog = false
            }
        )
    }

    val totalWorkCost = remember(estimateItems) { estimateItems.sumOf { it.totalPrice } }
    val materialsCost = remember(totalWorkCost) { (totalWorkCost * 0.42).toLong() }
    val grandTotal = totalWorkCost + materialsCost

    val listState = rememberLazyListState()

    if (showAiAuditDialog) {
        val summaryText = estimateItems.joinToString("\n") { "${it.category} -> ${it.title}: ${it.quantity} ${it.unit} x ${it.pricePerUnit} грн = ${it.totalPrice} грн" }
        AiEstimateAuditDialog(
            estimateSummaryText = summaryText,
            onDismissRequest = { showAiAuditDialog = false }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = L.tr("Смета и Расчёт работ", "Кошторис та Розрахунок робіт", "Estimate & Cost Calculation"),
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showAiAuditDialog = true },
                        modifier = Modifier.testTag("btn_estimates_ai_audit")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Analytics,
                            contentDescription = L.tr("AI Аудит Сметы", "AI Аудит Кошторису", "AI Estimate Audit"),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = { showSmartCalculatorDialog = true },
                        modifier = Modifier.testTag("btn_estimates_smart_calculator")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Calculate,
                            contentDescription = L.tr("Умный калькулятор", "Розумний калькулятор", "Smart Calculator"),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = { showNotificationCenter = true },
                        modifier = Modifier.testTag("btn_estimates_notifications")
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadNotifications > 0) {
                                    Badge {
                                        Text(if (unreadNotifications > 9) "9+" else unreadNotifications.toString())
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Notifications, contentDescription = "Notifications")
                        }
                    }
                    IconButton(
                        onClick = {
                            showExportDialog = true
                            NotificationHelper.sendEstimateStatusNotification(
                                context = context,
                                projectId = selectedProject?.id,
                                projectName = selectedProject?.title ?: "Объект",
                                statusTitle = "Смета сформирована к согласованию",
                                details = "Итоговая сумма сметы: $grandTotal ₴ ($totalWorkCost ₴ работы + $materialsCost ₴ материалы)."
                            )
                        }
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "Export PDF", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            )
        }
    ) { innerPadding ->
        val groupedItems = remember(estimateItems) { estimateItems.groupBy { it.category } }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Vibrant construction materials sample board background
            Image(
                painter = painterResource(id = R.drawable.img_bg_estimates_vibrant_1785324459894),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Dark protective scrim for vibrant photo detail with zero white glare
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.25f),
                                Color.Black.copy(alpha = 0.50f)
                            )
                        )
                    )
            )

            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
            // 1. Project Selector Header Item
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Text(
                            text = L.tr("Выберите объект для сметы:", "Оберіть об'єкт для кошторису:", "Select Project for Estimate:"),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        OutlinedCard(
                            onClick = { showProjectDropdown = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = selectedProject?.title ?: L.tr("Общий сметный расчет", "Загальний кошторисний розрахунок", "General Estimate Calculation"),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = selectedProject?.address ?: L.tr("Все объекты", "Всі об'єкти", "All Projects"),
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                        }

                        DropdownMenu(
                            expanded = showProjectDropdown,
                            onDismissRequest = { showProjectDropdown = false }
                        ) {
                            allProjects.forEach { proj ->
                                DropdownMenuItem(
                                    text = { Text("${proj.title} (${proj.city})") },
                                    onClick = {
                                        selectedProject = proj
                                        showProjectDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // 2. Summary Totals Card Item
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = L.tr("ИТОГО ПО СМЕТЕ:", "РАЗОМ ПО КОШТОРИСУ:", "TOTAL ESTIMATE:"),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "$grandTotal ₴",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            )
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.2f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(L.tr("Стоимость работ:", "Вартість робіт:", "Work Cost:"), fontSize = 11.sp, maxLines = 1)
                                Text("$totalWorkCost ₴", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                Text(L.tr("Черновые материалы (эст.):", "Чорнові матеріали (ест.):", "Estimated Materials:"), fontSize = 11.sp, maxLines = 1)
                                Text("$materialsCost ₴", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }

            // 3. Action Bar Item
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = L.tr("Позиции работ и расценки (${estimateItems.size})", "Позиції робіт та розцінки (${estimateItems.size})", "Work Items & Rates (${estimateItems.size})"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = { showSmartCalculatorDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .defaultMinSize(minHeight = 32.dp, minWidth = 1.dp)
                                .testTag("btn_estimates_smart_calc_action")
                        ) {
                            Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(L.tr("Умный калькулятор", "Розумний калькулятор", "Smart Calc"), fontSize = 12.sp)
                        }

                        Button(
                            onClick = { showAddItemDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier
                                .defaultMinSize(minHeight = 32.dp, minWidth = 1.dp)
                                .testTag("btn_add_estimate_item")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(L.tr("Добавить", "Додати", "Add"), fontSize = 12.sp)
                        }
                    }
                }
            }

            // 4. Work Position Cards grouped by category
            groupedItems.forEach { (category, items) ->
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = category,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${items.sumOf { it.totalPrice }} ₴",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                items(items, key = { it.id }) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(
                                    text = "${item.quantity} ${item.unit} × ${item.pricePerUnit} ₴/${item.unit}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${item.totalPrice} ₴",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                Spacer(modifier = Modifier.width(4.dp))

                                IconButton(
                                    onClick = { itemToEdit = item },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                }

                                IconButton(
                                    onClick = { itemToDelete = item },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        ScrollToTopBottomButtons(
            listState = listState,
            totalItemsCount = estimateItems.size + 5,
            modifier = Modifier.align(Alignment.BottomEnd)
        )
    }
}

    // Add Item Dialog
    if (showAddItemDialog) {
        var title by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("Чистовая отделка") }
        var unit by remember { mutableStateOf("м²") }
        var quantityStr by remember { mutableStateOf("") }
        var priceStr by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddItemDialog = false },
            title = { Text(L.tr("Новая позиция сметы", "Нова позиція кошторису", "New Estimate Item"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text(L.tr("Наименование работы", "Найменування роботи", "Job Title")) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text(L.tr("Категория", "Категорія", "Category")) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = quantityStr,
                            onValueChange = { quantityStr = it },
                            label = { Text(L.tr("Количество", "Кількість", "Quantity")) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = unit,
                            onValueChange = { unit = it },
                            label = { Text(L.tr("Ед. изм.", "Од. вим.", "Unit")) },
                            singleLine = true,
                            modifier = Modifier.weight(0.7f)
                        )
                    }

                    OutlinedTextField(
                        value = priceStr,
                        onValueChange = { priceStr = it },
                        label = { Text(L.tr("Цена за единицу (₴)", "Ціна за одиницю (₴)", "Price per unit (₴)")) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val qty = quantityStr.toDoubleOrNull() ?: 1.0
                        val price = priceStr.toLongOrNull() ?: 100
                        val itemCategory = category.ifBlank { "Общие работы" }
                        val itemTitle = title.ifBlank { "Строительно-монтажная работа" }
                        estimateItems.add(
                            EstimateItem(
                                id = "e_" + System.currentTimeMillis(),
                                category = itemCategory,
                                title = itemTitle,
                                unit = unit.ifBlank { "шт" },
                                quantity = qty,
                                pricePerUnit = price
                            )
                        )
                        NotificationHelper.sendEstimateStatusNotification(
                            context = context,
                            projectId = selectedProject?.id,
                            projectName = selectedProject?.title ?: "Объект",
                            statusTitle = "Добавлена новая работа в смету",
                            details = "$itemCategory: $itemTitle ($qty $unit × $price ₴ = ${ (qty * price).toLong() } ₴)"
                        )
                        showAddItemDialog = false
                    },
                    enabled = title.isNotBlank()
                ) {
                    Text(L.tr("Добавить в смету", "Додати до кошторису", "Add to Estimate"))
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddItemDialog = false }) {
                    Text(L.tr("Отмена", "Скасувати", "Cancel"))
                }
            }
        )
    }

    // Export PDF Dialog
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text(L.tr("Экспорт сметы сгенерирован!", "Експорт кошторису згенеровано!", "Estimate Exported!"), fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    L.tr(
                        "Официальная коммерческая смета на сумму $grandTotal ₴ успешно сформирована. Вы можете отправить её заказчику или распечатать.",
                        "Офіційний комерційний кошторис на суму $grandTotal ₴ успішно сформовано. Ви можете надіслати його замовнику або роздрукувати.",
                        "Official commercial estimate of $grandTotal ₴ successfully generated. You can send it to the client or print."
                    )
                )
            },
            confirmButton = {
                Button(onClick = { showExportDialog = false }) {
                    Text(L.tr("Скачать PDF / Отправить", "Завантажити PDF / Надіслати", "Download PDF / Send"))
                }
            }
        )
    }

    if (itemToDelete != null) {
        val item = itemToDelete!!
        AlertDialog(
            onDismissRequest = { itemToDelete = null },
            title = { Text(L.tr("Удалить позицию?", "Видалити позицію?", "Delete Item?"), fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    L.tr(
                        "Вы действительно хотите удалить позицию «${item.title}» из сметного расчета?",
                        "Ви дійсно бажаєте видалити позицію «${item.title}» з кошторисного розрахунку?",
                        "Are you sure you want to delete «${item.title}» from the estimate calculation?"
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        estimateItems.remove(item)
                        itemToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(L.tr("Удалить", "Видалити", "Delete"))
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToDelete = null }) {
                    Text(L.tr("Отмена", "Скасувати", "Cancel"))
                }
            }
        )
    }

    if (itemToEdit != null) {
        val item = itemToEdit!!
        var title by remember { mutableStateOf(item.title) }
        var category by remember { mutableStateOf(item.category) }
        var unit by remember { mutableStateOf(item.unit) }
        var quantityStr by remember { mutableStateOf(item.quantity.toString()) }
        var priceStr by remember { mutableStateOf(item.pricePerUnit.toString()) }

        AlertDialog(
            onDismissRequest = { itemToEdit = null },
            title = { Text(L.tr("Редактировать позицию сметы", "Редагувати позицію кошторису", "Edit Estimate Item"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text(L.tr("Наименование работы", "Найменування роботи", "Job Title")) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text(L.tr("Категория", "Категорія", "Category")) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = quantityStr,
                            onValueChange = { quantityStr = it },
                            label = { Text(L.tr("Количество", "Кількість", "Quantity")) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = unit,
                            onValueChange = { unit = it },
                            label = { Text(L.tr("Ед. изм.", "Од. вим.", "Unit")) },
                            singleLine = true,
                            modifier = Modifier.weight(0.7f)
                        )
                    }

                    OutlinedTextField(
                        value = priceStr,
                        onValueChange = { priceStr = it },
                        label = { Text(L.tr("Цена за единицу (₴)", "Ціна за одиницю (₴)", "Price per unit (₴)")) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val qty = quantityStr.toDoubleOrNull() ?: item.quantity
                        val price = priceStr.toLongOrNull() ?: item.pricePerUnit
                        val index = estimateItems.indexOf(item)
                        if (index != -1) {
                            estimateItems[index] = item.copy(
                                title = title,
                                category = category,
                                unit = unit,
                                quantity = qty,
                                pricePerUnit = price
                            )
                        }
                        itemToEdit = null
                    },
                    enabled = title.isNotBlank()
                ) {
                    Text(L.tr("Сохранить", "Зберегти", "Save"))
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToEdit = null }) {
                    Text(L.tr("Отмена", "Скасувати", "Cancel"))
                }
            }
        )
    }
}
