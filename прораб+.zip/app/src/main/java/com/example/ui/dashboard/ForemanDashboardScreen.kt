package com.example.ui.dashboard

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import com.example.ui.components.ScrollToTopBottomButtons
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.ProjectEntity
import com.example.data.local.UserEntity
import com.example.data.model.UserRole
import com.example.ui.viewmodel.FinanceViewModel
import com.example.ui.viewmodel.ProjectViewModel
import com.example.ui.viewmodel.TeamViewModel
import com.example.data.local.FinanceItemEntity
import com.example.ui.components.AiForemanAssistantDialog
import com.example.ui.components.VoiceTaskCreatorDialog
import com.example.ui.notification.NotificationCenterDialog
import com.example.ui.projects.SmartCalculatorDialog
import com.example.util.AppLanguage
import com.example.util.LanguageState
import com.example.util.L
import com.example.util.NotificationHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForemanDashboardScreen(
    currentUser: UserEntity?,
    projectViewModel: ProjectViewModel,
    financeViewModel: FinanceViewModel,
    teamViewModel: TeamViewModel,
    onOpenProjects: () -> Unit,
    onOpenFinance: () -> Unit,
    onOpenEstimates: () -> Unit,
    onOpenTeam: () -> Unit,
    onOpenCatalog: () -> Unit,
    onOpenEditProfile: () -> Unit,
    onOpenProjectDetail: (String) -> Unit,
    onSwitchRole: (UserRole) -> Unit,
    onLogout: () -> Unit = {}
) {
    val allProjects by projectViewModel.allProjects.collectAsState()
    val finances by financeViewModel.allFinances.collectAsState()
    val teamMembers by teamViewModel.allTeamMembers.collectAsState()

    val notifications by NotificationHelper.notifications.collectAsState()
    val unreadNotifications = remember(notifications) { notifications.count { !it.isRead } }

    val requestedProjects = remember(allProjects) { allProjects.filter { it.status == "REQUESTED" } }
    val activeProjects = remember(allProjects) { allProjects.filter { it.status == "IN_PROGRESS" || it.status == "ACTIVE" } }
    val totalRevenue = remember(finances) { finances.filter { it.type == "INCOME" }.sumOf { it.amountRub } }

    var showLanguageMenu by remember { mutableStateOf(false) }
    var showNotificationCenter by remember { mutableStateOf(false) }
    var showSmartCalculatorDialog by remember { mutableStateOf(false) }
    var showAiAssistantDialog by remember { mutableStateOf(false) }
    var showVoiceTaskDialog by remember { mutableStateOf(false) }

    if (showNotificationCenter) {
        NotificationCenterDialog(onDismissRequest = { showNotificationCenter = false })
    }

    if (showAiAssistantDialog) {
        AiForemanAssistantDialog(
            projectContext = "Объект: ЖК Новопечерские Липки, 80 м2",
            onDismissRequest = { showAiAssistantDialog = false },
            onAddTaskFromAi = { taskTitle ->
                showAiAssistantDialog = false
            }
        )
    }

    if (showVoiceTaskDialog) {
        VoiceTaskCreatorDialog(
            onDismissRequest = { showVoiceTaskDialog = false },
            onTaskCreated = { voiceTask ->
                showVoiceTaskDialog = false
            }
        )
    }

    if (showSmartCalculatorDialog) {
        SmartCalculatorDialog(
            onDismiss = { showSmartCalculatorDialog = false },
            onAddToFinance = { title, amount, category, type ->
                financeViewModel.addFinanceItem(
                    projectId = "p1",
                    title = title,
                    amountRub = amount,
                    type = type,
                    category = category,
                    date = "Сегодня",
                    note = "Добавлено из Умного калькулятора"
                )
                showSmartCalculatorDialog = false
            }
        )
    }

    val listState = rememberLazyListState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(L.tr("Кабинет Прораба", "Кабінет Прораба", "Foreman Dashboard"), fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                actions = {
                    // AI Foreman Assistant
                    IconButton(
                        onClick = { showAiAssistantDialog = true },
                        modifier = Modifier.testTag("btn_foreman_ai_assistant")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = L.tr("AI Помощник", "AI Помічник", "AI Assistant"),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Voice Task Mic
                    IconButton(
                        onClick = { showVoiceTaskDialog = true },
                        modifier = Modifier.testTag("btn_foreman_voice_task")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = L.tr("Голосовая задача", "Голосова задача", "Voice Task"),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Smart Calculator Quick Button
                    IconButton(
                        onClick = { showSmartCalculatorDialog = true },
                        modifier = Modifier.testTag("btn_foreman_smart_calc")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Calculate,
                            contentDescription = L.tr("Умный калькулятор", "Розумний калькулятор", "Smart Calculator"),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Notification Bell Icon with Badge
                    IconButton(
                        onClick = { showNotificationCenter = true },
                        modifier = Modifier.testTag("btn_notifications")
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadNotifications > 0) {
                                    Badge {
                                        Text(if (unreadNotifications > 9) "9+" else unreadNotifications.toString())
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Notifications, contentDescription = "Уведомления")
                        }
                    }

                    // Language Switcher Dropdown
                    Box {
                        TextButton(onClick = { showLanguageMenu = true }) {
                            Text(
                                text = "${LanguageState.currentLanguage.flag} ${LanguageState.currentLanguage.name}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        DropdownMenu(
                            expanded = showLanguageMenu,
                            onDismissRequest = { showLanguageMenu = false }
                        ) {
                            AppLanguage.values().forEach { lang ->
                                DropdownMenuItem(
                                    text = { Text("${lang.flag} ${lang.displayName}") },
                                    onClick = {
                                        LanguageState.currentLanguage = lang
                                        showLanguageMenu = false
                                    }
                                )
                            }
                        }
                    }

                    IconButton(onClick = onOpenEditProfile) {
                        Icon(Icons.Default.AccountBox, contentDescription = "Профиль")
                    }
                    TextButton(onClick = { onSwitchRole(UserRole.CUSTOMER) }) {
                        Text(L.tr("⇄ Заказчик", "⇄ Замовник", "⇄ Customer"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = onLogout) {
                        Icon(Icons.Default.Logout, contentDescription = "Выйти из аккаунта", tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Screen Vibrant Construction Background (Heavy Machinery & Crane Site)
            Image(
                painter = painterResource(id = R.drawable.img_bg_foreman_vibrant_1785324422281),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Dark protective scrim for vibrant photo detail with zero white glare
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.25f),
                                Color.Black.copy(alpha = 0.50f)
                            )
                        )
                    )
            )

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Image(
                                painter = painterResource(id = R.drawable.img_bg_foreman_vibrant_1785324422281),
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(130.dp)
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(130.dp)
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                MaterialTheme.colorScheme.primary.copy(alpha = 0.82f),
                                                MaterialTheme.colorScheme.primary.copy(alpha = 0.95f)
                                            )
                                        )
                                    )
                            )
                            Column(modifier = Modifier.padding(20.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = currentUser?.name ?: "Прораб Олексій",
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                    Text(
                                        text = L.tr("Панель управления объектами и бригадами", "Панель управління об'єктами та бригадами", "Site & Crew Management Dashboard"),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.85f)
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.primary
                                ) {
                                    Text(
                                        text = L.tr("Прораб", "Прораб", "Foreman"),
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Metrics Grid
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MetricCard(
                            title = L.tr("Активных строек", "Активних будівель", "Active Sites"),
                            value = "${activeProjects.size}",
                            icon = Icons.Default.Construction,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onOpenProjects() }
                        )

                        MetricCard(
                            title = L.tr("Заявки из каталога", "Заявки з каталогу", "Catalog Requests"),
                            value = "${requestedProjects.size}",
                            icon = Icons.Default.MarkEmailUnread,
                            badgeColor = if (requestedProjects.isNotEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MetricCard(
                            title = L.tr("Доход (Поступления)", "Дохід (Находження)", "Income / Revenue"),
                            value = "$totalRevenue ₴",
                            icon = Icons.Default.AccountBalanceWallet,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onOpenFinance() }
                        )

                        MetricCard(
                            title = L.tr("Команда / Рабочие", "Команда / Робітники", "Crew / Workers"),
                            value = "${teamMembers.size} ${L.tr("чел.", "чол.", "p.")}",
                            icon = Icons.Default.Groups,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onOpenTeam() }
                        )
                    }
                }
            }

            // Active Construction Objects List Section (FIXED LAYOUT to prevent text wrapping vertically!)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = L.tr("Активные объекты в работе", "Активні об'єкти в роботі", "Active Construction Sites"),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )

                    TextButton(
                        onClick = onOpenProjects,
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text(
                            text = L.tr("Все (${allProjects.size})", "Усі (${allProjects.size})", "All (${allProjects.size})"),
                            maxLines = 1,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            if (activeProjects.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                            Text(L.tr("Нет активных строек в работе", "Немає активних об'єктів у роботі", "No active construction sites"), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            } else {
                items(activeProjects, key = { it.id }) { project ->
                    ForemanProjectDashboardCard(
                        project = project,
                        onClick = { onOpenProjectDetail(project.id) }
                    )
                }
            }

            // Quick Modules Navigation Shortcuts
            item {
                Text(
                    text = L.tr("Разделы системы", "Розділи системи", "System Modules"),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    ModuleShortcutCard(
                        title = L.tr("Смета и Расчёт работ", "Кошторис та Розрахунок робіт", "Estimate & Cost Calculation"),
                        subtitle = L.tr("Калькуляция материалов, прайс-лист работ и экспорт PDF", "Калькуляція матеріалів, прайс робіт та експорт PDF", "Materials calculation, job rates & PDF export"),
                        icon = Icons.Default.Calculate,
                        onClick = onOpenEstimates
                    )

                    ModuleShortcutCard(
                        title = L.tr("Проекты, Объекты & Фотоотчёты", "Проєкти, Об'єкти та Фотозвіти", "Projects, Sites & Photo Reports"),
                        subtitle = L.tr("Сведения о проекте, этапы, фотоотчёты и чат", "Відомості про проєкт, етапи, фотозвіти та чат", "Site info, stages, photo reports & chat"),
                        icon = Icons.Default.Foundation,
                        onClick = onOpenProjects
                    )

                    ModuleShortcutCard(
                        title = L.tr("Финансы и Баланс", "Фінанси та Баланс", "Finances & Balance"),
                        subtitle = L.tr("Учет доходов, расходов, чеков и прибыли", "Облік доходів, витрат, чеків та прибутку", "Income, expenses, receipts & profit accounting"),
                        icon = Icons.Default.Payments,
                        onClick = onOpenFinance
                    )

                    ModuleShortcutCard(
                        title = L.tr("Команда и Специалисты", "Команда та Спеціалісти", "Crew & Specialists"),
                        subtitle = L.tr("Управление мастерами, расценками и графиком", "Управління майстрами, розцінками та графіком", "Worker management, rates & scheduling"),
                        icon = Icons.Default.Engineering,
                        onClick = onOpenTeam
                    )

                    ModuleShortcutCard(
                        title = L.tr("Каталог Прорабов (Публичный список)", "Каталог Прорабів (Публічний список)", "Foremen Catalog (Public List)"),
                        subtitle = L.tr("Просмотр анкет, рейтинга и позиций", "Перегляд анкет, рейтингу та позицій", "Browse profiles, ratings & positions"),
                        icon = Icons.Default.RecentActors,
                        onClick = onOpenCatalog
                    )
                }
            }
        }

        ScrollToTopBottomButtons(
            listState = listState,
            totalItemsCount = 15,
            modifier = Modifier.align(Alignment.BottomEnd)
        )
    }
}
}

@Composable
fun ForemanProjectDashboardCard(
    project: ProjectEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("foreman_project_${project.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = project.title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.weight(1f)
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = L.tr("Сведения & Фото", "Відомості & Фото", "Details & Photos"),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "${L.tr("Заказчик", "Замовник", "Client")}: ${project.customerName} • ${project.address}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("${L.tr("Прогресс", "Прогрес", "Progress")}: ${project.progressPercent}%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                Text("${L.tr("Бюджет", "Бюджет", "Budget")}: ${project.budgetRub} ₴", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }

            Spacer(modifier = Modifier.height(4.dp))

            LinearProgressIndicator(
                progress = { project.progressPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    badgeColor: Color = MaterialTheme.colorScheme.surface,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )

            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ModuleShortcutCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .padding(10.dp)
                        .size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
