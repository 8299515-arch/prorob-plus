package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.ai.VoiceTaskResult
import com.example.ui.viewmodel.VoiceTaskUiState
import com.example.ui.viewmodel.VoiceTaskViewModel
import com.example.util.L

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceTaskCreatorDialog(
    viewModel: VoiceTaskViewModel = viewModel(),
    onDismissRequest: () -> Unit,
    onTaskCreated: (VoiceTaskResult) -> Unit
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val spokenText by viewModel.spokenText.collectAsState()

    // Android Microphone runtime permission launcher
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.onPermissionGranted(context)
        } else {
            viewModel.onPermissionDenied()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            viewModel.stopListening()
        }
    }

    AlertDialog(
        onDismissRequest = {
            viewModel.stopListening()
            onDismissRequest()
        },
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .testTag("dialog_voice_task_creator")
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Mic,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = L.tr("Голосовая задача (AI)", "Голосова задача (AI)", "Voice Task (AI)"),
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                    IconButton(
                        onClick = {
                            viewModel.stopListening()
                            onDismissRequest()
                        }
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Mic Recording Control
                val isListening = uiState is VoiceTaskUiState.Listening
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(
                            if (isListening) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer
                        )
                        .testTag("btn_mic_record"),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(
                        onClick = {
                            if (isListening) {
                                viewModel.stopListening()
                            } else {
                                val hasPermission = ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO
                                ) == PackageManager.PERMISSION_GRANTED

                                if (hasPermission) {
                                    viewModel.startListening(context)
                                } else {
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Mic",
                            tint = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = when (uiState) {
                        is VoiceTaskUiState.Listening -> "Запись речи... Говорите в микрофон"
                        is VoiceTaskUiState.Processing -> "AI Анализирует строительный контекст..."
                        else -> "Нажмите микрофон или отредактируйте текст"
                    },
                    fontSize = 12.sp,
                    color = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Spoken / Edited Text Field
                OutlinedTextField(
                    value = spokenText,
                    onValueChange = { viewModel.updateSpokenText(it) },
                    label = { Text(L.tr("Распознанная речь прораба", "Розпізнана мова виконроба", "Recognized speech")) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_spoken_text"),
                    maxLines = 3,
                    shape = RoundedCornerShape(12.dp),
                    enabled = uiState !is VoiceTaskUiState.Processing
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Error State and Retry Mechanism
                if (uiState is VoiceTaskUiState.Error) {
                    val errorState = uiState as VoiceTaskUiState.Error
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = errorState.message,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedButton(
                                onClick = { viewModel.retry(context) },
                                modifier = Modifier.align(Alignment.End),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(L.tr("Повторить AI анализ", "Повторити AI аналіз", "Retry AI analysis"), fontSize = 11.sp)
                            }
                        }
                    }
                }

                // AI Parsing Button / Loading Indicator
                Button(
                    onClick = { viewModel.parseVoiceTask(context) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_parse_voice_task"),
                    shape = RoundedCornerShape(12.dp),
                    enabled = uiState !is VoiceTaskUiState.Processing && spokenText.isNotBlank()
                ) {
                    if (uiState is VoiceTaskUiState.Processing) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(L.tr("AI Структурирование...", "AI Структурування...", "AI Parsing..."))
                    } else {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(L.tr("Распознать с AI Gemini", "Розпізнати з AI Gemini", "Parse with Gemini AI"))
                    }
                }

                // Structured Task Result Display
                if (uiState is VoiceTaskUiState.Success) {
                    val task = (uiState as VoiceTaskUiState.Success).taskResult
                    Spacer(modifier = Modifier.height(14.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = L.tr("Сформированная задача:", "Сформована задача:", "Structured Task:"),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                SuggestionChip(
                                    onClick = {},
                                    label = { Text(task.priority, fontSize = 10.sp) }
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text("📌 Задача: ${task.taskTitle}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            if (task.description.isNotBlank()) {
                                Text("📝 Описание: ${task.description}", fontSize = 12.sp)
                            }
                            if (task.materials.isNotBlank()) {
                                Text("🧱 Материалы: ${task.materials}", fontSize = 12.sp)
                            }
                            Text("📦 Объём: ${task.quantity}", fontSize = 12.sp)
                            Text("📅 Срок: ${task.deadline}", fontSize = 12.sp)
                            Text("👤 Исполнитель: ${task.assignee}", fontSize = 12.sp)
                            Text("🏷️ Категория: ${task.category}", fontSize = 12.sp)

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = {
                                    onTaskCreated(task)
                                    viewModel.stopListening()
                                    onDismissRequest()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("btn_confirm_voice_task")
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(L.tr("Добавить в план строительства", "Додати в план будівництва", "Add to construction plan"))
                            }
                        }
                    }
                }
            }
        }
    }
}
