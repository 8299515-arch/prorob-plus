package com.example.ui.dashboard

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import com.example.ui.components.ScrollToTopBottomButtons
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.ProjectEntity
import com.example.data.local.UserEntity
import com.example.data.model.UserRole
import com.example.ui.viewmodel.ProjectViewModel
import com.example.util.AppLanguage
import com.example.util.LanguageState
import com.example.util.L

import com.example.ui.notification.NotificationCenterDialog
import com.example.ui.projects.SmartCalculatorDialog
import com.example.util.NotificationHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerDashboardScreen(
    currentUser: UserEntity?,
    projectViewModel: ProjectViewModel,
    onOpenCatalog: () -> Unit,
    onOpenProject: (String) -> Unit,
    onOpenEstimates: () -> Unit,
    onSwitchRole: (UserRole) -> Unit,
    onOpenPrivacyPolicy: () -> Unit,
    onLogout: () -> Unit = {}
) {
    val allProjects by projectViewModel.allProjects.collectAsState()
    val projects = remember(allProjects, currentUser) {
        if (currentUser?.id != null) {
            allProjects.filter { it.customerId == currentUser.id }
        } else {
            allProjects
        }
    }

    val notifications by NotificationHelper.notifications.collectAsState()
    val unreadNotifications = remember(notifications) { notifications.count { !it.isRead } }

    var showLanguageMenu by remember { mutableStateOf(false) }
    var showNotificationCenter by remember { mutableStateOf(false) }
    var showSmartCalculatorDialog by remember { mutableStateOf(false) }

    if (showNotificationCenter) {
        NotificationCenterDialog(onDismissRequest = { showNotificationCenter = false })
    }

    if (showSmartCalculatorDialog) {
        SmartCalculatorDialog(
            onDismiss = { showSmartCalculatorDialog = false },
            onAddToFinance = { _, _, _, _ ->
                showSmartCalculatorDialog = false
            }
        )
    }

    val listState = rememberLazyListState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(L.tr("Кабинет Заказчика", "Кабінет Замовника", "Customer Dashboard"), fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                actions = {
                    // Smart Calculator Button
                    IconButton(
                        onClick = { showSmartCalculatorDialog = true },
                        modifier = Modifier.testTag("btn_customer_smart_calc")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Calculate,
                            contentDescription = L.tr("Умный калькулятор", "Розумний калькулятор", "Smart Calculator"),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Notification Bell Icon with Badge
                    IconButton(
                        onClick = { showNotificationCenter = true },
                        modifier = Modifier.testTag("btn_customer_notifications")
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadNotifications > 0) {
                                    Badge {
                                        Text(if (unreadNotifications > 9) "9+" else unreadNotifications.toString())
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Notifications, contentDescription = "Уведомления")
                        }
                    }

                    // Language Switcher Dropdown
                    Box {
                        TextButton(onClick = { showLanguageMenu = true }) {
                            Text(
                                text = "${LanguageState.currentLanguage.flag} ${LanguageState.currentLanguage.name}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        DropdownMenu(
                            expanded = showLanguageMenu,
                            onDismissRequest = { showLanguageMenu = false }
                        ) {
                            AppLanguage.values().forEach { lang ->
                                DropdownMenuItem(
                                    text = { Text("${lang.flag} ${lang.displayName}") },
                                    onClick = {
                                        LanguageState.currentLanguage = lang
                                        showLanguageMenu = false
                                    }
                                )
                            }
                        }
                    }

                    IconButton(onClick = onOpenPrivacyPolicy) {
                        Icon(Icons.Default.Security, contentDescription = "Политика конфиденциальности")
                    }
                    TextButton(onClick = { onSwitchRole(UserRole.FOREMAN) }) {
                        Text(L.tr("⇄ Прораб", "⇄ Прораб", "⇄ Foreman"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = onLogout) {
                        Icon(Icons.Default.Logout, contentDescription = "Выйти из аккаунта", tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Colorful luxury apartment finishing & interior construction background
            Image(
                painter = painterResource(id = R.drawable.img_bg_customer_vibrant_1785324437377),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Dark protective scrim for vibrant photo detail with zero white glare
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.25f),
                                Color.Black.copy(alpha = 0.50f)
                            )
                        )
                    )
            )

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
            // Welcome Banner Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = L.tr("Здравствуйте, ${currentUser?.name ?: "Заказчик"}!", "Вітаємо, ${currentUser?.name ?: "Замовник"}!", "Welcome, ${currentUser?.name ?: "Customer"}!"),
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = L.tr("Контролируйте стройку и выбирайте проверенных прорабов", "Контролюйте будівництво та обирайте перевірених прорабів", "Track construction & choose verified foremen"),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.primary
                            ) {
                                Text(
                                    text = L.tr("Заказчик", "Замовник", "Customer"),
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = onOpenCatalog,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_open_catalog"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(L.tr("Каталог прорабов", "Каталог прорабів", "Foremen Catalog"), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = onOpenEstimates,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_open_estimates"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(L.tr("Смета и Расчёт", "Кошторис & Розрахунок", "Estimates"), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Quick Stats
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(L.tr("Ваши объекты", "Ваші об'єкти", "Your Projects"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("${projects.size}", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(L.tr("Активные стройки", "Активні будівництва", "Active Construction"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(4.dp))
                            val activeCount = projects.count { it.status == "IN_PROGRESS" || it.status == "ACTIVE" }
                            Text("$activeCount", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary))
                        }
                    }
                }
            }

            // Projects Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = L.tr("Мои объекты и проекты", "Мої об'єкти та проєкти", "My Sites & Projects"),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }
            }

            // Projects List
            if (projects.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.HomeWork, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(L.tr("У вас пока нет активных объектов", "У вас поки немає активних об'єктів", "No active projects yet"), fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                L.tr(
                                    "Перейдите в каталог прорабов, выберите мастера и отправьте ему заявку на проект.",
                                    "Перейдіть до каталогу прорабів, оберіть майстра та надішліть йому заявку на проєкт.",
                                    "Go to the foremen catalog, choose a contractor and submit a request."
                                ),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            OutlinedButton(onClick = onOpenCatalog) {
                                Text(L.tr("Выбрать прораба в каталоге", "Обрати прораба в каталозі", "Choose Foreman"))
                            }
                        }
                    }
                }
            } else {
                items(projects, key = { it.id }) { project ->
                    CustomerProjectCard(
                        project = project,
                        onClick = { onOpenProject(project.id) }
                    )
                }
            }
        }

        ScrollToTopBottomButtons(
            listState = listState,
            totalItemsCount = projects.size + 5,
            modifier = Modifier.align(Alignment.BottomEnd)
        )
    }
}
}

@Composable
fun CustomerProjectCard(
    project: ProjectEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("project_card_${project.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = project.title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.weight(1f)
                )

                // Status Badge
                val (statusText, statusBg, statusFg) = when (project.status) {
                    "REQUESTED" -> Triple(L.tr("Запрос отправлен", "Запит надіслано", "Request sent"), Color(0xFFFEF3C7), Color(0xFF92400E))
                    "IN_PROGRESS" -> Triple(L.tr("Идет стройка", "Триває будівництво", "In Construction"), Color(0xFFDCFCE7), Color(0xFF166534))
                    "COMPLETED" -> Triple(L.tr("Завершен", "Завершено", "Completed"), Color(0xFFE0F2FE), Color(0xFF075985))
                    else -> Triple(L.tr("В обработке", "В обробці", "Processing"), Color(0xFFF1F5F9), Color(0xFF475569))
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = statusBg
                ) {
                    Text(
                        text = statusText,
                        color = statusFg,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Engineering, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${L.tr("Прораб", "Прораб", "Foreman")}: ${project.foremanName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Place, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = project.address,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(L.tr("Прогресс работ:", "Прогрес робіт:", "Progress:"), style = MaterialTheme.typography.bodySmall)
                Text("${project.progressPercent}%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(4.dp))

            LinearProgressIndicator(
                progress = { project.progressPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${L.tr("Бюджет", "Бюджет", "Budget")}: ${project.budgetRub} ₴",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = "${L.tr("Освоено", "Освоєно", "Spent")}: ${project.spentRub} ₴",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
