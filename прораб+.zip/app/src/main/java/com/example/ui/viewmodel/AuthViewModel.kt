package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.UserEntity
import com.example.data.model.UserRole
import com.example.data.repository.ProrabRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AuthViewModel(private val repository: ProrabRepository) : ViewModel() {

    val currentUser: StateFlow<UserEntity?> = repository.currentUserFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    fun loginOrRegister(email: String, role: UserRole, name: String, city: String, onResult: () -> Unit) {
        viewModelScope.launch {
            repository.loginOrRegister(email, role, name, city)
            onResult()
        }
    }

    fun switchRole(newRole: UserRole) {
        viewModelScope.launch {
            repository.switchUserRole(newRole)
        }
    }

    fun logout(onResult: () -> Unit) {
        viewModelScope.launch {
            repository.logout()
            onResult()
        }
    }
}
