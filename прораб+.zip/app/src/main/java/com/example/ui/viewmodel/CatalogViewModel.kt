package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ForemanProfileEntity
import com.example.data.local.ReviewEntity
import com.example.data.repository.ProrabRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class CatalogViewModel(private val repository: ProrabRepository) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCity = MutableStateFlow("Все города")
    val selectedCity: StateFlow<String> = _selectedCity.asStateFlow()

    private val _selectedSpec = MutableStateFlow("Все специализации")
    val selectedSpec: StateFlow<String> = _selectedSpec.asStateFlow()

    private val _onlyAvailable = MutableStateFlow(false)
    val onlyAvailable: StateFlow<Boolean> = _onlyAvailable.asStateFlow()

    val allForemen: StateFlow<List<ForemanProfileEntity>> = repository.allForemenFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val filteredForemen: StateFlow<List<ForemanProfileEntity>> = combine(
        allForemen,
        _searchQuery,
        _selectedCity,
        _selectedSpec,
        _onlyAvailable
    ) { foremen, query, city, spec, available ->
        foremen.filter { f ->
            val matchesQuery = query.isBlank() || f.name.contains(query, ignoreCase = true) || f.specialization.contains(query, ignoreCase = true)
            val matchesCity = city == "Все города" || f.city.equals(city, ignoreCase = true)
            val matchesSpec = spec == "Все специализации" || f.specialization.contains(spec, ignoreCase = true)
            val matchesAvailability = !available || f.isAvailable
            matchesQuery && matchesCity && matchesSpec && matchesAvailability
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCity(city: String) {
        _selectedCity.value = city
    }

    fun setSelectedSpec(spec: String) {
        _selectedSpec.value = spec
    }

    fun toggleOnlyAvailable(available: Boolean) {
        _onlyAvailable.value = available
    }

    fun getReviewsForForeman(foremanId: String): Flow<List<ReviewEntity>> {
        return repository.getReviewsForForemanFlow(foremanId)
    }

    fun updateForemanProfile(profile: ForemanProfileEntity) {
        viewModelScope.launch {
            repository.updateForemanProfile(profile)
        }
    }
}
