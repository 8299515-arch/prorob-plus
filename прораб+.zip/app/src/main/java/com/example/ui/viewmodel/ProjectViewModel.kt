package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.MessageEntity
import com.example.data.local.MilestoneEntity
import com.example.data.local.PhotoReportEntity
import com.example.data.local.ProjectEntity
import com.example.data.local.UserEntity
import com.example.data.repository.ProrabRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class ProjectViewModel(private val repository: ProrabRepository) : ViewModel() {

    val allProjects: StateFlow<List<ProjectEntity>> = repository.allProjectsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun getProjectsForUser(user: UserEntity?): Flow<List<ProjectEntity>> {
        return repository.getProjectsForUserFlow(user)
    }

    fun getPhotoReportsForProject(projectId: String): Flow<List<PhotoReportEntity>> {
        return repository.getPhotoReportsForProjectFlow(projectId)
    }

    fun addPhotoReport(
        projectId: String,
        stageName: String,
        description: String,
        photosJson: String,
        authorName: String
    ) {
        viewModelScope.launch {
            val report = PhotoReportEntity(
                id = "photo_" + UUID.randomUUID().toString().take(8),
                projectId = projectId,
                stageName = stageName.ifBlank { "Ход работ" },
                date = "28 июля 2026",
                description = description.ifBlank { "Фотоотчет по выполненным работам" },
                photoUrlsJson = if (photosJson.isBlank()) "[\"Фото 1\", \"Фото 2\"]" else photosJson,
                authorName = authorName
            )
            repository.addPhotoReport(report)
        }
    }

    fun getMessagesForProject(projectId: String): Flow<List<MessageEntity>> {
        return repository.getMessagesForProjectFlow(projectId)
    }

    fun sendMessage(projectId: String, sender: UserEntity, text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            val isFromCustomer = sender.role == "CUSTOMER"
            val msg = MessageEntity(
                id = "msg_" + System.currentTimeMillis(),
                projectId = projectId,
                senderId = sender.id,
                senderName = sender.name,
                text = text.trim(),
                timestamp = System.currentTimeMillis(),
                isFromCustomer = isFromCustomer
            )
            repository.sendMessage(msg)
        }
    }

    fun createProjectFromCustomer(
        title: String,
        foremanId: String,
        foremanName: String,
        address: String,
        budgetRub: Long,
        description: String,
        customer: UserEntity,
        onCreated: (ProjectEntity) -> Unit
    ) {
        viewModelScope.launch {
            val proj = repository.createProjectFromCustomer(
                title = title,
                foremanId = foremanId,
                foremanName = foremanName,
                address = address,
                budgetRub = budgetRub,
                description = description,
                customer = customer
            )
            onCreated(proj)
        }
    }

    fun addProject(
        title: String,
        address: String,
        budgetRub: Long,
        description: String,
        currentUser: UserEntity?,
        customerName: String = "",
        foremanName: String = ""
    ) {
        viewModelScope.launch {
            val isForeman = currentUser?.role == "FOREMAN"
            val newProj = ProjectEntity(
                id = "proj_" + java.util.UUID.randomUUID().toString().take(8),
                title = title.ifBlank { "Новый объект" },
                customerId = if (!isForeman && currentUser != null) currentUser.id else "customer_1",
                customerName = if (!isForeman && currentUser != null) currentUser.name else customerName.ifBlank { "Заказчик" },
                foremanId = if (isForeman && currentUser != null) currentUser.id else "foreman_1",
                foremanName = if (isForeman && currentUser != null) currentUser.name else foremanName.ifBlank { "Иван Петров" },
                city = currentUser?.city ?: "Москва",
                address = address.ifBlank { "Адрес объекта" },
                budgetRub = budgetRub,
                spentRub = 0,
                status = "IN_PROGRESS",
                progressPercent = 0,
                startDate = "Сегодня",
                estimatedEndDate = "В процессе",
                description = description
            )
            repository.addProject(newProj)
        }
    }

    fun updateProjectStatus(projectId: String, newStatus: String) {
        viewModelScope.launch {
            repository.updateProjectStatus(projectId, newStatus)
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            repository.deleteProject(projectId)
        }
    }

    fun deletePhotoReport(reportId: String) {
        viewModelScope.launch {
            repository.deletePhotoReport(reportId)
        }
    }

    fun deleteMessage(messageId: String) {
        viewModelScope.launch {
            repository.deleteMessage(messageId)
        }
    }

    fun updateProject(project: ProjectEntity) {
        viewModelScope.launch {
            repository.updateProject(project)
        }
    }

    fun updatePhotoReport(report: PhotoReportEntity) {
        viewModelScope.launch {
            repository.updatePhotoReport(report)
        }
    }

    fun updateMessage(message: MessageEntity) {
        viewModelScope.launch {
            repository.updateMessage(message)
        }
    }

    // Milestones & Task Tracking
    fun getMilestonesForProject(projectId: String): Flow<List<MilestoneEntity>> {
        return repository.getMilestonesForProjectFlow(projectId).onEach { milestones ->
            if (milestones.isEmpty()) {
                repository.seedDefaultMilestonesIfEmpty(projectId)
            }
        }
    }

    fun toggleMilestoneCompletion(milestone: MilestoneEntity) {
        viewModelScope.launch {
            val updated = milestone.copy(isCompleted = !milestone.isCompleted)
            repository.updateMilestone(updated)
            // also update project progressPercent in project entity if needed
            val currentMilestones = repository.getMilestonesForProjectFlow(milestone.projectId).firstOrNull() ?: emptyList()
            if (currentMilestones.isNotEmpty()) {
                val updatedList = currentMilestones.map { if (it.id == milestone.id) updated else it }
                val completedCount = updatedList.count { it.isCompleted }
                val newProgress = ((completedCount.toFloat() / updatedList.size) * 100).toInt()
                val proj = repository.allProjectsFlow.firstOrNull()?.find { it.id == milestone.projectId }
                if (proj != null) {
                    repository.updateProject(proj.copy(progressPercent = newProgress))
                }
            }
        }
    }

    fun addMilestone(projectId: String, title: String, category: String, dueDate: String, assignedTo: String) {
        viewModelScope.launch {
            val milestone = MilestoneEntity(
                id = "ms_" + UUID.randomUUID().toString().take(8),
                projectId = projectId,
                title = title.ifBlank { "Новый этап" },
                category = category.ifBlank { "Работы" },
                isCompleted = false,
                dueDate = dueDate.ifBlank { "В процессе" },
                assignedTo = assignedTo.ifBlank { "Мастер" }
            )
            repository.addMilestone(milestone)
        }
    }

    fun updateMilestone(milestone: MilestoneEntity) {
        viewModelScope.launch {
            repository.updateMilestone(milestone)
        }
    }

    fun deleteMilestone(milestoneId: String, projectId: String) {
        viewModelScope.launch {
            repository.deleteMilestone(milestoneId, projectId)
        }
    }
}
