package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Auth : Screen("auth")
    object CustomerDashboard : Screen("customer_dashboard")
    object ForemanDashboard : Screen("foreman_dashboard")
    object Catalog : Screen("catalog")
    object ForemanDetail : Screen("foreman_detail/{foremanId}") {
        fun createRoute(foremanId: String) = "foreman_detail/$foremanId"
    }
    object ProjectDetail : Screen("project_detail/{projectId}") {
        fun createRoute(projectId: String) = "project_detail/$projectId"
    }
    object Finance : Screen("finance")
    object Team : Screen("team")
    object ProjectsList : Screen("projects_list")
    object Estimates : Screen("estimates")
    object ForemanProfileEdit : Screen("foreman_profile_edit")
    object PrivacyPolicy : Screen("privacy_policy")
}
