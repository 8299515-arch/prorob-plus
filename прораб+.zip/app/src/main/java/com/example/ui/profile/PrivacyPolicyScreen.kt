package com.example.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ScrollToTopBottomButtons
import com.example.util.L

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyPolicyScreen(
    onBackClick: () -> Unit
) {
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(L.tr("Политика конфиденциальности", "Політика конфіденційності", "Privacy Policy"), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .verticalScroll(scrollState)
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(L.tr("Политика безопасности и Data Safety", "Політика безпеки та Data Safety", "Security Policy & Data Safety"), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(L.tr("Приложение «Прораб+» (Релиз 1.0)", "Застосунок «Прораб+» (Реліз 1.0)", "App «Prorab+» (Release 1.0)"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(L.tr("1. Категории пользователей и данных", "1. Категорії користувачів та даних", "1. User Categories & Data"), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        L.tr(
                            "Приложение обрабатывает данные двух ролей:\n" +
                            "• Прорабы: публичный профиль, контакты, портфолио выполненных объектов (фотографии и описание), расценки.\n" +
                            "• Заказчики: личный кабинет, параметры строящихся объектов, история сообщений и платежей.",
                            "Застосунок обробляє дані двох ролей:\n" +
                            "• Прораби: публічний профіль, контакти, портфоліо виконаних об'єктів (фотографії та опис), розцінки.\n" +
                            "• Замовники: особистий кабінет, параметри об'єктів, що будуються, історія повідомлень та платежів.",
                            "The application processes data for two roles:\n" +
                            "• Foremen: public profile, contacts, portfolio of completed sites (photos and description), rates.\n" +
                            "• Customers: personal dashboard, parameters of sites under construction, history of messages and payments."
                        ),
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(L.tr("2. Офлайн-персистентность и локальное хранение", "2. Офлайн-персистентність та локальне збереження", "2. Offline Persistence & Local Storage"), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        L.tr(
                            "Все сметы, сообщения и данные проектов сохраняются локально в шифрованной базе данных Room с поддержкой офлайн-режима и автоматической синхронизацией при появлении сети.",
                            "Усі кошториси, повідомлення та дані проєктів зберігаються локально в базі даних Room з підтримкою офлайн-режиму та автоматичною синхронізацією при появі мережі.",
                            "All estimates, messages and project data are saved locally in the Room database with offline mode support and automatic sync when network is available."
                        ),
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(L.tr("3. Разграничение прав доступа", "3. Розмежування прав доступу", "3. Access Control"), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        L.tr(
                            "Заказчик имеет доступ исключительно к смете и прогрессу своего собственного объекта. Внутренние данные прораба (зарплаты мастеров, внутренние задачи бригады) заказчику недоступны.",
                            "Замовник має доступ виключно до кошторису та прогресу власного об'єкта. Внутрішні дані прораба (зарплати майстрів, внутрішні завдання бригади) замовнику недоступні.",
                            "The customer has access exclusively to the estimate and progress of their own object. Internal foreman data (worker salaries, internal team tasks) are inaccessible to the customer."
                        ),
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(L.tr("4. Права на фото и портфолио", "4. Права на фото та портфоліо", "4. Photo & Portfolio Rights"), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        L.tr(
                            "Загружаемые фотографии объектов в портфолио используются исключительно в целях презентации квалификации прораба в публичном каталоге.",
                            "Завантажувані фотографії об'єктів у портфоліо використовуються виключно з метою презентації кваліфікації прораба в публічному каталозі.",
                            "Uploaded site photos in the portfolio are used solely for presenting the foreman's qualification in the public catalog."
                        ),
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        ScrollToTopBottomButtons(
            scrollState = scrollState,
            modifier = Modifier.align(Alignment.BottomEnd)
        )
    }
}
}
