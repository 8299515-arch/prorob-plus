package com.example.ui.projects

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.L
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartCalculatorDialog(
    onDismiss: () -> Unit,
    onAddToFinance: (title: String, amount: Long, category: String, type: String) -> Unit
) {
    var selectedCalcType by remember { mutableIntStateOf(0) } // 0: Plaster, 1: Tiles, 2: Paint, 3: Screed, 4: Quick Unit

    // Plaster state
    var plasterArea by remember { mutableStateOf("45") }
    var plasterThicknessMm by remember { mutableStateOf("15") }
    var plasterBagPrice by remember { mutableStateOf("420") }

    // Tiles state
    var tileArea by remember { mutableStateOf("25") }
    var tileMarginPercent by remember { mutableStateOf("10") }
    var tilePricePerM2 by remember { mutableStateOf("1200") }
    var tileAdhesiveBagPrice by remember { mutableStateOf("380") }

    // Paint state
    var paintArea by remember { mutableStateOf("60") }
    var paintCoats by remember { mutableStateOf("2") }
    var paintCoveragePerLiter by remember { mutableStateOf("9") }
    var paintPricePerLiter by remember { mutableStateOf("350") }

    // Floor Screed state
    var screedArea by remember { mutableStateOf("30") }
    var screedThicknessCm by remember { mutableStateOf("5") }
    var screedBagPrice by remember { mutableStateOf("320") }

    // Quick Unit Math state
    var unitTitle by remember { mutableStateOf(L.tr("Монтаж гипсокартона", "Монтаж гіпсокартону", "Drywall Installation")) }
    var unitQty by remember { mutableStateOf("35") }
    var unitType by remember { mutableStateOf("м²") }
    var unitPrice by remember { mutableStateOf("450") }
    var unitCategory by remember { mutableStateOf("Черновые работы") }

    val numberFormatter = remember { NumberFormat.getNumberInstance(Locale("ru", "RU")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Calculate,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = L.tr("Умный строй-калькулятор", "Розумний буд-калькулятор", "Smart Construction Calculator"),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = L.tr("Расчёт материалов и стоимости работ", "Розрахунок матеріалів та вартості робіт", "Material & labor cost estimation"),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Presets Scrollable Tab Row
                ScrollableTabRow(
                    selectedTabIndex = selectedCalcType,
                    edgePadding = 0.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    Tab(
                        selected = selectedCalcType == 0,
                        onClick = { selectedCalcType = 0 },
                        text = { Text(L.tr("Штукатурка", "Штукатурка", "Plaster"), fontSize = 12.sp) }
                    )
                    Tab(
                        selected = selectedCalcType == 1,
                        onClick = { selectedCalcType = 1 },
                        text = { Text(L.tr("Плитка", "Плитка", "Tiles"), fontSize = 12.sp) }
                    )
                    Tab(
                        selected = selectedCalcType == 2,
                        onClick = { selectedCalcType = 2 },
                        text = { Text(L.tr("Краска", "Фарба", "Paint"), fontSize = 12.sp) }
                    )
                    Tab(
                        selected = selectedCalcType == 3,
                        onClick = { selectedCalcType = 3 },
                        text = { Text(L.tr("Стяжка", "Стяжка", "Screed"), fontSize = 12.sp) }
                    )
                    Tab(
                        selected = selectedCalcType == 4,
                        onClick = { selectedCalcType = 4 },
                        text = { Text(L.tr("Быстрый", "Швидкий", "Quick"), fontSize = 12.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                when (selectedCalcType) {
                    0 -> {
                        // Plaster Calculator
                        val area = plasterArea.toDoubleOrNull() ?: 0.0
                        val thick = plasterThicknessMm.toDoubleOrNull() ?: 0.0
                        val bagPrice = plasterBagPrice.toLongOrNull() ?: 0L

                        // Formula: ~8.5kg per m² per 10mm thickness (standard Knauf Rotband)
                        val totalKg = area * (thick / 10.0) * 8.5
                        val totalBags = kotlin.math.ceil(totalKg / 25.0).toInt()
                        val totalCost = totalBags * bagPrice

                        OutlinedTextField(
                            value = plasterArea,
                            onValueChange = { plasterArea = it },
                            label = { Text(L.tr("Площадь стен (м²)", "Площа стін (м²)", "Wall Area (m²)")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = plasterThicknessMm,
                            onValueChange = { plasterThicknessMm = it },
                            label = { Text(L.tr("Толщина слоя (мм)", "Товщина шару (мм)", "Layer thickness (mm)")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = plasterBagPrice,
                            onValueChange = { plasterBagPrice = it },
                            label = { Text(L.tr("Цена мешка 25 кг (₴)", "Ціна мішка 25 кг (₴)", "Price per 25kg bag (₴)")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Results Card
                        CalculationResultCard(
                            title = L.tr("Результат расчёта штукатурки:", "Результат розрахунку штукатурки:", "Plaster Calculation Result:"),
                            details = listOf(
                                L.tr("Общий вес смеси", "Загальна вага суміші", "Total weight") to "${totalKg.toInt()} кг",
                                L.tr("Количество мешков (25 кг)", "Кількість мішків (25 кг)", "Bags needed (25kg)") to "$totalBags шт."
                            ),
                            totalCost = totalCost,
                            onAdd = {
                                val itemTitle = "${L.tr("Штукатурка стен", "Штукатурка стін", "Wall plastering")} ($totalBags ${L.tr("мешков", "мішків", "bags")})"
                                onAddToFinance(itemTitle, totalCost, "Черновые материалы", "EXPENSE")
                            }
                        )
                    }

                    1 -> {
                        // Tile Calculator
                        val area = tileArea.toDoubleOrNull() ?: 0.0
                        val margin = tileMarginPercent.toDoubleOrNull() ?: 10.0
                        val priceM2 = tilePricePerM2.toDoubleOrNull() ?: 0.0
                        val bagPrice = tileAdhesiveBagPrice.toDoubleOrNull() ?: 0.0

                        val totalM2WithMargin = area * (1.0 + margin / 100.0)
                        val tileCost = totalM2WithMargin * priceM2
                        // Adhesive: ~5 kg per m²
                        val adhesiveKg = totalM2WithMargin * 5.0
                        val adhesiveBags = kotlin.math.ceil(adhesiveKg / 25.0).toInt()
                        val adhesiveCost = adhesiveBags * bagPrice
                        val grandTotal = (tileCost + adhesiveCost).toLong()

                        OutlinedTextField(
                            value = tileArea,
                            onValueChange = { tileArea = it },
                            label = { Text(L.tr("Площадь укладки (м²)", "Площа укладання (м²)", "Tiling Area (m²)")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = tilePricePerM2,
                            onValueChange = { tilePricePerM2 = it },
                            label = { Text(L.tr("Цена плитки за м² (₴)", "Ціна плитки за м² (₴)", "Tile Price per m² (₴)")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = tileMarginPercent,
                            onValueChange = { tileMarginPercent = it },
                            label = { Text(L.tr("Запас на подрезку (%)", "Запас на підрізку (%)", "Cut margin (%)")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = tileAdhesiveBagPrice,
                            onValueChange = { tileAdhesiveBagPrice = it },
                            label = { Text(L.tr("Цена клея 25 кг (₴)", "Ціна клею 25 кг (₴)", "Adhesive price 25kg (₴)")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        CalculationResultCard(
                            title = L.tr("Результат расчёта плитки:", "Результат розрахунку плитки:", "Tile Calculation Result:"),
                            details = listOf(
                                L.tr("Площадь с подрезкой", "Площа з підрізкою", "Area with margin") to String.format(Locale.US, "%.1f м²", totalM2WithMargin),
                                L.tr("Клей для плитки", "Клей для плитки", "Tile adhesive") to "$adhesiveBags ${L.tr("мешков", "мішків", "bags")}"
                            ),
                            totalCost = grandTotal,
                            onAdd = {
                                val itemTitle = "${L.tr("Закупка плитки и клея", "Закупівля плитки та клею", "Tile & adhesive purchase")} (${String.format(Locale.US, "%.1f", totalM2WithMargin)} м²)"
                                onAddToFinance(itemTitle, grandTotal, "Чистовые материалы", "EXPENSE")
                            }
                        )
                    }

                    2 -> {
                        // Paint Calculator
                        val area = paintArea.toDoubleOrNull() ?: 0.0
                        val coats = paintCoats.toIntOrNull() ?: 2
                        val coverage = paintCoveragePerLiter.toDoubleOrNull() ?: 9.0
                        val priceLiter = paintPricePerLiter.toDoubleOrNull() ?: 0.0

                        val totalLiters = (area * coats) / coverage
                        val totalCans10L = kotlin.math.ceil(totalLiters / 10.0).toInt()
                        val grandTotal = (totalLiters * priceLiter).toLong()

                        OutlinedTextField(
                            value = paintArea,
                            onValueChange = { paintArea = it },
                            label = { Text(L.tr("Площадь покраски (м²)", "Площа фарбування (м²)", "Painting Area (m²)")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = paintCoats,
                            onValueChange = { paintCoats = it },
                            label = { Text(L.tr("Количество слоев", "Кількість шарів", "Number of coats")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = paintCoveragePerLiter,
                            onValueChange = { paintCoveragePerLiter = it },
                            label = { Text(L.tr("Расход (м² / литр)", "Витрата (м² / літр)", "Coverage (m² / L)")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = paintPricePerLiter,
                            onValueChange = { paintPricePerLiter = it },
                            label = { Text(L.tr("Цена краски за литр (₴)", "Ціна фарби за літр (₴)", "Paint price per liter (₴)")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        CalculationResultCard(
                            title = L.tr("Результат расчёта краски:", "Результат розрахунку фарби:", "Paint Calculation Result:"),
                            details = listOf(
                                L.tr("Общий объём краски", "Загальний об'єм фарби", "Total paint needed") to String.format(Locale.US, "%.1f л", totalLiters),
                                L.tr("Рекомендуем в ведрах 10л", "Рекомендуємо у відрах 10л", "Recommended 10L buckets") to "$totalCans10L шт."
                            ),
                            totalCost = grandTotal,
                            onAdd = {
                                val itemTitle = "${L.tr("Закупка краски", "Закупівля фарби", "Paint purchase")} (${String.format(Locale.US, "%.1f", totalLiters)} л)"
                                onAddToFinance(itemTitle, grandTotal, "Чистовые материалы", "EXPENSE")
                            }
                        )
                    }

                    3 -> {
                        // Screed Calculator
                        val area = screedArea.toDoubleOrNull() ?: 0.0
                        val thickCm = screedThicknessCm.toDoubleOrNull() ?: 0.0
                        val bagPrice = screedBagPrice.toDoubleOrNull() ?: 0.0

                        // ~20 kg per m² per 1 cm thickness
                        val totalKg = area * thickCm * 20.0
                        val totalBags = kotlin.math.ceil(totalKg / 25.0).toInt()
                        val grandTotal = (totalBags * bagPrice).toLong()

                        OutlinedTextField(
                            value = screedArea,
                            onValueChange = { screedArea = it },
                            label = { Text(L.tr("Площадь помещения (м²)", "Площа приміщення (м²)", "Room Area (m²)")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = screedThicknessCm,
                            onValueChange = { screedThicknessCm = it },
                            label = { Text(L.tr("Толщина стяжки (см)", "Товщина стяжки (см)", "Screed thickness (cm)")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = screedBagPrice,
                            onValueChange = { screedBagPrice = it },
                            label = { Text(L.tr("Цена мешка 25 кг (₴)", "Ціна мішка 25 кг (₴)", "Bag price 25kg (₴)")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        CalculationResultCard(
                            title = L.tr("Результат расчёта стяжки:", "Результат розрахунку стяжки:", "Floor Screed Result:"),
                            details = listOf(
                                L.tr("Вес смеси", "Вага суміші", "Total mix weight") to "${totalKg.toInt()} кг",
                                L.tr("Количество мешков (25 кг)", "Кількість мішків (25 кг)", "Bags needed (25kg)") to "$totalBags шт."
                            ),
                            totalCost = grandTotal,
                            onAdd = {
                                val itemTitle = "${L.tr("Материалы для стяжки пола", "Матеріали для стяжки підлоги", "Floor screed materials")} ($totalBags ${L.tr("мешков", "мішків", "bags")})"
                                onAddToFinance(itemTitle, grandTotal, "Черновые материалы", "EXPENSE")
                            }
                        )
                    }

                    4 -> {
                        // Quick Unit Math Calculator
                        val qty = unitQty.toDoubleOrNull() ?: 0.0
                        val price = unitPrice.toDoubleOrNull() ?: 0.0
                        val grandTotal = (qty * price).toLong()

                        OutlinedTextField(
                            value = unitTitle,
                            onValueChange = { unitTitle = it },
                            label = { Text(L.tr("Наименование работы / материала", "Найменування роботи / матеріалу", "Item Title")) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = unitQty,
                                onValueChange = { unitQty = it },
                                label = { Text(L.tr("Кол-во", "Кільк-сть", "Qty")) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = unitType,
                                onValueChange = { unitType = it },
                                label = { Text(L.tr("Ед. изм.", "Од. вим.", "Unit")) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = unitPrice,
                                onValueChange = { unitPrice = it },
                                label = { Text(L.tr("Цена за ед. (₴)", "Ціна за од. (₴)", "Unit Price (₴)")) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1.5f)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Category Dropdown/Selector
                        Text(L.tr("Категория расходов:", "Категорія витрат:", "Expense Category:"), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf("Черновые материалы", "Чистовые материалы", "Зарплата рабочим", "Оборудование").forEach { cat ->
                                FilterChip(
                                    selected = unitCategory == cat,
                                    onClick = { unitCategory = cat },
                                    label = { Text(cat, fontSize = 10.sp, maxLines = 1) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        CalculationResultCard(
                            title = L.tr("Итоговая позиция сметы:", "Підсумкова позиція кошторису:", "Calculated Estimate Item:"),
                            details = listOf(
                                L.tr("Объём работ", "Обсяг робіт", "Volume") to "$qty $unitType",
                                L.tr("Расценка", "Розцінка", "Rate") to "$price ₴/$unitType"
                            ),
                            totalCost = grandTotal,
                            onAdd = {
                                val itemTitle = "$unitTitle ($qty $unitType)"
                                onAddToFinance(itemTitle, grandTotal, unitCategory, "EXPENSE")
                            }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(L.tr("Закрыть", "Закрити", "Close"))
            }
        }
    )
}

@Composable
private fun CalculationResultCard(
    title: String,
    details: List<Pair<String, String>>,
    totalCost: Long,
    onAdd: () -> Unit
) {
    val numberFormatter = remember { NumberFormat.getNumberInstance(Locale("ru", "RU")) }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(8.dp))

            details.forEach { (label, value) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = value,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Divider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f))

            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = L.tr("Ориентировочная сумма:", "Орієнтовна сума:", "Estimated Total:"),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${numberFormatter.format(totalCost)} ₴",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onAdd,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = L.tr("Добавить в смету", "Додати до кошторису", "Add to Estimate"),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
