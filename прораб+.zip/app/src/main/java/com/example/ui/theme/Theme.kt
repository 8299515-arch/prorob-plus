package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// Premium Dark Industrial AI Theme (Primary Mode)
private val DarkColorScheme =
  darkColorScheme(
    primary = ProRabAiBlueLight,
    onPrimary = ProRabWhite,
    primaryContainer = ProRabAiBlueDark,
    onPrimaryContainer = Color(0xFFEFF6FF),
    secondary = ProRabOrange,
    onSecondary = ProRabGraphite,
    secondaryContainer = Color(0xFF78350F),
    onSecondaryContainer = ProRabOrangeLight,
    tertiary = ProRabOrangeLight,
    onTertiary = ProRabGraphite,
    tertiaryContainer = Color(0xFF451A03),
    onTertiaryContainer = Color(0xFFFEF3C7),
    background = ProRabGraphite,
    onBackground = Color(0xFFF3F4F6),
    surface = ProRabGraphiteSurface,
    onSurface = Color(0xFFF3F4F6),
    surfaceVariant = ProRabSteel,
    onSurfaceVariant = Color(0xFFD1D5DB),
    outline = Color(0xFF9CA3AF),
    outlineVariant = Color(0xFF4B5563),
    error = ConstructionDanger,
    onError = ProRabWhite,
    errorContainer = Color(0xFF7F1D1D),
    onErrorContainer = Color(0xFFFEE2E2)
  )

// Premium Light Executive Theme
private val LightColorScheme =
  lightColorScheme(
    primary = ProRabAiBlue,
    onPrimary = ProRabWhite,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = ProRabAiBlueDark,
    secondary = Color(0xFF475569),
    onSecondary = ProRabWhite,
    secondaryContainer = Color(0xFFF1F5F9),
    onSecondaryContainer = Color(0xFF0F172A),
    tertiary = ProRabOrange,
    onTertiary = ProRabWhite,
    tertiaryContainer = Color(0xFFFEF3C7),
    onTertiaryContainer = Color(0xFF78350F),
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = ProRabWhite,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF334155),
    outline = Color(0xFF64748B),
    outlineVariant = Color(0xFFCBD5E1),
    error = ConstructionDanger,
    onError = ProRabWhite,
    errorContainer = Color(0xFFFEE2E2),
    onErrorContainer = Color(0xFF991B1B)
  )

@Composable
fun ProrabPlusTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
