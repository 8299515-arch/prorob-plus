package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.FinanceItemEntity
import com.example.data.repository.ProrabRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class FinanceViewModel(private val repository: ProrabRepository) : ViewModel() {

    val allFinances: StateFlow<List<FinanceItemEntity>> = repository.getAllFinancesFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun getFinancesForProject(projectId: String): Flow<List<FinanceItemEntity>> {
        return repository.getFinancesForProjectFlow(projectId)
    }

    fun addFinanceItem(
        projectId: String,
        title: String,
        amountRub: Long,
        type: String,
        category: String,
        date: String,
        note: String
    ) {
        viewModelScope.launch {
            val item = FinanceItemEntity(
                id = "fin_" + UUID.randomUUID().toString().take(8),
                projectId = projectId,
                title = title,
                amountRub = amountRub,
                type = type,
                category = category,
                date = date,
                note = note
            )
            repository.addFinanceItem(item)
        }
    }

    fun updateFinanceItem(item: FinanceItemEntity) {
        viewModelScope.launch {
            repository.updateFinanceItem(item)
        }
    }

    fun deleteFinanceItem(id: String, projectId: String) {
        viewModelScope.launch {
            repository.deleteFinanceItem(id, projectId)
        }
    }

    fun updateProjectBudget(projectId: String, newBudgetRub: Long) {
        viewModelScope.launch {
            repository.updateProjectBudget(projectId, newBudgetRub)
        }
    }
}
