package com.example.ui.viewmodel

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AnalyticsLogger
import com.example.data.ai.VoiceTaskResult
import com.example.data.repository.VoiceTaskRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

sealed class VoiceTaskUiState {
    object Idle : VoiceTaskUiState()
    object PermissionRequired : VoiceTaskUiState()
    object Listening : VoiceTaskUiState()
    object Processing : VoiceTaskUiState()
    data class Success(val taskResult: VoiceTaskResult) : VoiceTaskUiState()
    data class Error(val message: String, val isNetworkError: Boolean = false) : VoiceTaskUiState()
}

class VoiceTaskViewModel(
    private val repository: VoiceTaskRepository = VoiceTaskRepository()
) : ViewModel() {

    companion object {
        private const val TAG = "VoiceTaskViewModel"
    }

    private val _uiState = MutableStateFlow<VoiceTaskUiState>(VoiceTaskUiState.Idle)
    val uiState: StateFlow<VoiceTaskUiState> = _uiState.asStateFlow()

    private val _spokenText = MutableStateFlow("Завтра нужно заказать 30 мешков цемента М500 и закончить штукатурку стены")
    val spokenText: StateFlow<String> = _spokenText.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null
    private var lastAttemptedText: String = ""

    fun updateSpokenText(text: String) {
        _spokenText.value = text
    }

    fun onPermissionGranted(context: Context) {
        AnalyticsLogger.logEvent("mic_permission_granted")
        startListening(context)
    }

    fun onPermissionDenied() {
        AnalyticsLogger.logEvent("mic_permission_denied")
        _uiState.value = VoiceTaskUiState.Error("Для голосового ввода необходимо разрешение на использование микрофона.")
    }

    fun startListening(context: Context) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _uiState.value = VoiceTaskUiState.Error("Голосовое распознавание недоступно на вашем устройстве. Используйте текстовый ввод.")
            AnalyticsLogger.logEvent("speech_rec_unavailable")
            return
        }

        try {
            stopListening()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        Log.d(TAG, "SpeechRecognizer: Ready for speech")
                        _uiState.value = VoiceTaskUiState.Listening
                    }

                    override fun onBeginningOfSpeech() {
                        Log.d(TAG, "SpeechRecognizer: Beginning of speech")
                    }

                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        Log.d(TAG, "SpeechRecognizer: End of speech")
                        if (_uiState.value is VoiceTaskUiState.Listening) {
                            _uiState.value = VoiceTaskUiState.Idle
                        }
                    }

                    override fun onError(error: Int) {
                        Log.w(TAG, "SpeechRecognizer error code: $error")
                        val errorMessage = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> "Речь не распознана. Попробуйте еще раз."
                            SpeechRecognizer.ERROR_NETWORK -> "Сбой сети. Выполнен переход в режим ввода текста."
                            SpeechRecognizer.ERROR_AUDIO -> "Ошибка аудио. Проверьте настройки микрофона."
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Время ожидания речи истекло."
                            else -> "Ошибка распознавания речи (код $error)."
                        }
                        AnalyticsLogger.logEvent("speech_rec_error", mapOf("errorCode" to error.toString()))
                        _uiState.value = VoiceTaskUiState.Error(errorMessage, isNetworkError = error == SpeechRecognizer.ERROR_NETWORK)
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            val recognized = matches[0]
                            Log.d(TAG, "Recognized speech: $recognized")
                            _spokenText.value = recognized
                            _uiState.value = VoiceTaskUiState.Idle
                            parseVoiceTask(context, recognized)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            _spokenText.value = matches[0]
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Продиктуйте строительную задачу...")
            }
            speechRecognizer?.startListening(intent)
            _uiState.value = VoiceTaskUiState.Listening
            AnalyticsLogger.logEvent("speech_rec_started")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start SpeechRecognizer", e)
            _uiState.value = VoiceTaskUiState.Error("Не удалось запустить микрофон: ${e.localizedMessage}")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            Log.w(TAG, "Cleanup exception on stopListening: ${e.localizedMessage}")
        }
    }

    fun parseVoiceTask(context: Context, text: String = _spokenText.value) {
        if (text.isBlank()) {
            _uiState.value = VoiceTaskUiState.Error("Введите текст задачи или продиктуйте голосом.")
            return
        }

        lastAttemptedText = text
        _uiState.value = VoiceTaskUiState.Processing

        viewModelScope.launch {
            val result = repository.parseVoiceText(context, text)
            result.fold(
                onSuccess = { task ->
                    _uiState.value = VoiceTaskUiState.Success(task)
                },
                onFailure = { error ->
                    _uiState.value = VoiceTaskUiState.Error(
                        message = error.localizedMessage ?: "Ошибка обработки AI задачи",
                        isNetworkError = true
                    )
                }
            )
        }
    }

    fun retry(context: Context) {
        val targetText = if (lastAttemptedText.isNotBlank()) lastAttemptedText else _spokenText.value
        parseVoiceTask(context, targetText)
    }

    fun resetState() {
        _uiState.value = VoiceTaskUiState.Idle
    }

    override fun onCleared() {
        super.onCleared()
        stopListening()
    }
}
