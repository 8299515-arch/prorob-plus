package com.example.ui.projects

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.MessageEntity
import com.example.data.local.MilestoneEntity
import com.example.data.local.PhotoReportEntity
import com.example.data.local.UserEntity
import com.example.ui.notification.NotificationCenterDialog
import com.example.ui.viewmodel.FinanceViewModel
import com.example.ui.viewmodel.ProjectViewModel
import com.example.util.L
import com.example.util.NotificationHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectDetailScreen(
    projectId: String,
    projectViewModel: ProjectViewModel,
    financeViewModel: FinanceViewModel,
    currentUser: UserEntity?,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val notifications by NotificationHelper.notifications.collectAsState()
    val unreadNotifications = remember(notifications) { notifications.count { !it.isRead } }

    val allProjects by projectViewModel.allProjects.collectAsState()
    val project = remember(allProjects, projectId) { allProjects.find { it.id == projectId } }
    
    val messages by projectViewModel.getMessagesForProject(projectId).collectAsState(initial = emptyList())
    val finances by financeViewModel.getFinancesForProject(projectId).collectAsState(initial = emptyList())
    val photoReports by projectViewModel.getPhotoReportsForProject(projectId).collectAsState(initial = emptyList())
    val milestones by projectViewModel.getMilestonesForProject(projectId).collectAsState(initial = emptyList())

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Overview, 1: Milestones, 2: Photo Reports, 3: Chat, 4: Finances
    var messageInput by remember { mutableStateOf("") }
    var showAddPhotoReportDialog by remember { mutableStateOf(false) }
    var selectedPreviewPhoto by remember { mutableStateOf<String?>(null) }

    var showDeleteProjectDialog by remember { mutableStateOf(false) }
    var showEditProjectDialog by remember { mutableStateOf(false) }
    var reportToDelete by remember { mutableStateOf<PhotoReportEntity?>(null) }
    var reportToEdit by remember { mutableStateOf<PhotoReportEntity?>(null) }
    var messageToDelete by remember { mutableStateOf<MessageEntity?>(null) }
    var messageToEdit by remember { mutableStateOf<MessageEntity?>(null) }

    var showAddMilestoneDialog by remember { mutableStateOf(false) }
    var milestoneToEdit by remember { mutableStateOf<MilestoneEntity?>(null) }
    var milestoneToDelete by remember { mutableStateOf<MilestoneEntity?>(null) }

    var showSmartCalculatorDialog by remember { mutableStateOf(false) }
    var showNotificationCenter by remember { mutableStateOf(false) }

    if (showNotificationCenter) {
        NotificationCenterDialog(onDismissRequest = { showNotificationCenter = false })
    }

    if (project == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(project.title, fontWeight = FontWeight.Bold, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showNotificationCenter = true },
                        modifier = Modifier.testTag("btn_project_notifications")
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadNotifications > 0) {
                                    Badge {
                                        Text(if (unreadNotifications > 9) "9+" else unreadNotifications.toString())
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Notifications, contentDescription = "Notifications")
                        }
                    }
                    IconButton(onClick = { showSmartCalculatorDialog = true }) {
                        Icon(Icons.Default.Calculate, contentDescription = "Smart Calculator", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = { showEditProjectDialog = true }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit site", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = { showDeleteProjectDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete site", tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Vibrant architectural blueprint background
            Image(
                painter = painterResource(id = R.drawable.img_bg_projects_vibrant_1785324448473),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Dark protective scrim for vibrant photo detail with zero white glare
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.25f),
                                Color.Black.copy(alpha = 0.50f)
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier.fillMaxSize()
            ) {
            // Main Tabs Bar
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 16.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text(L.tr("Обзор", "Огляд", "Overview")) },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = null) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("${L.tr("Этапы", "Етапи", "Milestones")} (${milestones.size})") },
                    icon = { Icon(Icons.Default.Task, contentDescription = null) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("${L.tr("Фотоотчёты", "Фотозвіти", "Photo Reports")} (${photoReports.size})") },
                    icon = { Icon(Icons.Default.PhotoCamera, contentDescription = null) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("${L.tr("Чат", "Чат", "Chat")} (${messages.size})") },
                    icon = { Icon(Icons.Default.Chat, contentDescription = null) }
                )
                Tab(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    text = { Text(L.tr("Финансы", "Фінанси", "Finances")) },
                    icon = { Icon(Icons.Default.Receipt, contentDescription = null) }
                )
            }

            when (selectedTab) {
                0 -> {
                    // Overview Tab
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(L.tr("Статус объекта", "Статус об'єкта", "Site Status"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = when (project.status) {
                                            "IN_PROGRESS" -> L.tr("Идет стройка", "Триває будівництво", "Under Construction")
                                            "REQUESTED" -> L.tr("Новая заявка", "Нова заявка", "New Request")
                                            "COMPLETED" -> L.tr("Сдан в эксплуатацию", "Здано в експлуатацію", "Completed")
                                            else -> L.tr("В работе", "В роботі", "In Progress")
                                        },
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Text(L.tr("Адрес объекта:", "Адреса об'єкта:", "Site Address:"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(project.address, style = MaterialTheme.typography.bodyMedium)

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Text(L.tr("Участники:", "Учасники:", "Participants:"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("${L.tr("Заказчик", "Замовник", "Customer")}: ${project.customerName}", style = MaterialTheme.typography.bodySmall)
                                    Text("${L.tr("Прораб", "Прораб", "Foreman")}: ${project.foremanName}", style = MaterialTheme.typography.bodySmall)

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Text("${L.tr("Прогресс выполнения", "Прогрес виконання", "Progress")} (${project.progressPercent}%):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    LinearProgressIndicator(
                                        progress = { project.progressPercent / 100f },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(10.dp),
                                        color = MaterialTheme.colorScheme.primary,
                                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                }
                            }
                        }

                        item {
                            MilestoneProgressOverviewCard(
                                milestones = milestones,
                                onViewAllClick = { selectedTab = 1 },
                                onToggleMilestone = { projectViewModel.toggleMilestoneCompletion(it) }
                            )
                        }

                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(L.tr("Описание заказа и задач", "Опис замовлення та завдань", "Order & Task Description"), style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(project.description, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }

                        // Quick Photo Reports Summary Card on Overview Tab
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedTab = 2 },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Collections, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("${L.tr("Фотоотчёты по этапам", "Фотозвіти за етапами", "Stage Photo Reports")} (${photoReports.size})", fontWeight = FontWeight.Bold)
                                        Text(L.tr("Посмотреть свежие фото со стройки", "Переглянути свіжі фото з будівництва", "View fresh construction photos"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Icon(Icons.Default.ChevronRight, contentDescription = null)
                                }
                            }
                        }

                        // Status Actions for Foreman
                        if (currentUser?.role == "FOREMAN") {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text(L.tr("Управление статусом (для прораба):", "Управління статусом (для прораба):", "Status Management (Foreman):"), fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Button(
                                                onClick = { projectViewModel.updateProjectStatus(project.id, "IN_PROGRESS") },
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text(L.tr("В работу", "В роботу", "In Progress"), fontSize = 11.sp)
                                            }

                                            Button(
                                                onClick = { projectViewModel.updateProjectStatus(project.id, "COMPLETED") },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text(L.tr("Завершить", "Завершити", "Complete"), fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // Milestones & Task Tracking Tab
                    MilestoneTrackerTabContent(
                        milestones = milestones,
                        onToggleMilestone = { projectViewModel.toggleMilestoneCompletion(it) },
                        onAddMilestoneClick = { showAddMilestoneDialog = true },
                        onEditMilestoneClick = { milestoneToEdit = it },
                        onDeleteMilestoneClick = { milestoneToDelete = it }
                    )
                }

                2 -> {
                    // Photo Reports Tab
                    Box(modifier = Modifier.fillMaxSize()) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            // Header & Add Action Bar
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = L.tr("История фотоотчётов", "Історія фотозвітів", "Photo Report History"),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )

                                Button(
                                    onClick = { showAddPhotoReportDialog = true },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    modifier = Modifier.testTag("btn_add_photo_report")
                                ) {
                                    Icon(Icons.Default.AddAPhoto, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(L.tr("Добавить фото", "Додати фото", "Add Photo"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (photoReports.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = Icons.Default.InsertPhoto,
                                            contentDescription = null,
                                            modifier = Modifier.size(56.dp),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(L.tr("Фотоотчётов пока нет", "Фотозвітів поки немає", "No photo reports yet"), fontWeight = FontWeight.Bold)
                                        Text(L.tr("Добавьте первый фотоотчёт с объекта", "Додайте перший фотозвіт з об'єкта", "Add first photo report from site"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            } else {
                                LazyColumn(
                                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                                    verticalArrangement = Arrangement.spacedBy(16.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    items(photoReports, key = { it.id }) { report ->
                                        PhotoReportCard(
                                            report = report,
                                            onPhotoClick = { photoName -> selectedPreviewPhoto = photoName },
                                            onEditClick = { reportToEdit = report },
                                            onDeleteClick = { reportToDelete = report }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                3 -> {
                    // Chat Tab
                    Column(modifier = Modifier.fillMaxSize()) {
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(messages, key = { it.id }) { msg ->
                                ChatBubbleMessage(
                                    message = msg,
                                    isCurrentUser = msg.senderId == (currentUser?.id ?: ""),
                                    onEditClick = { messageToEdit = msg },
                                    onDeleteClick = { messageToDelete = msg }
                                )
                            }
                        }

                        // Message Input Bar
                        Surface(
                            shadowElevation = 8.dp,
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = messageInput,
                                    onValueChange = { messageInput = it },
                                    placeholder = { Text(L.tr("Сообщение...", "Повідомлення...", "Message...")) },
                                    singleLine = true,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("input_chat_msg")
                                )

                                Spacer(modifier = Modifier.width(8.dp))

                                IconButton(
                                    onClick = {
                                        if (messageInput.isNotBlank()) {
                                            val user = currentUser ?: UserEntity(id = "user_anon", email = "a@a.com", name = L.tr("Пользователь", "Користувач", "User"), role = "CUSTOMER", token = "t")
                                            val sentText = messageInput
                                            projectViewModel.sendMessage(project.id, user, sentText)
                                            NotificationHelper.sendChatNotification(
                                                context = context,
                                                projectId = project.id,
                                                projectName = project.title,
                                                senderName = user.name.ifBlank { L.tr("Пользователь", "Користувач", "User") },
                                                text = sentText
                                            )
                                            messageInput = ""
                                        }
                                    },
                                    modifier = Modifier.testTag("btn_send_chat")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Send,
                                        contentDescription = "Send",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }

                4 -> {
                    // Finances & Estimate Tab
                    ProjectFinanceComponent(
                        project = project,
                        finances = finances,
                        financeViewModel = financeViewModel,
                        onOpenSmartCalculator = { showSmartCalculatorDialog = true }
                    )
                }
            }
        }
    }
}

    // Smart Calculator Dialog
    if (showSmartCalculatorDialog) {
        SmartCalculatorDialog(
            onDismiss = { showSmartCalculatorDialog = false },
            onAddToFinance = { title, amount, category, type ->
                financeViewModel.addFinanceItem(
                    projectId = project.id,
                    title = title,
                    amountRub = amount,
                    type = type,
                    category = category,
                    date = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date()),
                    note = L.tr("Рассчитано через Умный Калькулятор", "Розраховано через Розумний Калькулятор", "Calculated via Smart Calculator")
                )
                showSmartCalculatorDialog = false
            }
        )
    }

    // Add Photo Report Dialog
    if (showAddPhotoReportDialog) {
        AddPhotoReportDialog(
            onDismiss = { showAddPhotoReportDialog = false },
            onConfirm = { stageName, desc, photoTitles ->
                val author = if (currentUser?.role == "FOREMAN") (currentUser.name.ifBlank { L.tr("Прораб", "Прораб", "Foreman") }) else L.tr("Заказчик", "Замовник", "Customer")
                val photoJson = "[\"" + photoTitles.split(",").joinToString("\", \"") { it.trim() } + "\"]"
                projectViewModel.addPhotoReport(
                    projectId = project.id,
                    stageName = stageName,
                    description = desc,
                    photosJson = photoJson,
                    authorName = author
                )
                showAddPhotoReportDialog = false
            }
        )
    }

    // Fullscreen Photo Preview Dialog
    if (selectedPreviewPhoto != null) {
        AlertDialog(
            onDismissRequest = { selectedPreviewPhoto = null },
            title = { Text(selectedPreviewPhoto ?: L.tr("Фото объекта", "Фото об'єкта", "Site Photo"), fontWeight = FontWeight.Bold) },
            text = {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Camera, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = selectedPreviewPhoto ?: L.tr("Снимок со стройки", "Знімок з будівництва", "Photo from site"),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Text(
                                text = L.tr("Загружено в оригинальном качестве HD", "Завантажено в оригінальній якості HD", "Uploaded in HD original quality"),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { selectedPreviewPhoto = null }) {
                    Text(L.tr("Закрыть", "Закрити", "Close"))
                }
            }
        )
    }
    if (showDeleteProjectDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteProjectDialog = false },
            title = { Text(L.tr("Удалить объект?", "Видалити об'єкт?", "Delete Site?"), fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    L.tr(
                        "Вы действительно хотите удалить объект «${project.title}»? Это действие нельзя отменить.",
                        "Ви дійсно бажаєте видалити об'єкт «${project.title}»? Цю дію не можна скасувати.",
                        "Are you sure you want to delete «${project.title}»? This action cannot be undone."
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteProjectDialog = false
                        projectViewModel.deleteProject(project.id)
                        onBackClick()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(L.tr("Удалить", "Видалити", "Delete"))
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteProjectDialog = false }) {
                    Text(L.tr("Отмена", "Скасувати", "Cancel"))
                }
            }
        )
    }

    if (showEditProjectDialog) {
        EditProjectDialog(
            project = project,
            onDismiss = { showEditProjectDialog = false },
            onConfirm = { updatedProject ->
                projectViewModel.updateProject(updatedProject)
                showEditProjectDialog = false
            }
        )
    }

    if (showAddMilestoneDialog) {
        AddEditMilestoneDialog(
            onDismiss = { showAddMilestoneDialog = false },
            onConfirm = { title, category, dueDate, assignedTo ->
                projectViewModel.addMilestone(projectId, title, category, dueDate, assignedTo)
                showAddMilestoneDialog = false
            }
        )
    }

    if (milestoneToEdit != null) {
        AddEditMilestoneDialog(
            existingMilestone = milestoneToEdit,
            onDismiss = { milestoneToEdit = null },
            onConfirm = { title, category, dueDate, assignedTo ->
                milestoneToEdit?.let { ms ->
                    projectViewModel.updateMilestone(ms.copy(title = title, category = category, dueDate = dueDate, assignedTo = assignedTo))
                }
                milestoneToEdit = null
            }
        )
    }

    if (milestoneToDelete != null) {
        AlertDialog(
            onDismissRequest = { milestoneToDelete = null },
            title = { Text(L.tr("Удалить этап?", "Видалити етап?", "Delete Milestone?"), fontWeight = FontWeight.Bold) },
            text = { Text(L.tr("Вы уверены, что хотите удалить этот этап из графика?", "Ви впевнені, що хочете видалити цей етап з графіка?", "Are you sure you want to delete this milestone?")) },
            confirmButton = {
                Button(
                    onClick = {
                        milestoneToDelete?.let { ms -> projectViewModel.deleteMilestone(ms.id, projectId) }
                        milestoneToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(L.tr("Удалить", "Видалити", "Delete"))
                }
            },
            dismissButton = {
                TextButton(onClick = { milestoneToDelete = null }) {
                    Text(L.tr("Отмена", "Скасувати", "Cancel"))
                }
            }
        )
    }

    if (reportToDelete != null) {
        val rep = reportToDelete!!
        AlertDialog(
            onDismissRequest = { reportToDelete = null },
            title = { Text(L.tr("Удалить фотоотчёт?", "Видалити фотозвіт?", "Delete Photo Report?"), fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    L.tr(
                        "Удалить фотоотчёт по этапу «${rep.stageName}»?",
                        "Видалити фотозвіт по етапу «${rep.stageName}»?",
                        "Delete photo report for stage «${rep.stageName}»?"
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        projectViewModel.deletePhotoReport(rep.id)
                        reportToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(L.tr("Удалить", "Видалити", "Delete"))
                }
            },
            dismissButton = {
                TextButton(onClick = { reportToDelete = null }) {
                    Text(L.tr("Отмена", "Скасувати", "Cancel"))
                }
            }
        )
    }

    if (reportToEdit != null) {
        val rep = reportToEdit!!
        EditPhotoReportDialog(
            report = rep,
            onDismiss = { reportToEdit = null },
            onConfirm = { updated ->
                projectViewModel.updatePhotoReport(updated)
                reportToEdit = null
            }
        )
    }

    if (messageToDelete != null) {
        val msg = messageToDelete!!
        AlertDialog(
            onDismissRequest = { messageToDelete = null },
            title = { Text(L.tr("Удалить сообщение?", "Видалити повідомлення?", "Delete Message?"), fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    L.tr(
                        "Удалить сообщение «${msg.text.take(30)}...»?",
                        "Видалити повідомлення «${msg.text.take(30)}...»?",
                        "Delete message «${msg.text.take(30)}...»?"
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        projectViewModel.deleteMessage(msg.id)
                        messageToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(L.tr("Удалить", "Видалити", "Delete"))
                }
            },
            dismissButton = {
                TextButton(onClick = { messageToDelete = null }) {
                    Text(L.tr("Отмена", "Скасувати", "Cancel"))
                }
            }
        )
    }

    if (messageToEdit != null) {
        val msg = messageToEdit!!
        EditMessageDialog(
            message = msg,
            onDismiss = { messageToEdit = null },
            onConfirm = { updated ->
                projectViewModel.updateMessage(updated)
                messageToEdit = null
            }
        )
    }
}

@Composable
fun PhotoReportCard(
    report: PhotoReportEntity,
    onPhotoClick: (String) -> Unit,
    onEditClick: (() -> Unit)? = null,
    onDeleteClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Text(
                        text = report.stageName,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = report.date,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.width(4.dp))

                    if (onEditClick != null) {
                        IconButton(
                            onClick = onEditClick,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit photo report",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete photo report",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = report.description,
                style = MaterialTheme.typography.bodyMedium
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "${L.tr("Автор", "Автор", "Author")}: ${report.authorName}",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Photo Previews Row
            val photoList = remember(report.photoUrlsJson) {
                report.photoUrlsJson
                    .replace("[", "")
                    .replace("]", "")
                    .replace("\"", "")
                    .split(",")
                    .map { it.trim() }
                    .filter { it.isNotBlank() }
            }

            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(photoList) { photoTitle ->
                    Card(
                        modifier = Modifier
                            .size(width = 130.dp, height = 90.dp)
                            .clickable { onPhotoClick(photoTitle) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = photoTitle,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddPhotoReportDialog(
    onDismiss: () -> Unit,
    onConfirm: (stageName: String, desc: String, photos: String) -> Unit
) {
    var stageName by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var photos by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L.tr("Новый фотоотчёт с объекта", "Новий фотозвіт з об'єкта", "New Site Photo Report"), fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = stageName,
                    onValueChange = { stageName = it },
                    label = { Text(L.tr("Этап работ", "Етап робіт", "Work Stage")) },
                    placeholder = { Text(L.tr("например, Черновая электрика", "наприклад, Чорнова електрика", "e.g. Rough electrical")) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text(L.tr("Описание выполненных работ", "Опис виконаних робіт", "Work Description")) },
                    placeholder = { Text(L.tr("Завершен проход кабелей, установлены подрозетники...", "Завершено прокладку кабелів, встановлено підрозетники...", "Cable routing complete, flush boxes installed...")) },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )

                OutlinedTextField(
                    value = photos,
                    onValueChange = { photos = it },
                    label = { Text(L.tr("Названия / Теги фото (через запятую)", "Назви / Теги фото (через кому)", "Photo Titles / Tags (comma separated)")) },
                    placeholder = { Text(L.tr("Вид щита, Разводка по полу, Кухня", "Вид щита, Розводка по підлозі, Кухня", "Panel view, Floor wiring, Kitchen")) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(stageName, desc, photos) },
                enabled = stageName.isNotBlank() && desc.isNotBlank()
            ) {
                Text(L.tr("Опубликовать фотоотчёт", "Опублікувати фотозвіт", "Publish Photo Report"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(L.tr("Отмена", "Скасувати", "Cancel"))
            }
        }
    )
}

@Composable
fun ChatBubbleMessage(
    message: MessageEntity,
    isCurrentUser: Boolean,
    onEditClick: (() -> Unit)? = null,
    onDeleteClick: (() -> Unit)? = null
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isCurrentUser) Alignment.End else Alignment.Start
    ) {
        Text(
            text = message.senderName,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = if (isCurrentUser) Arrangement.End else Arrangement.Start
        ) {
            if (!isCurrentUser) {
                if (onEditClick != null) {
                    IconButton(onClick = onEditClick, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit message", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    }
                }
                if (onDeleteClick != null) {
                    IconButton(onClick = onDeleteClick, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete message", tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.size(16.dp))
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isCurrentUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
            ) {
                Text(
                    text = message.text,
                    color = if (isCurrentUser) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    fontSize = 14.sp
                )
            }

            if (isCurrentUser) {
                if (onEditClick != null) {
                    IconButton(onClick = onEditClick, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit message", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    }
                }
                if (onDeleteClick != null) {
                    IconButton(onClick = onDeleteClick, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete message", tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun EditPhotoReportDialog(
    report: PhotoReportEntity,
    onDismiss: () -> Unit,
    onConfirm: (updatedReport: PhotoReportEntity) -> Unit
) {
    var stageName by remember { mutableStateOf(report.stageName) }
    var desc by remember { mutableStateOf(report.description) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L.tr("Редактировать фотоотчёт", "Редагувати фотозвіт", "Edit Photo Report"), fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = stageName,
                    onValueChange = { stageName = it },
                    label = { Text(L.tr("Этап работ", "Етап робіт", "Work Stage")) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text(L.tr("Описание выполненных работ", "Опис виконаних робіт", "Work Description")) },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(report.copy(stageName = stageName, description = desc))
                },
                enabled = stageName.isNotBlank() && desc.isNotBlank()
            ) {
                Text(L.tr("Сохранить", "Зберегти", "Save"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(L.tr("Отмена", "Скасувати", "Cancel"))
            }
        }
    )
}

@Composable
fun EditMessageDialog(
    message: MessageEntity,
    onDismiss: () -> Unit,
    onConfirm: (updatedMessage: MessageEntity) -> Unit
) {
    var text by remember { mutableStateOf(message.text) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L.tr("Редактировать сообщение", "Редагувати повідомлення", "Edit Message"), fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text(L.tr("Текст сообщения", "Текст повідомлення", "Message Text")) },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 4
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(message.copy(text = text))
                },
                enabled = text.isNotBlank()
            ) {
                Text(L.tr("Сохранить", "Зберегти", "Save"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(L.tr("Отмена", "Скасувати", "Cancel"))
            }
        }
    )
}
