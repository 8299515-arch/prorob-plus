package com.example.ui.projects

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import com.example.ui.components.ScrollToTopBottomButtons
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.ProjectEntity
import com.example.data.local.UserEntity
import com.example.ui.viewmodel.ProjectViewModel
import com.example.util.L

enum class ProjectFilterTab {
    ALL, IN_PROGRESS, REQUESTED, COMPLETED;

    @Composable
    fun getLabel(): String {
        return when (this) {
            ALL -> L.tr("Все объекты", "Всі об'єкти", "All Projects")
            IN_PROGRESS -> L.tr("В работе", "В роботі", "In Progress")
            REQUESTED -> L.tr("Заявки", "Заявки", "Requests")
            COMPLETED -> L.tr("Завершенные", "Завершені", "Completed")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectsListScreen(
    currentUser: UserEntity?,
    projectViewModel: ProjectViewModel,
    onProjectClick: (String) -> Unit,
    onBackClick: () -> Unit
) {
    val allProjects by projectViewModel.allProjects.collectAsState()
    val projects = remember(allProjects, currentUser) {
        if (currentUser?.role == "CUSTOMER") {
            allProjects.filter { it.customerId == currentUser.id }
        } else {
            allProjects
        }
    }
    var selectedFilter by remember { mutableStateOf(ProjectFilterTab.ALL) }
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    var projectToDelete by remember { mutableStateOf<ProjectEntity?>(null) }
    var projectToEdit by remember { mutableStateOf<ProjectEntity?>(null) }

    // Filter projects
    val filteredProjects = remember(projects, selectedFilter, searchQuery) {
        projects.filter { proj ->
            val matchesFilter = when (selectedFilter) {
                ProjectFilterTab.ALL -> true
                ProjectFilterTab.IN_PROGRESS -> proj.status == "IN_PROGRESS" || proj.status == "ACTIVE"
                ProjectFilterTab.REQUESTED -> proj.status == "REQUESTED"
                ProjectFilterTab.COMPLETED -> proj.status == "COMPLETED"
            }
            val matchesQuery = if (searchQuery.isBlank()) true else {
                proj.title.contains(searchQuery, ignoreCase = true) ||
                proj.address.contains(searchQuery, ignoreCase = true) ||
                proj.customerName.contains(searchQuery, ignoreCase = true) ||
                proj.foremanName.contains(searchQuery, ignoreCase = true)
            }
            matchesFilter && matchesQuery
        }
    }

    val totalBudget = projects.sumOf { it.budgetRub }
    val activeCount = projects.count { it.status == "IN_PROGRESS" || it.status == "ACTIVE" }

    val listState = rememberLazyListState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(L.tr("Проекты и Объекты", "Проєкти та Об'єкти", "Projects & Sites"), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showAddDialog = true }) {
                        Icon(Icons.Default.AddBusiness, contentDescription = "Add site")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text(L.tr("Добавить объект", "Додати об'єкт", "Add Site"), fontWeight = FontWeight.Bold) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_project")
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Vibrant architectural blueprint desk with golden sunlight background
            Image(
                painter = painterResource(id = R.drawable.img_bg_projects_vibrant_1785324448473),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Dark protective scrim for vibrant photo detail with zero white glare
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.25f),
                                Color.Black.copy(alpha = 0.50f)
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier.fillMaxSize()
            ) {
            // Search Field & Stats Banner
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(L.tr("Поиск по названию, адресу, имени...", "Пошук за назвою, адресою, ім'ям...", "Search title, address, name..."), color = MaterialTheme.colorScheme.onSurfaceVariant) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )

                // Stats Overview
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(L.tr("Всего объектов", "Всього об'єктів", "Total sites"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${projects.size}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(L.tr("В работе", "В роботі", "In progress"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("$activeCount", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary))
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1.2f),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(L.tr("Общий бюджет", "Загальний бюджет", "Total budget"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${totalBudget / 1000} ${L.tr("тыс.", "тис.", "k")} ₴", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }

                // Filter Tabs
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(ProjectFilterTab.entries) { tab ->
                        FilterChip(
                            selected = (selectedFilter == tab),
                            onClick = { selectedFilter = tab },
                            label = {
                                val count = when (tab) {
                                    ProjectFilterTab.ALL -> projects.size
                                    ProjectFilterTab.IN_PROGRESS -> projects.count { it.status == "IN_PROGRESS" || it.status == "ACTIVE" }
                                    ProjectFilterTab.REQUESTED -> projects.count { it.status == "REQUESTED" }
                                    ProjectFilterTab.COMPLETED -> projects.count { it.status == "COMPLETED" }
                                }
                                Text("${tab.getLabel()} ($count)")
                            },
                            shape = RoundedCornerShape(20.dp)
                        )
                    }
                }
            }

            // Projects List
            Box(modifier = Modifier.weight(1f)) {
                if (filteredProjects.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.FolderOpen,
                                contentDescription = null,
                                modifier = Modifier.size(56.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = L.tr("Объекты не найдены", "Об'єкти не знайдено", "Sites not found"),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = L.tr("Попробуйте изменить фильтры или добавьте новый объект", "Спробуйте змінити фільтри або додайте новий об'єкт", "Try changing filters or add a new site"),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 80.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(filteredProjects, key = { it.id }) { project ->
                            ProjectItemCard(
                                project = project,
                                onClick = { onProjectClick(project.id) },
                                onEditClick = { projectToEdit = project },
                                onDeleteClick = { projectToDelete = project }
                            )
                        }
                    }
                }

                ScrollToTopBottomButtons(
                    listState = listState,
                    totalItemsCount = filteredProjects.size + 3,
                    modifier = Modifier.align(Alignment.BottomEnd)
                )
            }
        }
    }
}

    if (showAddDialog) {
        AddProjectDialog(
            currentUser = currentUser,
            onDismiss = { showAddDialog = false },
            onConfirm = { title, address, budget, desc, customerName ->
                projectViewModel.addProject(
                    title = title,
                    address = address,
                    budgetRub = budget,
                    description = desc,
                    currentUser = currentUser,
                    customerName = customerName
                )
                showAddDialog = false
            }
        )
    }

    if (projectToDelete != null) {
        val proj = projectToDelete!!
        AlertDialog(
            onDismissRequest = { projectToDelete = null },
            title = { Text(L.tr("Удалить объект?", "Видалити об'єкт?", "Delete Site?"), fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    L.tr(
                        "Вы действительно хотите удалить объект «${proj.title}»? Все связанные фотоотчеты, сметы и чаты будут удалены.",
                        "Ви дійсно бажаєте видалити об'єкт «${proj.title}»? Усі пов'язані фотозвіти, кошториси та чати будуть видалені.",
                        "Are you sure you want to delete «${proj.title}»? All related photo reports, estimates and chats will be deleted."
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        projectViewModel.deleteProject(proj.id)
                        projectToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(L.tr("Удалить", "Видалити", "Delete"))
                }
            },
            dismissButton = {
                TextButton(onClick = { projectToDelete = null }) {
                    Text(L.tr("Отмена", "Скасувати", "Cancel"))
                }
            }
        )
    }

    if (projectToEdit != null) {
        val proj = projectToEdit!!
        EditProjectDialog(
            project = proj,
            onDismiss = { projectToEdit = null },
            onConfirm = { updatedProject ->
                projectViewModel.updateProject(updatedProject)
                projectToEdit = null
            }
        )
    }
}

@Composable
fun ProjectItemCard(
    project: ProjectEntity,
    onClick: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("project_item_${project.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = project.title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.weight(1f)
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    val (statusText, statusBg, statusFg) = when (project.status) {
                        "REQUESTED" -> Triple(L.tr("Заявка", "Заявка", "Request"), Color(0xFFFEF3C7), Color(0xFF92400E))
                        "IN_PROGRESS", "ACTIVE" -> Triple(L.tr("В работе", "В роботі", "In Progress"), Color(0xFFDCFCE7), Color(0xFF166534))
                        "COMPLETED" -> Triple(L.tr("Завершен", "Завершено", "Completed"), Color(0xFFE0F2FE), Color(0xFF075985))
                        else -> Triple(L.tr("Пауза", "Пауза", "Paused"), Color(0xFFF1F5F9), Color(0xFF475569))
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = statusBg
                    ) {
                        Text(
                            text = statusText,
                            color = statusFg,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    IconButton(
                        onClick = onEditClick,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit site",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete site",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Place, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = project.address,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${L.tr("Заказчик", "Замовник", "Customer")}: ${project.customerName} • ${L.tr("Прораб", "Прораб", "Foreman")}: ${project.foremanName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("${L.tr("Прогресс работ", "Прогрес робіт", "Work Progress")}: ${project.progressPercent}%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                Text("${L.tr("Бюджет", "Бюджет", "Budget")}: ${project.budgetRub} ₴", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }

            Spacer(modifier = Modifier.height(4.dp))

            LinearProgressIndicator(
                progress = { project.progressPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}

@Composable
fun AddProjectDialog(
    currentUser: UserEntity?,
    onDismiss: () -> Unit,
    onConfirm: (title: String, address: String, budget: Long, desc: String, customerName: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var budgetText by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var customerName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L.tr("Новый строительный объект", "Новий будівельний об'єкт", "New Construction Site"), fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(L.tr("Название объекта / проекта", "Назва об'єкта / проєкту", "Site / Project Name")) },
                    placeholder = { Text(L.tr("например, Квартира в ЖК PecherSKY", "наприклад, Квартира в ЖК PecherSKY", "e.g. Apartment in PecherSKY")) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text(L.tr("Адрес объекта", "Адреса об'єкта", "Site Address")) },
                    placeholder = { Text(L.tr("ул. Крещатик, д. 15, кв. 42", "вул. Хрещатик, буд. 15, кв. 42", "15 Khreshchatyk str, apt 42")) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = budgetText,
                    onValueChange = { budgetText = it },
                    label = { Text(L.tr("Бюджет проекта (₴)", "Бюджет проєкту (₴)", "Project Budget (₴)")) },
                    placeholder = { Text("1500000") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (currentUser?.role == "FOREMAN") {
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text(L.tr("ФИО / Контакт Заказчика", "ПІБ / Контакт Замовника", "Customer Name / Contact")) },
                        placeholder = { Text("Олександр Коваленко") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text(L.tr("Описание и задачи", "Опис та завдання", "Description & Tasks")) },
                    placeholder = { Text(L.tr("Капитальный ремонт, укладка плитки, сантехника", "Капітальний ремонт, укладання плитки, сантехніка", "General renovation, tiling, plumbing")) },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val budget = budgetText.toLongOrNull() ?: 0L
                    onConfirm(title, address, budget, desc, customerName)
                },
                enabled = title.isNotBlank() && address.isNotBlank()
            ) {
                Text(L.tr("Создать объект", "Створити об'єкт", "Create Site"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(L.tr("Отмена", "Скасувати", "Cancel"))
            }
        }
    )
}

@Composable
fun EditProjectDialog(
    project: ProjectEntity,
    onDismiss: () -> Unit,
    onConfirm: (updatedProject: ProjectEntity) -> Unit
) {
    var title by remember { mutableStateOf(project.title) }
    var address by remember { mutableStateOf(project.address) }
    var budgetText by remember { mutableStateOf(project.budgetRub.toString()) }
    var progressText by remember { mutableStateOf(project.progressPercent.toString()) }
    var desc by remember { mutableStateOf(project.description) }
    var customerName by remember { mutableStateOf(project.customerName) }
    var foremanName by remember { mutableStateOf(project.foremanName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L.tr("Редактировать объект", "Редагувати об'єкт", "Edit Site"), fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(L.tr("Название объекта", "Назва об'єкта", "Site Name")) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text(L.tr("Адрес объекта", "Адреса об'єкта", "Site Address")) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = budgetText,
                        onValueChange = { budgetText = it },
                        label = { Text(L.tr("Бюджет (₴)", "Бюджет (₴)", "Budget (₴)")) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = progressText,
                        onValueChange = { progressText = it },
                        label = { Text(L.tr("Прогресс (%)", "Прогрес (%)", "Progress (%)")) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = customerName,
                    onValueChange = { customerName = it },
                    label = { Text(L.tr("Заказчик", "Замовник", "Customer")) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = foremanName,
                    onValueChange = { foremanName = it },
                    label = { Text(L.tr("Прораб", "Прораб", "Foreman")) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text(L.tr("Описание", "Опис", "Description")) },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val budget = budgetText.toLongOrNull() ?: project.budgetRub
                    val progress = progressText.toIntOrNull()?.coerceIn(0, 100) ?: project.progressPercent
                    onConfirm(
                        project.copy(
                            title = title,
                            address = address,
                            budgetRub = budget,
                            progressPercent = progress,
                            customerName = customerName,
                            foremanName = foremanName,
                            description = desc
                        )
                    )
                },
                enabled = title.isNotBlank() && address.isNotBlank()
            ) {
                Text(L.tr("Сохранить изменения", "Зберегти зміни", "Save Changes"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(L.tr("Отмена", "Скасувати", "Cancel"))
            }
        }
    )
}
