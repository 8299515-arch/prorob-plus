package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ProjectEntity
import com.example.data.local.TeamMemberEntity
import com.example.data.repository.ProrabRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class TeamViewModel(private val repository: ProrabRepository) : ViewModel() {

    val allTeamMembers: StateFlow<List<TeamMemberEntity>> = repository.getAllTeamMembersFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allProjects: StateFlow<List<ProjectEntity>> = repository.allProjectsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun getTeamForForeman(foremanId: String): Flow<List<TeamMemberEntity>> {
        return repository.getTeamForForemanFlow(foremanId)
    }

    fun addTeamMember(
        foremanId: String,
        name: String,
        roleTitle: String,
        phone: String,
        dailyRateRub: Long,
        assignedProjectId: String = ""
    ) {
        viewModelScope.launch {
            val member = TeamMemberEntity(
                id = "team_" + UUID.randomUUID().toString().take(8),
                foremanId = foremanId,
                name = name,
                roleTitle = roleTitle,
                phone = phone,
                dailyRateRub = dailyRateRub,
                assignedProjectId = assignedProjectId,
                isAvailable = assignedProjectId.isBlank()
            )
            repository.addTeamMember(member)
        }
    }

    fun updateTeamMember(member: TeamMemberEntity) {
        viewModelScope.launch {
            repository.addTeamMember(member)
        }
    }

    fun deleteTeamMember(id: String) {
        viewModelScope.launch {
            repository.deleteTeamMember(id)
        }
    }
}

