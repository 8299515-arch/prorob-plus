package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ====================================
// BRAND DESIGN SYSTEM: ПРОРАБ+
// Style: Premium Industrial AI SaaS
// ====================================

// Base Graphite Colors
val ProRabGraphite = Color(0xFF111827)
val ProRabGraphiteSurface = Color(0xFF1F2937)
val ProRabSteel = Color(0xFF374151)

// AI Engine Colors
val ProRabAiBlue = Color(0xFF2563EB)
val ProRabAiBlueLight = Color(0xFF3B82F6)
val ProRabAiBlueDark = Color(0xFF1E40AF)
val AiGlow = Color(0xFF60A5FA)
val AiCardBackground = Color(0xFF172554)

// Construction Accents
val ProRabOrange = Color(0xFFF59E0B)
val ProRabOrangeLight = Color(0xFFFBBF24)
val ProRabWhite = Color(0xFFFFFFFF)

// Construction Status Colors
val ConstructionSuccess = Color(0xFF22C55E)
val ConstructionWarning = Color(0xFFF97316)
val ConstructionDanger = Color(0xFFEF4444)

// Legacy Aliases for Seamless Backward Compatibility
val DarkGraphite = ProRabGraphite
val DarkGraphiteSurface = ProRabGraphiteSurface
val DarkGraphiteVariant = ProRabSteel

val AiBlue = ProRabAiBlue
val AiBlueLight = ProRabAiBlueLight
val AiBlueContainer = ProRabAiBlueDark

val SafetyOrange = ProRabOrange
val SafetyOrangeLight = ProRabOrangeLight

val BoldPurplePrimary = ProRabAiBlue
val BoldPurpleOnPrimary = ProRabWhite
val BoldPurpleContainer = Color(0xFFDBEAFE)
val BoldPurpleOnPrimaryContainer = ProRabAiBlueDark

val BoldSecondary = Color(0xFF475569)
val BoldOnSecondary = ProRabWhite
val BoldSecondaryContainer = Color(0xFFF1F5F9)
val BoldOnSecondaryContainer = Color(0xFF0F172A)

val BoldTertiary = ProRabOrange
val BoldOnTertiary = ProRabWhite
val BoldTertiaryContainer = Color(0xFFFEF3C7)

val BoldBackground = Color(0xFFF8FAFC)
val BoldOnBackground = Color(0xFF0F172A)

val BoldSurface = ProRabWhite
val BoldOnSurface = Color(0xFF0F172A)
val BoldSurfaceVariant = Color(0xFFF1F5F9)
val BoldOnSurfaceVariant = Color(0xFF334155)

val BoldOutline = Color(0xFF64748B)
val BoldOutlineVariant = Color(0xFFCBD5E1)

val BoldError = ConstructionDanger
val BoldOnError = ProRabWhite
val BoldErrorContainer = Color(0xFFFEE2E2)

val BoldDarkPrimary = ProRabAiBlueLight
val BoldDarkOnPrimary = ProRabWhite
val BoldDarkPrimaryContainer = ProRabAiBlueDark
val BoldDarkOnPrimaryContainer = Color(0xFFEFF6FF)
val BoldDarkBackground = ProRabGraphite
val BoldDarkSurface = ProRabGraphiteSurface
val BoldDarkSurfaceVariant = ProRabSteel
