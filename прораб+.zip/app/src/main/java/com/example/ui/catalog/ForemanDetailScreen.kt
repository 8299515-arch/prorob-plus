package com.example.ui.catalog

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import com.example.ui.components.ScrollToTopBottomButtons
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.ForemanProfileEntity
import com.example.data.local.ReviewEntity
import com.example.data.local.UserEntity
import com.example.ui.viewmodel.CatalogViewModel
import com.example.ui.viewmodel.ProjectViewModel
import com.example.util.L
import com.example.util.UkrainianCities

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForemanDetailScreen(
    foremanId: String,
    catalogViewModel: CatalogViewModel,
    projectViewModel: ProjectViewModel,
    currentUser: UserEntity?,
    onBackClick: () -> Unit,
    onProjectCreated: (String) -> Unit
) {
    val foremen by catalogViewModel.allForemen.collectAsState()
    val foreman = foremen.find { it.id == foremanId }
    val reviews by catalogViewModel.getReviewsForForeman(foremanId).collectAsState(initial = emptyList())
    val context = LocalContext.current

    val listState = rememberLazyListState()

    var showCreateProjectDialog by remember { mutableStateOf(false) }

    if (foreman == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(foreman.name, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${foreman.phone}"))
                            context.startActivity(intent)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(L.tr("Позвонить", "Зателефонувати", "Call"))
                    }

                    Button(
                        onClick = { showCreateProjectDialog = true },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("btn_start_project_with_foreman"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.AddBusiness, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(L.tr("Начать проект", "Розпочати проєкт", "Start Project"), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
            // Header Banner
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .background(MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_construction_banner_1785231642070),
                        contentDescription = "Construction Banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // Profile info card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Engineering,
                                        contentDescription = foreman.name,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Column {
                                Text(
                                    text = foreman.name,
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = foreman.specialization,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                val cityDisplay = UkrainianCities.getCityTranslation(foreman.city, com.example.util.LanguageState.currentLanguage)
                                Text(
                                    text = "$cityDisplay • ${L.tr("Опыт", "Досвід", "Experience")} ${foreman.experienceYears} ${L.tr("лет", "років", "years")}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Rating
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFFEF3C7)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = Color(0xFFD97706),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${foreman.rating} (${foreman.reviewsCount} ${L.tr("отзывов", "відгуків", "reviews")})",
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF92400E)
                                    )
                                }
                            }

                            // Price Tag
                            Text(
                                text = "${L.tr("от", "від", "from")} ${foreman.priceFromRub} ₴/м²",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = L.tr("О прорабе", "Про прораба", "About Foreman"),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = foreman.bio,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Portfolio Section
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(
                        text = L.tr("Портфолио выполненных объектов", "Портфоліо виконаних об'єктів", "Completed Portfolio Sites"),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(listOf(
                            "ЖК PecherSKY (120 м²)",
                            "Коттедж Козин (240 м²)",
                            "Пентхаус Аркадия (180 м²)"
                        )) { itemTitle ->
                            Card(
                                modifier = Modifier
                                    .width(200.dp)
                                    .height(140.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Box {
                                    Image(
                                        painter = painterResource(id = R.drawable.img_construction_banner_1785231642070),
                                        contentDescription = itemTitle,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(
                                                androidx.compose.ui.graphics.Brush.verticalGradient(
                                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f))
                                                )
                                            )
                                    )
                                    Text(
                                        text = itemTitle,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .padding(10.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Reviews Section
            item {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "${L.tr("Отзывы клиентов", "Відгуки клієнтів", "Client Reviews")} (${reviews.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    if (reviews.isEmpty()) {
                        Text(
                            text = L.tr("Пока нет отзывов", "Поки немає відгуків", "No reviews yet"),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        reviews.forEach { rev ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = rev.customerName,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Row {
                                            repeat(rev.rating) {
                                                Icon(
                                                    imageVector = Icons.Default.Star,
                                                    contentDescription = null,
                                                    tint = Color(0xFFD97706),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    }

                                    Text(
                                        text = rev.projectTitle,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(vertical = 2.dp)
                                    )

                                    Text(
                                        text = rev.text,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        ScrollToTopBottomButtons(
            listState = listState,
            totalItemsCount = 10 + reviews.size,
            modifier = Modifier.align(Alignment.BottomEnd)
        )

    // Dialog for Direct Project Creation with selected Foreman
    if (showCreateProjectDialog) {
        CreateProjectDialog(
            foreman = foreman,
            currentUser = currentUser,
            onDismiss = { showCreateProjectDialog = false },
            onSubmit = { title, address, budget, description ->
                val user = currentUser ?: UserEntity(
                    id = "cust_anon",
                    email = "customer@example.com",
                    name = L.tr("Заказчик", "Замовник", "Customer"),
                    role = "CUSTOMER",
                    token = "token"
                )
                projectViewModel.createProjectFromCustomer(
                    title = title,
                    foremanId = foreman.id,
                    foremanName = foreman.name,
                    address = address,
                    budgetRub = budget,
                    description = description,
                    customer = user,
                    onCreated = { newProj ->
                        showCreateProjectDialog = false
                        onProjectCreated(newProj.id)
                    }
                )
            }
        )
    }
}
}
}

@Composable
fun CreateProjectDialog(
    foreman: ForemanProfileEntity,
    currentUser: UserEntity?,
    onDismiss: () -> Unit,
    onSubmit: (title: String, address: String, budget: Long, description: String) -> Unit
) {
    var title by remember { mutableStateOf(L.tr("Ремонт квартиры", "Ремонт квартири", "Apartment Repair") + " (${foreman.specialization})") }
    var address by remember { mutableStateOf("${UkrainianCities.getCityTranslation(foreman.city, com.example.util.LanguageState.currentLanguage)}, ул. Крещатик, д. 25") }
    var budgetStr by remember { mutableStateOf("1500000") }
    var description by remember { mutableStateOf(L.tr("Капитальный ремонт с черновой и чистовой отделкой по дизайн-проекту.", "Капітальний ремонт з чорновим та чистовим оздобленням за дизайн-проєктом.", "Turnkey repair with rough and finishing works according to design project.")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${L.tr("Начать проект с", "Розпочати проєкт з", "Start project with")} ${foreman.name}") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(L.tr("Название объекта / проекта", "Назва об'єкта / проєкту", "Site / Project Title")) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_project_title")
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text(L.tr("Адрес объекта", "Адреса об'єкта", "Site Address")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = budgetStr,
                    onValueChange = { budgetStr = it },
                    label = { Text(L.tr("Планируемый бюджет (₴)", "Планований бюджет (₴)", "Planned Budget (₴)")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text(L.tr("Пожелания / Детали заказа", "Побажання / Деталі замовлення", "Notes / Order Details")) },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val budget = budgetStr.toLongOrNull() ?: 1000000L
                    onSubmit(title, address, budget, description)
                },
                modifier = Modifier.testTag("submit_create_project")
            ) {
                Text(L.tr("Отправить заявку", "Надіслати заявку", "Submit Request"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(L.tr("Отмена", "Скасувати", "Cancel"))
            }
        }
    )
}
