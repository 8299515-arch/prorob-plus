package com.example.ui.projects

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.FinanceItemEntity
import com.example.data.local.ProjectEntity
import com.example.ui.viewmodel.FinanceViewModel
import com.example.util.L
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectFinanceComponent(
    project: ProjectEntity,
    finances: List<FinanceItemEntity>,
    financeViewModel: FinanceViewModel,
    onOpenSmartCalculator: () -> Unit
) {
    var selectedFilterTab by remember { mutableIntStateOf(0) } // 0: All, 1: Income, 2: Expenses, 3: Categories
    var showAddDialog by remember { mutableStateOf(false) }
    var itemToEdit by remember { mutableStateOf<FinanceItemEntity?>(null) }
    var itemToDelete by remember { mutableStateOf<FinanceItemEntity?>(null) }
    var showEditBudgetDialog by remember { mutableStateOf(false) }

    val numberFormatter = remember { NumberFormat.getNumberInstance(Locale("ru", "RU")) }

    val totalIncome = remember(finances) {
        finances.filter { it.type == "INCOME" }.sumOf { it.amountRub }
    }
    val totalExpenses = remember(finances) {
        finances.filter { it.type == "EXPENSE" }.sumOf { it.amountRub }
    }
    val balance = totalIncome - totalExpenses
    val budgetRemainder = project.budgetRub - totalExpenses

    val filteredFinances = remember(finances, selectedFilterTab) {
        when (selectedFilterTab) {
            1 -> finances.filter { it.type == "INCOME" }
            2 -> finances.filter { it.type == "EXPENSE" }
            else -> finances
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // 1. Overall Financial Summary & Balance Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = L.tr("Смета и финансовый баланс", "Кошторис та фінансовий баланс", "Estimate & Financial Balance"),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        IconButton(
                            onClick = { showEditBudgetDialog = true },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Budget",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Budget vs Spent progress bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${L.tr("Смета / Бюджет", "Кошторис / Бюджет", "Estimate Budget")}:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${numberFormatter.format(project.budgetRub)} ₴",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    val spentRatio = if (project.budgetRub > 0) (totalExpenses.toFloat() / project.budgetRub.toFloat()).coerceIn(0f, 1f) else 0f
                    LinearProgressIndicator(
                        progress = { spentRatio },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = if (spentRatio > 0.9f) Color(0xFFDC2626) else MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // 4 Stat Badges Grid (Income, Expenses, Cash Balance, Budget Remainder)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Income
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFF0FDF4)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(L.tr("Доходы", "Доходи", "Income"), fontSize = 10.sp, color = Color(0xFF15803D), fontWeight = FontWeight.Medium)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${numberFormatter.format(totalIncome)} ₴",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF166534),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        // Expenses
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFFFF1F2)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = Color(0xFFE11D48), modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(L.tr("Расходы", "Витрати", "Expenses"), fontSize = 10.sp, color = Color(0xFFBE123C), fontWeight = FontWeight.Medium)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${numberFormatter.format(totalExpenses)} ₴",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF9F1239),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Current Balance (Cash in hand)
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = if (balance >= 0) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else Color(0xFFFEF2F2)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(L.tr("Текущий Баланс", "Поточний Баланс", "Cash Balance"), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${if (balance >= 0) "+" else ""}${numberFormatter.format(balance)} ₴",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (balance >= 0) MaterialTheme.colorScheme.primary else Color(0xFFDC2626),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        // Budget Remainder
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(L.tr("Остаток сметы", "Залишок кошторису", "Budget Remaining"), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${numberFormatter.format(budgetRemainder)} ₴",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Quick Action Buttons Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = { showAddDialog = true },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_add_finance_item"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(L.tr("+ Запись", "+ Запис", "+ Record"), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }

                OutlinedButton(
                    onClick = onOpenSmartCalculator,
                    modifier = Modifier
                        .weight(1.2f)
                        .testTag("btn_smart_calc"),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Calculate, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(L.tr("Калькулятор", "Калькулятор", "Calculator"), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }

                OutlinedButton(
                    onClick = { showEditBudgetDialog = true },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(L.tr("Смета", "Кошторис", "Budget"), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }

        // 3. Filter Chips (All, Income, Expenses, Categories Summary)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = selectedFilterTab == 0,
                    onClick = { selectedFilterTab = 0 },
                    label = { Text("${L.tr("Все", "Усі", "All")} (${finances.size})", fontSize = 10.sp) }
                )
                FilterChip(
                    selected = selectedFilterTab == 1,
                    onClick = { selectedFilterTab = 1 },
                    label = { Text("${L.tr("Доходы", "Доходи", "Income")} (${finances.count { it.type == "INCOME" }})", fontSize = 10.sp) }
                )
                FilterChip(
                    selected = selectedFilterTab == 2,
                    onClick = { selectedFilterTab = 2 },
                    label = { Text("${L.tr("Расходы", "Витрати", "Expenses")} (${finances.count { it.type == "EXPENSE" }})", fontSize = 10.sp) }
                )
                FilterChip(
                    selected = selectedFilterTab == 3,
                    onClick = { selectedFilterTab = 3 },
                    label = { Text(L.tr("Категории", "Категорії", "Categories"), fontSize = 10.sp) }
                )
            }
        }

        // 4. Tab 3: Category Summary View OR List of items
        if (selectedFilterTab == 3) {
            item {
                CategoryBreakdownCard(finances = finances)
            }
        } else {
            if (filteredFinances.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.ReceiptLong,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = L.tr("Записей пока нет", "Записів поки немає", "No financial records yet"),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = L.tr("Нажмите '+ Запись' или 'Калькулятор' для внесения", "Натисніть '+ Запис' або 'Калькулятор' для внесення", "Tap '+ Record' or 'Calculator' to add items"),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            } else {
                items(filteredFinances, key = { it.id }) { financeItem ->
                    FinanceItemCard(
                        item = financeItem,
                        onEdit = { itemToEdit = financeItem },
                        onDelete = { itemToDelete = financeItem }
                    )
                }
            }
        }
    }

    // Add / Edit Finance Dialog
    if (showAddDialog || itemToEdit != null) {
        AddEditFinanceDialog(
            projectId = project.id,
            existingItem = itemToEdit,
            onDismiss = {
                showAddDialog = false
                itemToEdit = null
            },
            onSave = { title, amount, type, category, date, note ->
                if (itemToEdit != null) {
                    financeViewModel.updateFinanceItem(
                        itemToEdit!!.copy(
                            title = title,
                            amountRub = amount,
                            type = type,
                            category = category,
                            date = date,
                            note = note
                        )
                    )
                } else {
                    financeViewModel.addFinanceItem(
                        projectId = project.id,
                        title = title,
                        amountRub = amount,
                        type = type,
                        category = category,
                        date = date,
                        note = note
                    )
                }
                showAddDialog = false
                itemToEdit = null
            }
        )
    }

    // Delete Finance Item Confirmation Dialog
    if (itemToDelete != null) {
        AlertDialog(
            onDismissRequest = { itemToDelete = null },
            title = { Text(L.tr("Удалить финансовую запись?", "Видалити фінансовий запис?", "Delete financial record?")) },
            text = { Text("${L.tr("Вы действительно хотите удалить", "Ви дійсно бажаєте видалити", "Are you sure you want to delete")} \"${itemToDelete?.title}\"?") },
            confirmButton = {
                Button(
                    onClick = {
                        financeViewModel.deleteFinanceItem(itemToDelete!!.id, project.id)
                        itemToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(L.tr("Удалить", "Видалити", "Delete"))
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToDelete = null }) {
                    Text(L.tr("Отмена", "Скасувати", "Cancel"))
                }
            }
        )
    }

    // Edit Budget Dialog
    if (showEditBudgetDialog) {
        var budgetInput by remember { mutableStateOf(project.budgetRub.toString()) }

        AlertDialog(
            onDismissRequest = { showEditBudgetDialog = false },
            title = { Text(L.tr("Корректировка сметы объекта", "Коригування кошторису об'єкта", "Edit Project Budget")) },
            text = {
                Column {
                    Text(
                        text = L.tr("Введите плановую сумму сметы/бюджета для этого объекта:", "Введіть планову суму кошторису/бюджету для цього об'єкта:", "Enter scheduled estimate/budget total:"),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = budgetInput,
                        onValueChange = { budgetInput = it },
                        label = { Text(L.tr("Смета / Бюджет (₴)", "Кошторис / Бюджет (₴)", "Estimate Total (₴)")) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newBudget = budgetInput.toLongOrNull() ?: project.budgetRub
                        financeViewModel.updateProjectBudget(project.id, newBudget)
                        showEditBudgetDialog = false
                    }
                ) {
                    Text(L.tr("Сохранить", "Зберегти", "Save"))
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditBudgetDialog = false }) {
                    Text(L.tr("Отмена", "Скасувати", "Cancel"))
                }
            }
        )
    }
}

@Composable
private fun FinanceItemCard(
    item: FinanceItemEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val numberFormatter = remember { NumberFormat.getNumberInstance(Locale("ru", "RU")) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Icon indicator
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            if (item.type == "INCOME") Color(0xFFDCFCE7) else Color(0xFFFFE4E6)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (item.type == "INCOME") Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                        contentDescription = null,
                        tint = if (item.type == "INCOME") Color(0xFF16A34A) else Color(0xFFE11D48),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = item.category,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                maxLines = 1
                            )
                        }

                        if (item.date.isNotBlank()) {
                            Text(
                                text = "•  ${item.date}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${if (item.type == "INCOME") "+" else "-"}${numberFormatter.format(item.amountRub)} ₴",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (item.type == "INCOME") Color(0xFF16A34A) else Color(0xFFE11D48)
                        ),
                        maxLines = 1
                    )

                    Row {
                        IconButton(
                            onClick = onEdit,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Delete",
                                tint = Color.Gray,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            if (item.note.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.background,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = item.note,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun CategoryBreakdownCard(finances: List<FinanceItemEntity>) {
    val numberFormatter = remember { NumberFormat.getNumberInstance(Locale("ru", "RU")) }

    val categoriesSummary = remember(finances) {
        finances.groupBy { it.category }
            .mapValues { entry ->
                val income = entry.value.filter { it.type == "INCOME" }.sumOf { it.amountRub }
                val expense = entry.value.filter { it.type == "EXPENSE" }.sumOf { it.amountRub }
                income to expense
            }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = L.tr("Распределение бюджета по категориям", "Розподіл бюджету за категоріями", "Budget Breakdown by Category"),
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (categoriesSummary.isEmpty()) {
                Text(L.tr("Нет категорий", "Немає категорій", "No categories"), fontSize = 12.sp, color = Color.Gray)
            } else {
                categoriesSummary.forEach { (cat, amounts) ->
                    val (inc, exp) = amounts
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(cat, fontSize = 13.sp, fontWeight = FontWeight.Medium)

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (inc > 0) {
                                Text("+${numberFormatter.format(inc)} ₴", fontSize = 12.sp, color = Color(0xFF16A34A), fontWeight = FontWeight.Bold)
                            }
                            if (exp > 0) {
                                Text("-${numberFormatter.format(exp)} ₴", fontSize = 12.sp, color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Divider(modifier = Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditFinanceDialog(
    projectId: String,
    existingItem: FinanceItemEntity?,
    onDismiss: () -> Unit,
    onSave: (title: String, amount: Long, type: String, category: String, date: String, note: String) -> Unit
) {
    var title by remember { mutableStateOf(existingItem?.title ?: "") }
    var amountText by remember { mutableStateOf(existingItem?.amountRub?.toString() ?: "") }
    var type by remember { mutableStateOf(existingItem?.type ?: "EXPENSE") } // INCOME or EXPENSE
    var category by remember { mutableStateOf(existingItem?.category ?: "Черновые материалы") }
    var dateText by remember {
        mutableStateOf(existingItem?.date ?: SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
    }
    var note by remember { mutableStateOf(existingItem?.note ?: "") }

    val categoriesList = listOf(
        "Черновые материалы",
        "Чистовые материалы",
        "Зарплата рабочим",
        "Оплата заказчика",
        "Оборудование и инструмент",
        "Транспорт и доставка",
        "Прочие расходы"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (existingItem != null) L.tr("Редактирование записи", "Редагування запису", "Edit Record") else L.tr("Новая финансовая запись", "Новий фінансовий запис", "New Financial Record"),
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Type selector
                Row(modifier = Modifier.fillMaxWidth()) {
                    FilterChip(
                        selected = type == "EXPENSE",
                        onClick = {
                            type = "EXPENSE"
                            if (category == "Оплата заказчика") category = "Черновые материалы"
                        },
                        label = { Text(L.tr("Расход (-)", "Витрата (-)", "Expense (-)"), fontSize = 11.sp, maxLines = 1) },
                        leadingIcon = { Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(14.dp)) },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    FilterChip(
                        selected = type == "INCOME",
                        onClick = {
                            type = "INCOME"
                            category = "Оплата заказчика"
                        },
                        label = { Text(L.tr("Доход (+)", "Дохід (+)", "Income (+)"), fontSize = 11.sp, maxLines = 1) },
                        leadingIcon = { Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(14.dp)) },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(L.tr("Наименование", "Найменування", "Title")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text(L.tr("Сумма (₴)", "Сума (₴)", "Amount (₴)")) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Category selection dropdown
                Column {
                    Text(L.tr("Категория:", "Категорія:", "Category:"), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyColumn(modifier = Modifier.height(100.dp)) {
                        items(categoriesList) { cat ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { category = cat }
                                    .padding(vertical = 4.dp, horizontal = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = category == cat, onClick = { category = cat })
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(cat, fontSize = 12.sp)
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it },
                    label = { Text(L.tr("Дата (ГГГГ-ММ-ДД)", "Дата (РРРР-ММ-ДД)", "Date (YYYY-MM-DD)")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text(L.tr("Примечание / Чек", "Примітка / Чек", "Note / Receipt")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toLongOrNull() ?: 0L
                    if (title.isNotBlank() && amount > 0) {
                        onSave(title, amount, type, category, dateText, note)
                    }
                }
            ) {
                Text(L.tr("Сохранить", "Зберегти", "Save"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(L.tr("Отмена", "Скасувати", "Cancel"))
            }
        }
    )
}
