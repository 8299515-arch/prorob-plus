package com.example.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.ForemanProfileEntity
import com.example.ui.viewmodel.CatalogViewModel
import com.example.util.L

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForemanProfileEditScreen(
    catalogViewModel: CatalogViewModel,
    foremanId: String = "foreman_1",
    onBackClick: () -> Unit
) {
    val foremen by catalogViewModel.allForemen.collectAsState()
    val foreman = foremen.find { it.id == foremanId } ?: foremen.firstOrNull()

    var name by remember(foreman) { mutableStateOf(foreman?.name ?: "Олексій Смирнов") }
    var city by remember(foreman) { mutableStateOf(foreman?.city ?: "Киев") }
    var specialization by remember(foreman) { mutableStateOf(foreman?.specialization ?: "Капитальный ремонт квартир") }
    var expYears by remember(foreman) { mutableStateOf(foreman?.experienceYears?.toString() ?: "8") }
    var priceFrom by remember(foreman) { mutableStateOf(foreman?.priceFromRub?.toString() ?: "8500") }
    var bio by remember(foreman) { mutableStateOf(foreman?.bio ?: "Профессиональный ремонт и отделка любой сложности.") }
    var isAvailable by remember(foreman) { mutableStateOf(foreman?.isAvailable ?: true) }

    var showSnackbar by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(L.tr("Профиль прораба в каталоге", "Профіль прораба в каталозі", "Foreman Catalog Profile"), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(L.tr("Публичные данные для каталога заказчиков", "Публічні дані для каталогу замовників", "Public Data for Customer Catalog"), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text(L.tr("Имя и Фамилия", "Ім'я та Прізвище", "Full Name")) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = city,
                        onValueChange = { city = it },
                        label = { Text(L.tr("Город работы", "Місто роботи", "Work City")) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = specialization,
                        onValueChange = { specialization = it },
                        label = { Text(L.tr("Специализация", "Спеціалізація", "Specialization")) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = expYears,
                            onValueChange = { expYears = it },
                            label = { Text(L.tr("Опыт (лет)", "Досвід (років)", "Experience (yrs)")) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = priceFrom,
                            onValueChange = { priceFrom = it },
                            label = { Text(L.tr("Цена от (₴/м²)", "Ціна від (₴/м²)", "Price from (₴/m²)")) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = bio,
                        onValueChange = { bio = it },
                        label = { Text(L.tr("О себе и преимуществах бригады", "Про себе та переваги бригади", "About & Team Advantages")) },
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(L.tr("Доступен для новых заказов:", "Доступний для нових замовлень:", "Available for new orders:"))
                        Switch(
                            checked = isAvailable,
                            onCheckedChange = { isAvailable = it }
                        )
                    }
                }
            }

            Button(
                onClick = {
                    val currentId = foreman?.id ?: "foreman_1"
                    val updated = ForemanProfileEntity(
                        id = currentId,
                        name = name,
                        phone = foreman?.phone ?: "+380 67 123-45-67",
                        city = city,
                        specialization = specialization,
                        experienceYears = expYears.toIntOrNull() ?: 5,
                        rating = foreman?.rating ?: 5.0,
                        reviewsCount = foreman?.reviewsCount ?: 0,
                        isAvailable = isAvailable,
                        bio = bio,
                        priceFromRub = priceFrom.toLongOrNull() ?: 8000L
                    )
                    catalogViewModel.updateForemanProfile(updated)
                    showSnackbar = true
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("btn_save_foreman_profile"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(L.tr("Сохранить и опубликовать в каталоге", "Зберегти та опублікувати в каталозі", "Save & Publish to Catalog"), fontWeight = FontWeight.Bold)
            }

            if (showSnackbar) {
                Text(
                    text = L.tr("✓ Профиль успешно обновлен и опубликован в каталоге!", "✓ Профіль успішно оновлено та опубліковано в каталозі!", "✓ Profile successfully updated and published to catalog!"),
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}
