package com.example.ui.team

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import com.example.ui.components.ScrollToTopBottomButtons
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ProjectEntity
import com.example.data.local.TeamMemberEntity
import com.example.ui.viewmodel.TeamViewModel
import com.example.util.L

enum class TeamTab {
    MASTERS, RATES, SCHEDULE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamScreen(
    viewModel: TeamViewModel,
    onBackClick: () -> Unit
) {
    val members by viewModel.allTeamMembers.collectAsState()
    val projects by viewModel.allProjects.collectAsState()

    var selectedTab by remember { mutableStateOf(TeamTab.MASTERS) }
    var searchQuery by remember { mutableStateOf("") }

    var showAddDialog by remember { mutableStateOf(false) }
    var memberToEdit by remember { mutableStateOf<TeamMemberEntity?>(null) }
    var memberToDelete by remember { mutableStateOf<TeamMemberEntity?>(null) }
    var memberToAssign by remember { mutableStateOf<TeamMemberEntity?>(null) }

    val filteredMembers = remember(members, searchQuery) {
        if (searchQuery.isBlank()) members
        else members.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
            it.roleTitle.contains(searchQuery, ignoreCase = true) ||
            it.phone.contains(searchQuery, ignoreCase = true)
        }
    }

    val listState = rememberLazyListState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(L.tr("Команда & Мастера", "Команда & Майстри", "Team & Craftsmen"), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.testTag("fab_add_team_member")
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Add craftsman")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Tab Selector
            TabRow(
                selectedTabIndex = selectedTab.ordinal,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                Tab(
                    selected = selectedTab == TeamTab.MASTERS,
                    onClick = { selectedTab = TeamTab.MASTERS },
                    text = { Text(L.tr("Мастера", "Майстри", "Masters"), fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
                Tab(
                    selected = selectedTab == TeamTab.RATES,
                    onClick = { selectedTab = TeamTab.RATES },
                    text = { Text(L.tr("Расценки", "Розцінки", "Rates"), fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
                Tab(
                    selected = selectedTab == TeamTab.SCHEDULE,
                    onClick = { selectedTab = TeamTab.SCHEDULE },
                    text = { Text(L.tr("График & Объект", "Графік & Об'єкт", "Schedule & Site"), fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
            }

            Box(modifier = Modifier.weight(1f)) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                item {
                    // Search box
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text(L.tr("Поиск мастера по имени или роли...", "Пошук майстра за ім'ям чи роллю...", "Search craftsman by name or role..."), fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(18.dp))
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                when (selectedTab) {
                    TeamTab.MASTERS -> {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        L.tr("Управление бригадой", "Управління бригадою", "Crew Management"),
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        "${L.tr("Всего специалистов", "Всього фахівців", "Total specialists")}: ${members.size} ${L.tr("чел.", "осіб", "ppl")}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        if (filteredMembers.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        L.tr("Мастера не найдены", "Майстрів не знайдено", "No craftsmen found"),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        } else {
                            items(filteredMembers, key = { it.id }) { member ->
                                val assignedProject = projects.find { it.id == member.assignedProjectId }
                                CraftsmanCard(
                                    member = member,
                                    assignedProject = assignedProject,
                                    onEditClick = { memberToEdit = member },
                                    onDeleteClick = { memberToDelete = member },
                                    onAssignClick = { memberToAssign = member }
                                )
                            }
                        }
                    }

                    TeamTab.RATES -> {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        L.tr("Расценки и дневные ставки", "Розцінки та денні ставки", "Rates & Daily Pay"),
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    val avgRate = if (members.isNotEmpty()) members.map { it.dailyRateRub }.average().toLong() else 0L
                                    Text(
                                        "${L.tr("Средняя", "Середня", "Avg")}: $avgRate ₴/${L.tr("смена", "зміна", "shift")}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }

                        items(filteredMembers, key = { it.id }) { member ->
                            RateManagementCard(
                                member = member,
                                onEditRateClick = { memberToEdit = member }
                            )
                        }
                    }

                    TeamTab.SCHEDULE -> {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        L.tr("График & Назначение", "Графік & Призначення", "Schedule & Assignments"),
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    val busyCount = members.count { !it.isAvailable || it.assignedProjectId.isNotBlank() }
                                    val freeCount = members.size - busyCount
                                    Text(
                                        "${L.tr("На объектах", "На об'єктах", "On site")}: $busyCount • ${L.tr("Свободны", "Вільні", "Free")}: $freeCount",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        items(filteredMembers, key = { it.id }) { member ->
                            val assignedProject = projects.find { it.id == member.assignedProjectId }
                            ScheduleCard(
                                member = member,
                                assignedProject = assignedProject,
                                onAssignClick = { memberToAssign = member },
                                onToggleAvailability = {
                                    viewModel.updateTeamMember(
                                        member.copy(
                                            isAvailable = !member.isAvailable,
                                            assignedProjectId = if (!member.isAvailable) "" else member.assignedProjectId
                                        )
                                    )
                                }
                            )
                        }
                    }
                }
            }

            ScrollToTopBottomButtons(
                listState = listState,
                totalItemsCount = members.size + 3,
                modifier = Modifier.align(Alignment.BottomEnd)
            )
        }
    }
    }

    // Dialogs
    if (showAddDialog) {
        AddTeamMemberDialog(
            projects = projects,
            onDismiss = { showAddDialog = false },
            onSubmit = { name, role, phone, rate, projectId ->
                viewModel.addTeamMember(
                    foremanId = "foreman_1",
                    name = name,
                    roleTitle = role,
                    phone = phone,
                    dailyRateRub = rate,
                    assignedProjectId = projectId
                )
                showAddDialog = false
            }
        )
    }

    if (memberToEdit != null) {
        val member = memberToEdit!!
        EditTeamMemberDialog(
            member = member,
            projects = projects,
            onDismiss = { memberToEdit = null },
            onSubmit = { updated ->
                viewModel.updateTeamMember(updated)
                memberToEdit = null
            }
        )
    }

    if (memberToDelete != null) {
        val member = memberToDelete!!
        AlertDialog(
            onDismissRequest = { memberToDelete = null },
            title = { Text(L.tr("Удалить мастера?", "Видалити майстра?", "Delete Craftsman?"), fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    L.tr(
                        "Вы действительно хотите удалить специалиста «${member.name}» из списка вашей бригады?",
                        "Ви дійсно бажаєте видалити фахівця «${member.name}» зі списку вашої бригади?",
                        "Are you sure you want to remove «${member.name}» from your crew list?"
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteTeamMember(member.id)
                        memberToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(L.tr("Удалить", "Видалити", "Delete"))
                }
            },
            dismissButton = {
                TextButton(onClick = { memberToDelete = null }) {
                    Text(L.tr("Отмена", "Скасувати", "Cancel"))
                }
            }
        )
    }

    if (memberToAssign != null) {
        val member = memberToAssign!!
        AssignProjectDialog(
            member = member,
            projects = projects,
            onDismiss = { memberToAssign = null },
            onConfirm = { selectedProjectId ->
                viewModel.updateTeamMember(
                    member.copy(
                        assignedProjectId = selectedProjectId,
                        isAvailable = selectedProjectId.isBlank()
                    )
                )
                memberToAssign = null
            }
        )
    }
}

@Composable
fun CraftsmanCard(
    member: TeamMemberEntity,
    assignedProject: ProjectEntity?,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onAssignClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Surface(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Construction,
                                contentDescription = member.name,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(member.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "${member.roleTitle} • ${member.phone}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onEditClick,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit craftsman",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete craftsman",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Divider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        L.tr("Ставка / Смена", "Ставка / Зміна", "Daily Rate"),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "${member.dailyRateRub} ₴",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 14.sp
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        L.tr("Текущий объект", "Поточний об'єкт", "Current Site"),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = assignedProject?.title ?: L.tr("Свободен", "Вільний", "Available"),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        color = if (assignedProject != null) MaterialTheme.colorScheme.secondary else Color(0xFF166534)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            OutlinedButton(
                onClick = onAssignClick,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(vertical = 4.dp, horizontal = 8.dp)
            ) {
                Icon(Icons.Default.Apartment, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    if (assignedProject != null) L.tr("Сменить объект", "Змінити об'єкт", "Change Site")
                    else L.tr("Назначить на объект", "Призначити на об'єкт", "Assign to Site"),
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
fun RateManagementCard(
    member: TeamMemberEntity,
    onEditRateClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(member.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(member.roleTitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "${member.dailyRateRub} ₴/${L.tr("смена", "зміна", "shift")}",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = onEditRateClick,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit rate",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ScheduleCard(
    member: TeamMemberEntity,
    assignedProject: ProjectEntity?,
    onAssignClick: () -> Unit,
    onToggleAvailability: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(member.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(member.roleTitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (member.isAvailable && assignedProject == null) Color(0xFFDCFCE7) else Color(0xFFFEF3C7)
                ) {
                    Text(
                        text = if (assignedProject != null) L.tr("Занят на объекте", "Зайнятий на об'єкті", "Busy on site")
                               else if (member.isAvailable) L.tr("Доступен", "Доступний", "Available")
                               else L.tr("Отпуск / Выходной", "Відпустка / Вихідний", "Day off"),
                        color = if (member.isAvailable && assignedProject == null) Color(0xFF166534) else Color(0xFF92400E),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            if (assignedProject != null) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(assignedProject.title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(assignedProject.address, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                Text(
                    L.tr("Специалист не прикреплен к объекту", "Спеціаліст не прикріплений до об'єкта", "Specialist is not assigned to any site"),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onAssignClick,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(vertical = 4.dp, horizontal = 8.dp)
                ) {
                    Text(L.tr("Назначить объект", "Призначити об'єкт", "Assign Site"), fontSize = 12.sp)
                }

                TextButton(
                    onClick = onToggleAvailability,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(vertical = 4.dp, horizontal = 8.dp)
                ) {
                    Text(
                        if (member.isAvailable) L.tr("Поставить выходной", "Поставити вихідний", "Set Day Off")
                        else L.tr("Сделать доступным", "Зробити доступним", "Set Available"),
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
fun AddTeamMemberDialog(
    projects: List<ProjectEntity>,
    onDismiss: () -> Unit,
    onSubmit: (name: String, roleTitle: String, phone: String, dailyRateRub: Long, projectId: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var roleTitle by remember { mutableStateOf(L.tr("Мастер-Отделочник", "Майстер-Оздоблювальник", "Finishing Craftsman")) }
    var phone by remember { mutableStateOf("+380 ") }
    var rateStr by remember { mutableStateOf("2000") }
    var selectedProjectId by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L.tr("Добавить мастера в команду", "Додати майстра в команду", "Add Craftsman to Team"), fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(L.tr("ФИО мастера", "ПІБ майстра", "Full Name")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_team_name")
                )

                OutlinedTextField(
                    value = roleTitle,
                    onValueChange = { roleTitle = it },
                    label = { Text(L.tr("Специализация", "Спеціалізація", "Specialization")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text(L.tr("Телефон", "Телефон", "Phone")) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = rateStr,
                    onValueChange = { rateStr = it },
                    label = { Text(L.tr("Дневная ставка (₴/смена)", "Денна ставка (₴/зміна)", "Daily Rate (₴/shift)")) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                if (projects.isNotEmpty()) {
                    Text(L.tr("Прикрепить к объекту (опционально):", "Прикріпити до об'єкта (опціонально):", "Assign to site (optional):"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    projects.forEach { proj ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            RadioButton(
                                selected = selectedProjectId == proj.id,
                                onClick = { selectedProjectId = if (selectedProjectId == proj.id) "" else proj.id }
                            )
                            Text(proj.title, fontSize = 13.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val rate = rateStr.toLongOrNull() ?: 2000L
                    if (name.isNotBlank()) {
                        onSubmit(name, roleTitle, phone, rate, selectedProjectId)
                    }
                },
                modifier = Modifier.testTag("submit_add_team_member"),
                enabled = name.isNotBlank()
            ) {
                Text(L.tr("Добавить", "Додати", "Add"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(L.tr("Отмена", "Скасувати", "Cancel")) }
        }
    )
}

@Composable
fun EditTeamMemberDialog(
    member: TeamMemberEntity,
    projects: List<ProjectEntity>,
    onDismiss: () -> Unit,
    onSubmit: (updatedMember: TeamMemberEntity) -> Unit
) {
    var name by remember { mutableStateOf(member.name) }
    var roleTitle by remember { mutableStateOf(member.roleTitle) }
    var phone by remember { mutableStateOf(member.phone) }
    var rateStr by remember { mutableStateOf(member.dailyRateRub.toString()) }
    var selectedProjectId by remember { mutableStateOf(member.assignedProjectId) }
    var isAvailable by remember { mutableStateOf(member.isAvailable) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L.tr("Изменить данные мастера", "Змінити дані майстра", "Edit Craftsman Details"), fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(L.tr("ФИО мастера", "ПІБ майстра", "Full Name")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = roleTitle,
                    onValueChange = { roleTitle = it },
                    label = { Text(L.tr("Специализация", "Спеціалізація", "Specialization")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text(L.tr("Телефон", "Телефон", "Phone")) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = rateStr,
                    onValueChange = { rateStr = it },
                    label = { Text(L.tr("Дневная ставка (₴/смена)", "Денна ставка (₴/зміна)", "Daily Rate (₴/shift)")) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = isAvailable,
                        onCheckedChange = { isAvailable = it }
                    )
                    Text(L.tr("Доступен для вызовов", "Доступний для викликів", "Available for shifts"), fontSize = 13.sp)
                }

                if (projects.isNotEmpty()) {
                    Text(L.tr("Прикрепленный объект:", "Прикріплений об'єкт:", "Assigned site:"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        RadioButton(
                            selected = selectedProjectId.isBlank(),
                            onClick = { selectedProjectId = "" }
                        )
                        Text(L.tr("Без объекта (Свободен)", "Без об'єкта (Вільний)", "No site (Unassigned)"), fontSize = 13.sp)
                    }

                    projects.forEach { proj ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            RadioButton(
                                selected = selectedProjectId == proj.id,
                                onClick = { selectedProjectId = proj.id }
                            )
                            Text(proj.title, fontSize = 13.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val rate = rateStr.toLongOrNull() ?: member.dailyRateRub
                    if (name.isNotBlank()) {
                        onSubmit(
                            member.copy(
                                name = name,
                                roleTitle = roleTitle,
                                phone = phone,
                                dailyRateRub = rate,
                                assignedProjectId = selectedProjectId,
                                isAvailable = isAvailable
                            )
                        )
                    }
                },
                enabled = name.isNotBlank()
            ) {
                Text(L.tr("Сохранить", "Зберегти", "Save"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(L.tr("Отмена", "Скасувати", "Cancel")) }
        }
    )
}

@Composable
fun AssignProjectDialog(
    member: TeamMemberEntity,
    projects: List<ProjectEntity>,
    onDismiss: () -> Unit,
    onConfirm: (projectId: String) -> Unit
) {
    var selectedProjectId by remember { mutableStateOf(member.assignedProjectId) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L.tr("Назначение на объект", "Призначення на об'єкт", "Assign to Site"), fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text("${L.tr("Специалист", "Спеціаліст", "Specialist")}: ${member.name}", fontWeight = FontWeight.Bold)

                Divider(modifier = Modifier.padding(vertical = 4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    RadioButton(
                        selected = selectedProjectId.isBlank(),
                        onClick = { selectedProjectId = "" }
                    )
                    Text(L.tr("Снять с объекта (Свободен)", "Зняти з об'єкта (Вільний)", "Unassign (Available)"), fontSize = 13.sp)
                }

                projects.forEach { proj ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        RadioButton(
                            selected = selectedProjectId == proj.id,
                            onClick = { selectedProjectId = proj.id }
                        )
                        Column {
                            Text(proj.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(proj.address, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(selectedProjectId) }
            ) {
                Text(L.tr("Применить", "Застосувати", "Apply"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(L.tr("Отмена", "Скасувати", "Cancel")) }
        }
    )
}
