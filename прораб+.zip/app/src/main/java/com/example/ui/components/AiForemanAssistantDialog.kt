package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ai.GeminiAiService
import com.example.util.L
import kotlinx.coroutines.launch

data class AiChatMessage(val id: String, val sender: String, val text: String, val isAi: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiForemanAssistantDialog(
    projectContext: String? = null,
    onDismissRequest: () -> Unit,
    onAddTaskFromAi: (title: String) -> Unit = {}
) {
    val coroutineScope = rememberCoroutineScope()
    var inputText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    val chatMessages = remember {
        mutableStateListOf(
            AiChatMessage(
                id = "1",
                sender = "AI Прораб",
                text = "Приветствую! Я виртуальный главный инженер «Прораб+». Чем могу помочь? Могу составить график работ, рассчитать объемы материалов, проведать смету или подсказать СНиПы.",
                isAi = true
            )
        )
    }

    val quickPrompts = listOf(
        "Составь план ремонта квартиры 80 м2",
        "Какие материалы нужны для заливки фундамента?",
        "Создай график работ на месяц",
        "Проверь смету на завышение цен"
    )

    AlertDialog(
        onDismissRequest = onDismissRequest,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
            .testTag("dialog_ai_foreman_assistant")
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 620.dp)
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = L.tr("AI Помощник Прораба", "AI Помічник Прораба", "AI Foreman Assistant"),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "Powered by Gemini 3.5 Flash",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    IconButton(
                        onClick = onDismissRequest,
                        modifier = Modifier.testTag("btn_close_ai_dialog")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 12.dp))

                // Quick Suggestions
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 8.dp)
                ) {
                    items(quickPrompts) { prompt ->
                        SuggestionChip(
                            onClick = {
                                inputText = prompt
                            },
                            label = { Text(prompt, fontSize = 12.sp) },
                            icon = { Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        )
                    }
                }

                // Chat Messages List
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    items(chatMessages) { msg ->
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = if (msg.isAi) Alignment.CenterStart else Alignment.CenterEnd
                        ) {
                            Surface(
                                shape = RoundedCornerShape(
                                    topStart = 16.dp,
                                    topEnd = 16.dp,
                                    bottomStart = if (msg.isAi) 4.dp else 16.dp,
                                    bottomEnd = if (msg.isAi) 16.dp else 4.dp
                                ),
                                color = if (msg.isAi) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.widthIn(max = 280.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = msg.sender,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = if (msg.isAi) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onPrimary
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = msg.text,
                                        fontSize = 13.sp,
                                        color = if (msg.isAi) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onPrimary
                                    )

                                    if (msg.isAi && msg.text.length > 30) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        TextButton(
                                            onClick = { onAddTaskFromAi(msg.text.take(60)) },
                                            contentPadding = PaddingValues(0.dp),
                                            modifier = Modifier.height(28.dp)
                                        ) {
                                            Icon(Icons.Default.AddTask, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(L.tr("Превратить в задачу", "Перетворити в задачу", "Make task"), fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (isLoading) {
                        item {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(8.dp)
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("AI анализирует данные...", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Input Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = { Text(L.tr("Задайте вопрос AI...", "Задайте питання AI...", "Ask AI..."), fontSize = 13.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_ai_prompt"),
                        shape = RoundedCornerShape(16.dp),
                        maxLines = 3
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            val prompt = inputText.trim()
                            if (prompt.isNotBlank() && !isLoading) {
                                chatMessages.add(
                                    AiChatMessage(
                                        id = System.currentTimeMillis().toString(),
                                        sender = "Вы",
                                        text = prompt,
                                        isAi = false
                                    )
                                )
                                inputText = ""
                                isLoading = true

                                coroutineScope.launch {
                                    val aiResponse = GeminiAiService.askForemanAssistant(prompt, projectContext)
                                    isLoading = false
                                    chatMessages.add(
                                        AiChatMessage(
                                            id = (System.currentTimeMillis() + 1).toString(),
                                            sender = "AI Прораб",
                                            text = aiResponse,
                                            isAi = true
                                        )
                                    )
                                }
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .testTag("btn_send_ai_prompt")
                    ) {
                        Icon(
                            Icons.Default.Send,
                            contentDescription = "Send",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        }
    }
}
