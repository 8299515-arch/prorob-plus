package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ForemanProfileEntity
import com.example.data.local.ProjectEntity
import com.example.data.model.UserRole
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ProrabPlusUnitTest {

    @Test
    fun `appName string resource matches ProrabPlus`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Прораб+", appName)
    }

    @Test
    fun `user roles separation verification`() {
        val foremanRole = UserRole.FOREMAN
        val customerRole = UserRole.CUSTOMER

        assertEquals("FOREMAN", foremanRole.name)
        assertEquals("CUSTOMER", customerRole.name)
    }

    @Test
    fun `catalog filtering by city and availability`() {
        val foremen = listOf(
            ForemanProfileEntity(
                id = "1", name = "Иван", phone = "123", city = "Москва",
                specialization = "Капитальный ремонт", experienceYears = 10,
                rating = 4.9, reviewsCount = 15, isAvailable = true, bio = "Bio", priceFromRub = 8000
            ),
            ForemanProfileEntity(
                id = "2", name = "Сергей", phone = "456", city = "Казань",
                specialization = "Сантехника", experienceYears = 5,
                rating = 4.5, reviewsCount = 8, isAvailable = false, bio = "Bio", priceFromRub = 5000
            )
        )

        val moscowForemen = foremen.filter { it.city == "Москва" }
        assertEquals(1, moscowForemen.size)
        assertEquals("Иван", moscowForemen[0].name)

        val availableForemen = foremen.filter { it.isAvailable }
        assertEquals(1, availableForemen.size)
        assertEquals("Иван", availableForemen[0].name)
    }

    @Test
    fun `project creation from customer catalog request`() {
        val project = ProjectEntity(
            id = "proj_test_1",
            title = "Ремонт 2-к квартиры",
            customerId = "user_cust_1",
            customerName = "Виктор",
            foremanId = "foreman_1",
            foremanName = "Иван Петров",
            city = "Москва",
            address = "ул. Тверская, д. 1",
            budgetRub = 2000000,
            spentRub = 0,
            status = "REQUESTED",
            progressPercent = 0,
            startDate = "2026-07-28",
            estimatedEndDate = "2026-11-01",
            description = "Капитальный ремонт с нуля."
        )

        assertEquals("REQUESTED", project.status)
        assertEquals(2000000L, project.budgetRub)
        assertEquals("Иван Петров", project.foremanName)
    }
}
